'''
Calculate the layout information needed to chain-drill a hole or disk
from some sheet material by chain-drilling.
'''

# Copyright (C) 2013 Don Peterson
# Contact:  gmail.com@someonesdad1

#
# Licensed under the Open Software License version 3.0.
# See http://opensource.org/licenses/OSL-3.0.
#

from __future__ import print_function, division
import sys
from math import *  # Let input expressions use math symbols
from getnumber import GetNumber as getnum
import getopt
from sig import sig
from u import u, ParseUnit
from pdb import set_trace as xx

py3 = True if sys.version_info[0] > 2 else False
if not py3:
    input = raw_input

default_unit = "inches"

nl = "\n"
ii = isinstance

def Error(msg, status=1):
    print(msg, file=sys.stderr)
    exit(status)

def ParseCommandLine(d):
    d["-d"] = 3         # Number of significant digits
    try:
        opts, args = getopt.getopt(sys.argv[1:], "d:")
    except getopt.GetoptError as e:
        print(str(e))
        exit(1)
    for o, a in opts:
        if o in ("-d",):
            try:
                d["-d"] = int(a)
                if not (1 <= d["-d"] <= 15):
                    raise ValueError()
            except ValueError:
                msg = "-d argument must be an integer between 1 and 15"
                Error(msg)
    sig.digits = d["-d"]
    sig.rtz = True

def GetUserData(d):
    desired = d["desired"]  # It will be a lowercase letter
    # Make it 'hole' or 'disk'
    desired = {"h": "hole", "d": "disk"}[desired[0]]
    key = "%s_diameter" % desired
    # Diameter
    pm = "What is the %s diameter you want? " % desired
    value, unit = getnum(pm, low=0, low_open=True, allow_quit=True,
                         vars=globals(), use_unit=True)
    unit = unit if unit else default_unit
    d[key] = value*u(unit)
    # Drill diameter to use
    pm = "What drill diameter will be used? "
    value, unit = getnum(pm, low=0, low_open=True, allow_quit=True,
                         vars=globals(), use_unit=True)
    unit = unit if unit else default_unit
    d["chain_drill"] = value*u(unit)
    # Distance between drilled hole edges
    pm = "What is the distance between the hole edges? "
    value, unit = getnum(pm, low=0, low_open=True, allow_quit=True,
                         vars=globals(), use_unit=True)
    unit = unit if unit else default_unit
    d["dist_betw_holes"] = value*u(unit)
    # Allowance
    pm = "What is the allowance between the final diameter and chain holes? "
    value, unit = getnum(pm, low=0, low_open=True, allow_quit=True,
                         vars=globals(), use_unit=True)
    unit = unit if unit else default_unit
    d["allowance"] = value*u(unit)

def GetInfo(d):
    digits = d["-d"]
    unit = default_unit
    print('''
This script calculates the parameters for chain drilling a hole or a
disk from sheet material.  Default units are {unit}; you can optionally
type in any common unit name and it should be recognized.  Type q to exit
at any time.  Use the -d option on the command line to change the number of
significant figures in the report (default = {digits}).
'''[1:].format(**locals()))
    opt = {"d": "disk", "h": "hole"}
    d["desired"] = "hole"
    while True:
        print('''
Do you want to chain-drill a hole (h) or a disk (d)? '''[1:], end="")
        s = input("[%s] " % d["desired"][0])
        s = s.lower().strip()
        if s in opt:
            d["desired"] = opt[s]
            break
        elif s == "q":
            exit(0)
        elif not s:
            # Use default value
            break
        else:
            print("Unrecognized response\n")
    GetUserData(d)
    print()

def Chain(d):
    corr = 2*d["allowance"] + d["chain_drill"]
    desired = d["desired"]  # Will be 'hole' or 'disk'
    key = "%s_diameter" % desired
    D = d[key] - corr if d["desired"] == "hole" else d[key] + corr
    dbh = d["dist_betw_holes"]
    n = int((pi*D - dbh)/(d["chain_drill"] + dbh))
    if n <= 1:
        Error("Problem has no reasonable solution")
    dia = d[key]
    circ = D
    angle_radians = 2*pi/n
    theta_deg = angle_radians*180/pi
    chord = D*sin(angle_radians/2)
    chain = d["chain_drill"]
    matl_betw = chord - d["chain_drill"]
    allow = d["allowance"]
    chord = chord
    betw_hole = d["dist_betw_holes"]
    # Check for reasonableness
    if n < 1:
        print("No acceptable solution.  Try again.")
        exit(1)
    # Set up report variables in inches and mm
    dia_in = sig(dia/u("inches"))
    dia_mm = sig(dia/u("mm"))
    chain_in = sig(chain/u("inches"))
    chain_mm = sig(chain/u("mm"))
    allow_in = sig(allow/u("inches"))
    allow_mm = sig(allow/u("mm"))
    betw_hole_in = sig(betw_hole/u("inches"))
    betw_hole_mm = sig(betw_hole/u("mm"))
    matl_betw_in = sig(matl_betw/u("inches"))
    matl_betw_mm = sig(matl_betw/u("mm"))
    circ_in = sig(circ/u("inches"))
    circ_mm = sig(circ/u("mm"))
    chord_in = sig(chord/u("inches"))
    chord_mm = sig(chord/u("mm"))
    theta = sig(theta_deg)
    # Print report
    print('''
Chain-drilled {desired} input data:
    Desired {desired} diameter               = {dia_in} inches ({dia_mm} mm)
    Drill diameter                      = {chain_in} inches ({chain_mm} mm)
    Distance between drilled hole edges = {betw_hole_in} inches ({betw_hole_mm} mm)
    Allowance                           = {allow_in} inches ({allow_mm} mm)
  Results:
    Number of holes to drill            = {n}
    Angle between holes                 = {theta} deg
    Minimum material between holes      = {matl_betw_in} inches ({matl_betw_mm} mm)
  Information to lay out chain holes:
    Circle for chain hole centers       = {circ_in} inches ({circ_mm} mm)
    Divider setting for hole layout     = {chord_in} inches ({chord_mm} mm)
'''[1:-1].format(**locals()))

if __name__ == "__main__":
    d = {}
    ParseCommandLine(d)
    if 1:
        GetInfo(d)
    else:
        # Debugging:  5 inch diameter, 1/4 inch diameter drill, 0.1 inches
        # between hole edges, and 0.05 from final diameter.
        factor = u("inches")
        d["hole_diameter"] = factor*5
        d["dist_betw_holes"] = factor*0.1
        d["desired"] = "hole"
        d["chain_drill"] = factor*0.25
        d["allowance"] = factor*0.05
    Chain(d)
