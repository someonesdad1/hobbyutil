'''
vim: sw=4 ts=4
$Id: iapws95.py 1.15 2005/11/23 18:37:19 donp Exp $

The thermodynamic properties of water calculated with the 
IAPWS95 equations.  Variables and units:
    
    T       Temperature, K
    rho     Density, kg/m^3
    rhop    Saturated liquid density, kg/m^3
    rhopp   Saturated vapor density, kg/m^3
    p       Pressure, MPa
    u       Specific internal energy, kJ/kg
    h       Specific enthalpy, kJ/kg
    s       Specific entropy, kJ/(kg*K)
    cv      Isochoric specific heat, kJ/(kg*K)
    cp      Isobaric specific heat, kJ/(kg*K)
    w       Speed of sound, m/s

References:

    [1] The International Association for the Properties of
        Water and Steam, "Release on the IAPWS Formulation 1995
        for the Thermodynamic Properties of Ordinary Water
        Substance for General and Scientific Use", dated
        September 1996, Fredericia, Denmark.  See the "Releases"
        section of the website http://www.iapws.org/.

    [2] NIST Chemistry Webbook:  
        http://webbook.nist.gov/chemistry/fluid/

    [3] The International Association for the Properties of
        Water and Steam, "Revised Supplementary Release on 
        Saturation Properties of Ordinary Water Substance",
        dated September 1992, St. Petersburg, Russia.  See
        http://iapws.org/relguide/supsat.pdf.
----------------------------------------------------------------------

Copyright (C) Don Peterson 2004

This program is free software; you can redistribute it
and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE.  See the GNU General Public License for more
details.

You should have received a copy of the GNU General Public
License along with this program; if not, write to the Free
Software Foundation, Inc., 59 Temple Place, Suite 330,
Boston, MA 02111-1307  USA

'''

from __future__ import division
from math import log, exp, sqrt, fabs
from string import strip
import pdb
xx = pdb.set_trace

mark = 0
mark_file = None
mark_stream = None

# ----------------------------------------------------------------------

def Marker(message, done=0):
    global mark_stream
    if done:
        mark_stream.close()
    if not done and mark_stream == None:
        mark_stream = open(mark_file, "w")
    if not done:
        mark_stream.write("%s\n" % message)

# ----------------------------------------------------------------------

class Water95:
    def __init__(self):
        # Universal gas constant in kJ/(kg*K)
        self.R    = 0.46151805 
        # Critical temperature of water in K
        self.Tc   = 647.096
        # Critical pressure of water in MPa
        self.pc   = 22.064
        # Critical density of water in kg/m^3
        self.rhoc = 322
        # Minimum temperature for saturation calculations in K
        self.Tsat_min = 273.16
        # Maximum temperature for saturation calculations in K
        self.Tsat_max = 647.096
        # Coefficients for the various approximation equations
        self.n0 = (
            0.0,  
            -8.32044648201, 6.6832105268, 3.00632, 0.012436, 
            0.97315, 1.27950, 0.96956, 0.24873
        )
        self.gamma0 = (
            0, 0, 0, 0,
            1.28728967,
            3.53734222,
            7.74073708,
            9.24437796,
            27.5075105
        )
        self.n = ( 0,
            0.12533547935523e-1,  0.78957634722828e+1, -0.87803203303561e+1,
            0.31802509345418e+0, -0.26145533859358e+0, -0.78199751687981e-2,
            0.88089493102134e-2, -0.66856572307965e+0,  0.20433810950965e+0,
           -0.66212605039687e-4, -0.19232721156002e+0, -0.25709043003438e+0,
            0.16074868486251e+0, -0.40092828925807e-1,  0.39343422603254e-6,
           -0.75941377088144e-5,  0.56250979351888e-3, -0.15608652257135e-4,
            0.11537996422951e-8,  0.36582165144204e-6, -0.13251180074668e-11,
           -0.62639586912454e-9, -0.10793600908932e+0,  0.17611491008752e-1,
            0.22132295167546e+0, -0.40247669763528e+0,  0.58083399985759e+0,
            0.49969146990806e-2, -0.31358700712549e-1, -0.74315929710341e+0,
            0.47807329915480e+0,  0.20527940895948e-1, -0.13636435110343e+0,
            0.14180634400617e-1,  0.83326504880713e-2, -0.29052336009585e-1,
            0.38615085574206e-1, -0.20393486513704e-1, -0.16554050063734e-2,
            0.19955571979541e-2,  0.15870308324157e-3, -0.16388568342530e-4,
            0.43613615723811e-1,  0.34994005463765e-1, -0.76788197844621e-1,
            0.22446277332006e-1, -0.62689710414685e-4, -0.55711118565645e-9,
           -0.19905718354408e+0,  0.31777497330738e+0, -0.11841182425981e+0,
           -0.31306260323435e+2,  0.31546140237781e+2, -0.25213154341695e+4,
           -0.14874640856724e+0,  0.31806110878444e+0
        )
        self.c = ( 
            0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
            1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 
            2, 2, 2, 3, 3, 3, 3, 4, 6, 6, 6, 6
        )
        self.d = ( 
            0,  1,  1,  1,  2,  2,  3,  4,  1,  1,  1,  2,  2,  3,  4,  
            4,  5,  7,  9, 10, 11, 13, 15,  1,  2,  2,  2,  3,  4,  4,
            4,  5,  6,  6,  7,  9,  9,  9,  9,  9, 10, 10, 12,  3,  4,
            4,  5, 14,  3,  6,  6,  6,  3,  3,  3
        )
        self.t = ( 0,
            -0.5,  0.875,  1,  0.5,  0.75,  0.375,  1,  4,  6, 12,  1,
            5,  4,  2, 13,  9,  3,  4, 11,  4, 13,  1,  7,  1,  9, 10,
           10,  3,  7, 10, 10,  6, 10, 10,  1,  2,  3,  4,  8,  6,  9,
            8, 16, 22, 23, 23, 10, 50, 44, 46, 50,  0,  1,  4
        )
        self.a = { 55 :   3.5,  56 :   3.5  }
        self.b = { 55 :   0.85, 56 :   0.95 }
        self.A = { 55 :   0.32, 56 :   0.32 }
        self.B = { 55 :   0.2,  56 :   0.2  }
        self.C = { 55 :  28,    56 :  32    }
        self.D = { 55 : 700,    56 : 800    }
        self.alpha = { 52 :  20,    53 :  20,    54 : 20     }
        self.beta  = { 52 : 150,    53 : 150,    54 : 250,  
                       55 :   0.3,  56 :   0.3               }
        self.gamma = { 52 :   1.21, 53 :   1.21, 54 :   1.25 }

        # Constants for saturation properties
        self.sa = (0,  -7.85951783,  1.84408259, -11.7866497,
                       22.6807411, -15.9618719,    1.80122502
        )
        self.sb = (0,  1.99274064,   1.09965342, -0.510839303,
                      -1.75493479, -45.5170352,  -6.74694450e5
        )
        self.sc = (0, -2.03150240, -2.68302940, -5.38626492,
                     -17.2991605, -44.7586581, -63.9201063
        )

    def phi0(self, delta, tau):
        assert(delta >= 0)
        assert(tau >= 0)
        if mark:  Marker("phi0")
        sum = 0
        for i in xrange(4, 9):
           sum += self.n0[i]*log(1-exp(-tau*self.gamma0[i]))
        sum += log(delta) + self.n0[1] + self.n0[2]*tau + self.n0[3]*log(tau)
        return sum

    def phi0delta(self, delta, tau):
        assert(delta >= 0)
        assert(tau >= 0)
        #if mark:  Marker("phi0delta")
        return 1.0/delta

    def phi0deltadelta(self, delta, tau):
        assert(delta >= 0)
        assert(tau >= 0)
        #if mark:  Marker("phi0deltadelta")
        return -1.0/(delta*delta)

    def phi0tau(self, delta, tau):
        assert(delta >= 0)
        assert(tau >= 0)
        if mark:  Marker("phi0tau")
        sum = self.n0[2] + self.n0[3]/tau
        for i in xrange(4, 9):
           sum += self.n0[i]*self.gamma0[i]*(1/(1-exp(-tau*self.gamma0[i])) - 1)
        return sum

    def phi0tautau(self, delta, tau):
        assert(delta >= 0)
        assert(tau >= 0)
        if mark:  Marker("phi0tautau")
        sum = -self.n0[3]/(tau*tau)
        for i in xrange(4, 9):
           a = exp(-tau*self.gamma0[i])
           b = 1-a
           sum -= self.n0[i]*self.gamma0[i]*self.gamma0[i]*a/(b*b)
        return sum

    def phi0deltatau(self, delta, tau):
        assert(delta >= 0)
        assert(tau >= 0)
        #if mark:  Marker("phi0deltatau")
        return 0.0

    def phir(self, delta, tau):
        assert(delta >= 0)
        assert(tau >= 0)
        if mark:  Marker("phir")
        sum = 0
        d = delta - 1
        t = tau - 1
        for i in xrange(1, 8):
            sum += self.n[i]*delta**self.d[i]*tau**self.t[i]
        for i in xrange(8, 52):
            sum += self.n[i]*delta**self.d[i]*tau**self.t[i]* \
                   exp(-delta**self.c[i])
        for i in xrange(52, 55):
            a = -self.alpha[i]*d*d - self.beta[i]* \
                (tau - self.gamma[i])*(tau - self.gamma[i])
            sum += self.n[i]*delta**self.d[i]*tau**self.t[i]*exp(a)
        for i in xrange(55, 57):
            psi = exp(-self.C[i]*d*d - self.D[i]*t*t)
            theta = 1 - tau + self.A[i]*(d*d)**(1/(2*self.beta[i]))
            Delta = theta*theta + self.B[i]*(d*d)**(self.a[i])
            sum += self.n[i]*Delta**self.b[i]*delta*psi
        return sum

    def phirdelta(self, delta, tau): 
        assert(delta >= 0)
        assert(tau >= 0)
        if mark:  Marker("phirdelta")
        sum = 0
        d = delta - 1
        t = tau - 1
        for i in xrange(1, 8):
            sum += self.n[i]*self.d[i]*delta**(self.d[i] - 1)*tau**self.t[i]
        for i in xrange(8, 52):
            sum += self.n[i]*exp(-delta**self.c[i])*(delta**(self.d[i]-1)* \
                   tau**self.t[i]*(self.d[i] - self.c[i]*delta**self.c[i]))
        for i in xrange(52, 55):
            a = tau - self.gamma[i]
            b = -self.alpha[i]*d*d - self.beta[i]*a*a
            sum += self.n[i]*delta**self.d[i]*tau**self.t[i]*exp(b)* \
                   (self.d[i]/delta - 2*self.alpha[i]*d)
        for i in xrange(55, 57):
            psi = exp(-self.C[i]*d*d - self.D[i]*t*t)
            theta = 1 - tau + self.A[i]*(d*d)**(1/(2*self.beta[i]))
            Delta = theta*theta + self.B[i]*(d*d)**(self.a[i])
            dpsiddelta = -2*self.C[i]*d*psi
            dDeltaddelta = d*(self.A[i]*theta*2/self.beta[i]* \
                (d*d)**(1/(2*self.beta[i]) - 1) + 2*self.B[i]*self.a[i]* \
                (d*d)**(self.a[i] - 1))
            dDeltabiddelta = self.b[i]*Delta**(self.b[i]-1)*dDeltaddelta
            sum += self.n[i]*(Delta**self.b[i]*(psi + delta*dpsiddelta) + \
                   dDeltabiddelta*delta*psi)
        return sum

    def phirdeltadelta(self, delta, tau):
        assert(delta >= 0)
        assert(tau >= 0)
        if mark:  Marker("phirdeltadelta")
        sum = 0
        d = delta - 1
        t = tau - 1
        for i in xrange(1, 8):
            sum += self.n[i]*self.d[i]*(self.d[i] - 1)* \
                   delta**(self.d[i]-2)*tau**self.t[i]
        for i in xrange(8, 52):
            sum += self.n[i]*exp(-delta**self.c[i])*(delta**(self.d[i]-2)* \
                   tau**self.t[i]*((self.d[i] - self.c[i]*delta**self.c[i])* \
                   (self.d[i]-1-self.c[i]*delta**self.c[i]) - \
                   self.c[i]*self.c[i]*delta**self.c[i]))
        for i in xrange(52, 55):
            a = tau - self.gamma[i]
            b = -self.alpha[i]*d*d - self.beta[i]*a*a
            sum += self.n[i]*tau**self.t[i]*exp(b)* \
                   (-2*self.alpha[i]*delta**self.d[i] + \
                   4*self.alpha[i]*self.alpha[i]*delta**self.d[i]*d*d - \
                   4*self.d[i]*self.alpha[i]*delta**(self.d[i]-1)*d + \
                   self.d[i]*(self.d[i]-1)*delta**(self.d[i]-1))
        for i in xrange(55, 57):
            psi = exp(-self.C[i]*d*d - self.D[i]*t*t)
            theta = 1 - tau + self.A[i]*(d*d)**(1/(2*self.beta[i]))
            Delta = theta*theta + self.B[i]*(d*d)**(self.a[i])
            dpsiddelta = -2*self.C[i]*d*psi
            dDeltaddelta = d*(self.A[i]*theta*2/self.beta[i]* \
                (d*d)**(1/(2*self.beta[i]) - 1) + 2*self.B[i]*self.a[i]* \
                (d*d)**(self.a[i] - 1))
            dDeltabiddelta = self.b[i]*Delta**(self.b[i]-1)*dDeltaddelta
            d2psiddelta2 = (2*self.C[i]*d*d - 1)*2*self.C[i]*psi
            d2Deltaddelta2 = 1/d*dDeltaddelta + d*d*(4*self.B[i]*self.a[i]* \
                (self.a[i]-1)*(d*d)**(self.a[i]-2) + 2*self.A[i]*self.A[i]* \
                (1/(self.beta[i]*self.beta[i]))* \
                ((d*d)**(1/(2*self.beta[i])-1))**2) + \
                self.A[i]*theta*4/self.beta[i]*(1/(2*self.beta[i]) - 1)* \
                (d*d)**(1/(2*self.beta[i]) - 2)
            d2Deltabiddelta2 = self.b[i]*(Delta**(self.b[i]-1) * \
                d2Deltaddelta2 + (self.b[i]-1)*Delta**(self.b[i]-2)* \
                dDeltaddelta*dDeltaddelta)
            sum += self.n[i]*(Delta**self.b[i]*(2*dpsiddelta + \
                   delta*d2psiddelta2) + 2*dDeltabiddelta*(psi + \
                   delta*dpsiddelta) + d2Deltabiddelta2*delta*psi)
        return sum

    def phirtau(self, delta, tau):
        assert(delta >= 0)
        assert(tau >= 0)
        if mark:  Marker("phirtau")
        sum = 0
        d = delta - 1
        t = tau - 1
        for i in xrange(1, 8):
            sum += self.n[i]*self.t[i]*delta**self.d[i]*tau**(self.t[i]-1)
        for i in xrange(8, 52):
                sum += self.n[i]*self.t[i]*delta**self.d[i]* \
                    tau**(self.t[i]-1)*exp(-delta**self.c[i])
        for i in xrange(52, 55):
            a = tau - self.gamma[i]
            b = -self.alpha[i]*d*d - self.beta[i]*a*a
            sum += self.n[i]*delta**self.d[i]*tau**self.t[i]*exp(b)* \
                   (self.t[i]/tau - 2*self.beta[i]*(tau - self.gamma[i]))
        for i in xrange(55, 57):
            psi = exp(-self.C[i]*d*d - self.D[i]*t*t)
            theta = 1 - tau + self.A[i]*(d*d)**(1/(2*self.beta[i]))
            Delta = theta*theta + self.B[i]*(d*d)**(self.a[i])
            dDeltabidtau = -2*theta*self.b[i]*Delta**(self.b[i]-1)
            dpsidtau = -2*self.D[i]*t*psi
            sum += self.n[i]*delta*(dDeltabidtau*psi + \
                   Delta**self.b[i]*dpsidtau)
        return sum

    def phirtautau(self, delta, tau):
        assert(delta >= 0)
        assert(tau >= 0)
        if mark:  Marker("phirtautau")
        sum = 0
        d = delta - 1
        t = tau - 1
        for i in xrange(1, 8):
            sum += self.n[i]*self.t[i]*(self.t[i]-1)*delta**self.d[i]* \
                   tau**(self.t[i]-2)
        for i in xrange(8, 52):
            sum += self.n[i]*self.t[i]*(self.t[i]-1)*delta**self.d[i]* \
                   tau**(self.t[i]-2)*exp(-delta**self.c[i])
        for i in xrange(52, 55):
            a = tau - self.gamma[i]
            b = -self.alpha[i]*d*d - self.beta[i]*a*a
            sum += self.n[i]*delta**self.d[i]*tau**self.t[i]*exp(b)* \
                   ((self.t[i]/tau - 2*self.beta[i]*a)**2 - \
                   self.t[i]/(tau*tau) - 2*self.beta[i])
        for i in xrange(55, 57):
            psi = exp(-self.C[i]*d*d - self.D[i]*t*t)
            theta = 1 - tau + self.A[i]*(d*d)**(1/(2*self.beta[i]))
            Delta = theta*theta + self.B[i]*(d*d)**(self.a[i])
            dDeltabidtau = -2*theta*self.b[i]*Delta**(self.b[i]-1)
            d2Deltabidtau2 = 2*self.b[i]*Delta**(self.b[i]-1) + \
                4*theta*theta*self.b[i]*(self.b[i]-1)*Delta**(self.b[i]-2)
            dpsidtau = -2*self.D[i]*t*psi
            d2psidtau2 = (2*self.D[i]*t*t - 1)*2*self.D[i]*psi
            sum += self.n[i]*delta*(d2Deltabidtau2*psi + \
                   2*dDeltabidtau*dpsidtau + Delta**self.b[i]*d2psidtau2)
        return sum

    def phirdeltatau(self, delta, tau):
        assert(delta >= 0)
        assert(tau >= 0)
        if mark:  Marker("phirdeltatau")
        sum = 0
        d = delta - 1
        t = tau - 1
        for i in xrange(1, 8):
            sum += self.n[i]*self.d[i]*self.t[i]*delta**(self.d[i]-1)* \
                   tau**(self.t[i]-1)
        for i in xrange(8, 52):
            sum += self.n[i]*self.t[i]*delta**(self.d[i]-1)* \
                   tau**(self.t[i]-1)*(self.d[i] - self.c[i]* \
                   delta**self.c[i])*exp(-delta**self.c[i])
        for i in xrange(52, 55):
            a = tau - self.gamma[i]
            b = -self.alpha[i]*d*d - self.beta[i]*a*a
            sum += self.n[i]*delta**self.d[i]*tau**self.t[i]*exp(b)* \
                   (self.d[i]/delta - 2*self.alpha[i]*d)* \
                   (self.t[i]/tau - 2*self.beta[i]*a)
        for i in xrange(55, 57):
            psi = exp(-self.C[i]*d*d - self.D[i]*t*t)
            theta = 1 - tau + self.A[i]*(d*d)**(1/(2*self.beta[i]))
            Delta = theta*theta + self.B[i]*(d*d)**(self.a[i])
            dDeltabidtau = -2*theta*self.b[i]*Delta**(self.b[i]-1)
            dpsidtau = -2*self.D[i]*t*psi
            dDeltaddelta = d*(self.A[i]*theta*2/self.beta[i]* \
                (d*d)**(1/(2*self.beta[i]) - 1) + 2*self.B[i]*self.a[i]* \
                (d*d)**(self.a[i] - 1))
            d2psiddeltadtau = 4*self.C[i]*self.D[i]*d*t*psi
            dDeltabiddelta = self.b[i]*Delta**(self.b[i]-1)*dDeltaddelta
            dpsiddelta = -2*self.C[i]*d*psi
            d2Deltabiddeltadtau = -self.A[i]*self.b[i]*2/self.beta[i]* \
                Delta**(self.b[i]-1)*d*(d*d)**(1/(2*self.beta[i])-1) - \
                2*theta*self.b[i]*(self.b[i]-1)*Delta**(self.b[i]-2)* \
                dDeltaddelta
            sum += self.n[i]*(Delta**self.b[i]*(dpsidtau + delta* \
                   d2psiddeltadtau) + delta*dDeltabiddelta*dpsidtau + \
                   dDeltabidtau*(psi + delta*dpsiddelta) + \
                   d2Deltabiddeltadtau*delta*psi)
        return sum

    def _get_delta_tau(self, T, rho):
        return rho/self.rhoc, self.Tc/T

    def p(self, T, rho):
        if mark:  Marker("p")
        delta, tau = self._get_delta_tau(T, rho)
        p = rho*self.R*T*(1 + delta*self.phirdelta(delta, tau))
        assert(p > 0)
        return p

    def u(self, T, rho):
        if mark:  Marker("u")
        delta, tau = self._get_delta_tau(T, rho)
        u = self.R*T*tau*(self.phi0tau(delta, tau) + \
            self.phirtau(delta, tau))
        assert(u > 0)
        return u

    def h(self, T, rho):
        if mark:  Marker("h")
        delta, tau = self._get_delta_tau(T, rho)
        h = self.R*T*(1 + tau*(self.phi0tau(delta, tau) + \
            self.phirtau(delta, tau)) + delta*self.phirdelta(delta, tau))
        assert(h > 0)
        return h

    def s(self, T, rho):
        if mark:  Marker("s")
        delta, tau = self._get_delta_tau(T, rho)
        s = self.R*(tau*(self.phi0tau(delta, tau) + \
            self.phirtau(delta, tau)) - \
            self.phi0(delta, tau) - self.phir(delta, tau))
        assert(s > 0)
        return s

    def cv(self, T, rho):
        if mark:  Marker("cv")
        delta, tau = self._get_delta_tau(T, rho)
        cv = -self.R*tau*tau*(self.phi0tautau(delta, tau) + \
              self.phirtautau(delta, tau))
        assert(cv > 0)
        return cv

    def cp(self, T, rho):
        if mark:  Marker("cp")
        delta, tau = self._get_delta_tau(T, rho)
        a = 1 + delta*self.phirdelta(delta, tau) - \
            delta*tau*self.phirdeltatau(delta, tau)
        b = 1 + 2*delta*self.phirdelta(delta, tau) + \
            delta*delta*self.phirdeltadelta(delta, tau)
        cp = self.R*(-tau*tau*(self.phi0tautau(delta, tau) + \
             self.phirtautau(delta, tau)) + a*a/b)
        assert(cp > 0)
        return cp

    def w(self, T, rho):
        if mark:  Marker("w")
        delta, tau = self._get_delta_tau(T, rho)
        a = 1 + delta*self.phirdelta(delta, tau) - \
            delta*tau*self.phirdeltatau(delta, tau)
        b = tau*tau*(self.phi0tautau(delta, tau) + \
            self.phirtautau(delta, tau))
        w = 1 + 2*delta*self.phirdelta(delta, tau) + \
            delta*delta*self.phirdeltadelta(delta, tau) - a*a/b
        w = sqrt(self.R*T*w*1000)
        assert(w > 0)
        return w

    # These three functions will each return 0 for psat, rhop, and
    # rhopp having correct values for a given T.
    def _eq1(self, T, psat, rhop, rhopp):
        assert(psat > 0 and rhop > 0 and rhopp > 0)
        return psat/(self.R*T*rhop) - 1 - \
                rhop*self.phirdelta(rhop/self.rhoc, self.Tc/T)
    def _eq2(self, T, psat, rhop, rhopp):
        assert(psat > 0 and rhop > 0 and rhopp > 0)
        return psat/(self.R*T*rhopp) - 1 - \
                rhopp*self.phirdelta(rhopp/self.rhoc, self.Tc/T)
    def _eq3(self, T, psat, rhop, rhopp):
        tau = self.Tc/T
        assert(psat > 0 and rhop > 0 and rhopp > 0)
        return psat/(self.R*T)*(1/rhopp - 1/rhop) - \
                log(rhop/rhopp) - self.phir(rhop/self.rhoc, tau) + \
                self.phir(rhopp/self.rhoc, tau)

    def sat_p(self, T):
        '''Returns the saturation pressure at temperature T.  From
        equation 1 of ref. [3].
        '''
        assert(self.Tsat_min <= T <= self.Tsat_max)
        tau = 1 - T/self.Tc
        f = self.Tc/T*(self.sa[1]*tau + self.sa[2]*tau**1.5 + \
                       self.sa[3]*tau**3 + self.sa[4]*tau**3.5 + \
                       self.sa[5]*tau**4 + self.sa[6]*tau**7.5)
        p = self.pc*exp(f)
        assert(p > 0)
        return p

    def sat_rhop(self, T):
        '''Returns the saturated liquid density at temperature T.  
        From equation 2 of ref. [3].
        '''
        assert(self.Tsat_min <= T <= self.Tsat_max)
        tau = 1 - T/self.Tc
        f = 1 + self.sb[1]*tau**(1/3) + self.sb[2]*tau**(2/3) + \
                self.sb[3]*tau**(5/3) + self.sb[4]*tau**(16/3) + \
                self.sb[5]*tau**(43/3) + self.sb[6]*tau**(110/3)
        rhop = self.rhoc*f
        assert(rhop > 0)
        return rhop

    def sat_rhopp(self, T):
        '''Returns the saturated vapor density at temperature T.  
        From equation 3 of ref. [3].
        '''
        assert(self.Tsat_min <= T <= self.Tsat_max)
        tau = 1 - T/self.Tc
        f = self.sc[1]*tau**(1/3) + self.sc[2]*tau**(2/3) + \
            self.sc[3]*tau**(4/3) + self.sc[4]*tau**3 + \
            self.sc[5]*tau**(37/6) + self.sc[6]*tau**(71/6)
        rhopp = self.rhoc*exp(f)
        assert(rhopp > 0)
        return rhopp
