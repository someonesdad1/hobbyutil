# Unit tests for iapws95.py and iapws97.py modules.  Returns 0 if
# successful.

# Note:  The iapws97.py module is not currently working, so the test
# is not run.

# vim: sw=4 ts=4

from __future__ import division
from math import fabs
from string import find, strip, split
import sys, string
import iapws95 #, iapws97

# Set to true if the untested region listing is desired
show_untested = 1

# ---------------------------------------------------------------------- 
# Utility functions

def PctDiff(a, b):
    '''Return the percent difference between a and b.
    '''
    if a == 0 and b == 0:
        return 0.0
    return fabs(100.0*(a-b)/b)

def ReadDataFile(name):
    '''Read the indicated file, removing any lines beginning with '#'.
    Then parse each line into a tuple.  The first line of the tuple
    will contain strings describing each column.  The input file is
    expected to be tab separated.
    '''
    lines = open(name).readlines()
    data = []
    for line in lines:
        line = strip(line)
        if find(line, "#") == 0:
            continue
        data.append(tuple(split(line, "\t")))
    return data

def GetUntestedChunks(name_source_file, marks_file):
    "Return a list of untested chunks"
    import re
    # Get the messages written to the file
    found = {}
    for line in open(marks_file).readlines():
        found[strip(line)] = 0
    # Get all the marked lines in the source file
    source_file = {}
    match_line = re.compile(r"^\s*if mark:  Marker\(\"(.*)\"\)\s*$")
    lines = open(name_source_file).readlines()
    for line_number in xrange(len(lines)):
        mo = match_line.search(lines[line_number])
        if mo:
            source_file[mo.group(1)] = line_number
    # Remove any messages found in found from the source_file dictionary
    for key in found.keys():
        del source_file[key]
    # Any remaining items in source_file weren't executed
    list = source_file.keys()
    list.sort()
    if list:
        out = []
        for item in list:
            out.append((source_file[item], item))
        out.sort()
        return out
    return []

def PrintUntestedChunks(source_file, marks_file):
    list = GetUntestedChunks(source_file, marks_file)
    if list:
        print "Chunks not executed in testing (%s):" % source_file
        for item in list:
            print"  %4d  %s" % (item[0], item[1])

# ---------------------------------------------------------------------- 
# Test the IAPWS95 General and Scientific Model.

def TestIAPWS95():
    w = iapws95.Water95()
    # Temperature and density for Table 6
    T = 500       # K
    rho = 838.025 # kg/m^3
    def TestIdealGasPart():
        # Test that we match Table 6 values.  Note the phi0tautau
        # expected value is negative, as it has to be, although the
        # table gives it as positive.
        pairs = ( # Functions and their expected values
            (w.phi0(          rho/w.rhoc, w.Tc/T),  0.204797734e+1),
            (w.phi0delta(     rho/w.rhoc, w.Tc/T),  0.384236747e+0),
            (w.phi0deltadelta(rho/w.rhoc, w.Tc/T), -0.147637878e+0),
            (w.phi0tau(       rho/w.rhoc, w.Tc/T),  0.904611106e+1),
            (w.phi0tautau(    rho/w.rhoc, w.Tc/T), -0.193249185e+1),
            (w.phi0deltatau(  rho/w.rhoc, w.Tc/T),  0.000000000e+0)
        )
        eps = 0.0001
        for value, expected in pairs:
            assert(PctDiff(value, expected) < eps)
    def TestRealGasPart():
        # Test that we match Table 6 values
        pairs = ( # Functions and their expected values
            (w.phir(          rho/w.rhoc, w.Tc/T), -0.342693206e+1),
            (w.phirdelta(     rho/w.rhoc, w.Tc/T), -0.364366650e+0),
            (w.phirdeltadelta(rho/w.rhoc, w.Tc/T),  0.856063701e+0),
            (w.phirtau(       rho/w.rhoc, w.Tc/T), -0.581403435e+1),
            (w.phirtautau(    rho/w.rhoc, w.Tc/T), -0.223440737e+1),
            (w.phirdeltatau(  rho/w.rhoc, w.Tc/T), -0.112176915e+1)
        )
        eps = 0.0001
        for value, expected in pairs:
            assert(PctDiff(value, expected) < eps)
    def TestSinglePhaseRegion():
        # Values from Table 7
        set_of_test_values = (
            #Temp   Density       Pressure     Isochoric Sp. Ht  Spd of Sound       Entropy
            # K     kg/m^3           MPa          kJ/(kg*K)          m/s           kJ/(kg*K)
            # T       rho             p              cv               w                s
            (300, 0.9965560e+3, 0.99242e-1    , 0.413018111e+1, 0.150151914e+4, 0.393062642e+0),
            (300, 0.1005308e+4, 0.200022514e+2, 0.406798347e+1, 0.153492501e+4, 0.387405401e+0),
            (300, 0.1188202e+4, 0.700004704e+3, 0.346135580e+1, 0.244357992e+4, 0.132609616e+0),
            (500, 0.4350000e+0, 0.999679423e-1, 0.150817541e+1, 0.548314253e+3, 0.794488271e+1),
            (500, 0.4532000e+1, 0.999938125e+0, 0.166991025e+1, 0.535739001e+3, 0.682502725e+1),
            (500, 0.8380250e+3, 0.100003858e+2, 0.322106219e+1, 0.127128441e+4, 0.256690918e+1),
            (500, 0.1084564e+4, 0.700000405e+3, 0.307437693e+1, 0.241200877e+4, 0.203237509e+1),
            (647, 0.3580000e+3, 0.220384756e+2, 0.618315728e+1, 0.252145078e+3, 0.432092307e+1),
            (900, 0.2410000e+0, 0.100062559e+0, 0.175890657e+1, 0.724027147e+3, 0.916653194e+1),
            (900, 0.5261500e+2, 0.200000690e+2, 0.193510526e+1, 0.698445674e+3, 0.659070225e+1),
            (900, 0.8707690e+3, 0.700000006e+3, 0.266422350e+1, 0.201933608e+4, 0.417223802e+1),
        )
        for T, rho, p_e, cv_e, w_e, s_e in set_of_test_values:
            if T == 647:
                # Precision at the critical point is much less
                eps = 0.2
            else:
                eps = 0.0002
            assert(PctDiff(w.p(T, rho)/1000, p_e) < eps)
            assert(PctDiff(w.cv(T, rho), cv_e) < eps)
            assert(PctDiff(w.w(T, rho), w_e) < eps)
            assert(PctDiff(w.s(T, rho), s_e) < eps)
        # Tests for u and h came from NIST webpage at
        # http://webbook.nist.gov/chemistry/fluid/
        set_of_test_values = (
            # T    rho      u       h       cp
            (350, 973.70, 321.75, 321.79,  4.1946),  # Liquid
            (400, 937.49, 532.69, 532.95,  4.2555),  # Liquid
            (440, 900.65, 704.50, 705.31,  4.3571),  # Liquid
            (350, 0.26029, 2477.6, 2637.7, 2.0033),  # Vapor
            (400, 1.3694,  2536.2, 2715.7, 2.2183),  # Vapor
            (500, 4.5320,  2670.6, 2891.2, 2.2795),  # Vapor
        )
        eps = 0.0025
        for T, rho, u_e, h_e, cp_e in set_of_test_values:
            assert(PctDiff(w.u(T, rho), u_e) < eps)
            assert(PctDiff(w.h(T, rho), h_e) < eps)
            assert(PctDiff(w.cp(T, rho), cp_e) < eps)
    def TestTwoPhaseRegion():
        # Test values from Table 8
        set_of_test_values = (
            # Tsat  psat            rhop            rhopp 
            #       hp              hpp             sp 
            #       spp
            (275, 0.698451167e-3, 0.999887406e+3, 0.550664919e-2,
                  0.775972200e+1, 0.250428995e+4, 0.283094669e-1,
                  0.910660120e+1),
            (450, 0.932203564e+0, 0.890341250e+3, 0.481200360e+1,
                  0.749161585e+3, 0.277441078e+4, 0.210865845e+1,
                  0.660921221e+1),
            (625, 0.169082693e+2, 0.567090385e+3, 0.118290280e+3,
                  0.168626976e+4, 0.255071625e+4, 0.380194683e+1,
                  0.518506121e+1)
        )
        for Tsat, psat, rhop, rhopp, hp, hpp, sp, spp in  set_of_test_values:
            pass
        print "** Two Phase code not working yet **"
    mark_file = "iapws95.marks"
    iapws95.mark_file = mark_file
    source_file = "iapws95.py"
    iapws95.mark = 1
    TestIdealGasPart()
    TestRealGasPart()
    TestSinglePhaseRegion()
   #TestTwoPhaseRegion()
    iapws95.Marker("", done=1)
    if show_untested:
        PrintUntestedChunks(source_file, mark_file)
    else:
        num_untested = len(GetUntestedChunks(source_file, mark_file))
        if num_untested == 1:
            print "%s:  1 untested chunk" % source_file
        elif num_untested > 1:
            print "%s:  %d untested chunks" % (source_file, num_untested)

# ---------------------------------------------------------------------- 
def TestIAPWS95():
    w = iapws95.Water95()
    # Temperature and density for Table 6
    T = 500       # K
    rho = 838.025 # kg/m^3
    def TestIdealGasPart():
        # Test that we match Table 6 values.  Note the phi0tautau
        # expected value is negative, as it has to be, although the
        # table gives it as positive.
        pairs = ( # Functions and their expected values
            (w.phi0(          rho/w.rhoc, w.Tc/T),  0.204797734e+1),
            (w.phi0delta(     rho/w.rhoc, w.Tc/T),  0.384236747e+0),
            (w.phi0deltadelta(rho/w.rhoc, w.Tc/T), -0.147637878e+0),
            (w.phi0tau(       rho/w.rhoc, w.Tc/T),  0.904611106e+1),
            (w.phi0tautau(    rho/w.rhoc, w.Tc/T), -0.193249185e+1),
            (w.phi0deltatau(  rho/w.rhoc, w.Tc/T),  0.000000000e+0)
        )
        eps = 0.0001
        for value, expected in pairs:
            assert(PctDiff(value, expected) < eps)
    def TestRealGasPart():
        # Test that we match Table 6 values
        pairs = ( # Functions and their expected values
            (w.phir(          rho/w.rhoc, w.Tc/T), -0.342693206e+1),
            (w.phirdelta(     rho/w.rhoc, w.Tc/T), -0.364366650e+0),
            (w.phirdeltadelta(rho/w.rhoc, w.Tc/T),  0.856063701e+0),
            (w.phirtau(       rho/w.rhoc, w.Tc/T), -0.581403435e+1),
            (w.phirtautau(    rho/w.rhoc, w.Tc/T), -0.223440737e+1),
            (w.phirdeltatau(  rho/w.rhoc, w.Tc/T), -0.112176915e+1)
        )
        eps = 0.0001
        for value, expected in pairs:
            assert(PctDiff(value, expected) < eps)
    def TestSinglePhaseRegion():
        # Values from Table 7
        set_of_test_values = (
            #Temp   Density       Pressure     Isochoric Sp. Ht  Spd of Sound       Entropy
            # K     kg/m^3           MPa          kJ/(kg*K)          m/s           kJ/(kg*K)
            # T       rho             p              cv               w                s
            (300, 0.9965560e+3, 0.99242e-1    , 0.413018111e+1, 0.150151914e+4, 0.393062642e+0),
            (300, 0.1005308e+4, 0.200022514e+2, 0.406798347e+1, 0.153492501e+4, 0.387405401e+0),
            (300, 0.1188202e+4, 0.700004704e+3, 0.346135580e+1, 0.244357992e+4, 0.132609616e+0),
            (500, 0.4350000e+0, 0.999679423e-1, 0.150817541e+1, 0.548314253e+3, 0.794488271e+1),
            (500, 0.4532000e+1, 0.999938125e+0, 0.166991025e+1, 0.535739001e+3, 0.682502725e+1),
            (500, 0.8380250e+3, 0.100003858e+2, 0.322106219e+1, 0.127128441e+4, 0.256690918e+1),
            (500, 0.1084564e+4, 0.700000405e+3, 0.307437693e+1, 0.241200877e+4, 0.203237509e+1),
            (647, 0.3580000e+3, 0.220384756e+2, 0.618315728e+1, 0.252145078e+3, 0.432092307e+1),
            (900, 0.2410000e+0, 0.100062559e+0, 0.175890657e+1, 0.724027147e+3, 0.916653194e+1),
            (900, 0.5261500e+2, 0.200000690e+2, 0.193510526e+1, 0.698445674e+3, 0.659070225e+1),
            (900, 0.8707690e+3, 0.700000006e+3, 0.266422350e+1, 0.201933608e+4, 0.417223802e+1),
        )
        for T, rho, p_e, cv_e, w_e, s_e in set_of_test_values:
            if T == 647:
                # Precision at the critical point is much less
                eps = 0.2
            else:
                eps = 0.0002
            assert(PctDiff(w.p(T, rho)/1000, p_e) < eps)
            assert(PctDiff(w.cv(T, rho), cv_e) < eps)
            assert(PctDiff(w.w(T, rho), w_e) < eps)
            assert(PctDiff(w.s(T, rho), s_e) < eps)
        # Tests for u and h came from NIST webpage at
        # http://webbook.nist.gov/chemistry/fluid/
        set_of_test_values = (
            # T    rho      u       h       cp
            (350, 973.70, 321.75, 321.79,  4.1946),  # Liquid
            (400, 937.49, 532.69, 532.95,  4.2555),  # Liquid
            (440, 900.65, 704.50, 705.31,  4.3571),  # Liquid
            (350, 0.26029, 2477.6, 2637.7, 2.0033),  # Vapor
            (400, 1.3694,  2536.2, 2715.7, 2.2183),  # Vapor
            (500, 4.5320,  2670.6, 2891.2, 2.2795),  # Vapor
        )
        eps = 0.0025
        for T, rho, u_e, h_e, cp_e in set_of_test_values:
            assert(PctDiff(w.u(T, rho), u_e) < eps)
            assert(PctDiff(w.h(T, rho), h_e) < eps)
            assert(PctDiff(w.cp(T, rho), cp_e) < eps)
    def TestTwoPhaseRegion():
        # Test values from Table 8
        set_of_test_values = (
            # Tsat  psat            rhop            rhopp 
            #       hp              hpp             sp 
            #       spp
            (275, 0.698451167e-3, 0.999887406e+3, 0.550664919e-2,
                  0.775972200e+1, 0.250428995e+4, 0.283094669e-1,
                  0.910660120e+1),
            (450, 0.932203564e+0, 0.890341250e+3, 0.481200360e+1,
                  0.749161585e+3, 0.277441078e+4, 0.210865845e+1,
                  0.660921221e+1),
            (625, 0.169082693e+2, 0.567090385e+3, 0.118290280e+3,
                  0.168626976e+4, 0.255071625e+4, 0.380194683e+1,
                  0.518506121e+1)
        )
        # Allowed percent differences from table values.  Note these
        # are set just above the point that the assertion will fail.
        # The calculations are actually being done by the equations in
        # reference [3] in iapws95.py; they are not from solution of
        # the Maxwell equilibrium criterion as given in the IAPWS95
        # paper.
        p_eps     = 0.0025
        rhop_eps  = 0.043
        rhopp_eps = 0.042
        hp_eps    = 0.080
        hpp_eps   = 0.0087
        sp_eps    = 0.012
        spp_eps   = 0.0074
        for T, p, rhop, rhopp, hp, hpp, sp, spp in set_of_test_values:
            assert(PctDiff(w.sat_p(T), p)               < p_eps)
            assert(PctDiff(w.sat_rhop(T), rhop)         < rhop_eps)
            assert(PctDiff(w.sat_rhopp(T), rhopp)       < rhopp_eps)
            assert(PctDiff(w.h(T, w.sat_rhop(T)), hp)   < hp_eps)
            assert(PctDiff(w.h(T, w.sat_rhopp(T)), hpp) < hpp_eps)
            assert(PctDiff(w.s(T, w.sat_rhop(T)), sp)   < sp_eps)
            assert(PctDiff(w.s(T, w.sat_rhopp(T)), spp) < spp_eps)
    def Ref3Data():
        '''Test saturation properties from data in [3].
        '''
        data = (
            # T           p          rhop     rhopp
            (273.16,   611.657e-6, 999.789,  0.00485426),
            (373.1243,   0.101325, 958.365,  0.597586),
            (647.096,    w.pc,       w.rhoc, w.rhoc),
        )
        eps = 0.0001
        for T, p, rhop, rhopp in data:
            assert(PctDiff(w.sat_p(T), p)         < eps)
            assert(PctDiff(w.sat_rhop(T), rhop)   < eps)
            assert(PctDiff(w.sat_rhopp(T), rhopp) < eps)
    file = "iapws95"
    mark_file = file + ".marks"
    iapws95.mark_file = mark_file
    source_file = file + ".py"
    iapws95.mark = 1
    TestIdealGasPart()
    TestRealGasPart()
    TestSinglePhaseRegion()
    TestTwoPhaseRegion()
    Ref3Data()
    iapws95.Marker("", done=1)
    if show_untested:
        PrintUntestedChunks(source_file, mark_file)
    else:
        num_untested = len(GetUntestedChunks(source_file, mark_file))
        if num_untested == 1:
            print "%s:  1 untested chunk" % source_file
        elif num_untested > 1:
            print "%s:  %d untested chunks" % (source_file, num_untested)

# ---------------------------------------------------------------------- 
# Test the industrial model IAPWS97

def TestIAPWS97():
    def TestRegion1():
        '''Test Cases:
        1.  Recommended test values from IAPWS paper [1], page 9
        '''
        r = iapws97.Region1()
        eps = 0.001 # Allowed % difference published values
        # The published values came from reference 1, page 9
        # Column 1 test cases
        T = 300  # K
        p = 3    # MPa
        assert(PctDiff( r.v(T, p), 0.100215168e-2) < eps)
        assert(PctDiff( r.h(T, p), 0.115331273e+3) < eps)
        assert(PctDiff( r.u(T, p), 0.112324818e+3) < eps)
        assert(PctDiff( r.s(T, p), 0.392294792e+0) < eps)
        assert(PctDiff(r.cp(T, p), 0.417301218e+1) < eps)
        #assert(PctDiff( r.w(T, p), 0.150773921e+4) < eps)
        # Column 2 test cases
        T = 300  # K
        p = 80   # MPa
        assert(PctDiff( r.v(T, p), 0.971180894e-3) < eps)
        assert(PctDiff( r.h(T, p), 0.184142828e+3) < eps)
        assert(PctDiff( r.u(T, p), 0.106448356e+3) < eps)
        assert(PctDiff( r.s(T, p), 0.368563852e+0) < eps)
        assert(PctDiff(r.cp(T, p), 0.401008987e+1) < eps)
        #assert(PctDiff( r.w(T, p), 0.163469054e+4) < eps)
        # Column 3 test cases
        T = 500  # K
        p = 3    # MPa
        assert(PctDiff( r.v(T, p), 0.120241800e-2) < eps)
        assert(PctDiff( r.h(T, p), 0.975542239e+3) < eps)
        assert(PctDiff( r.u(T, p), 0.971934985e+3) < eps)
        assert(PctDiff( r.s(T, p), 0.258041912e+1) < eps)
        assert(PctDiff(r.cp(T, p), 0.465580682e+1) < eps)
        #assert(PctDiff( r.w(T, p), 0.124071337e+4) < eps)
    def TestRegion2():
        '''Test Cases:
        1.  Recommended test values from IAPWS paper [1], page 17
        '''
        r = iapws97.Region2()
        eps = 0.001 # Allowed % difference published values
        # The published values came from reference 1, page 17
        # Column 1 test cases
        T = 300    # K
        p = 0.0035 # MPa
        assert(PctDiff( r.v(T, p), 0.394913866e+2) < eps)
        assert(PctDiff( r.h(T, p), 0.254991145e+4) < eps)
        assert(PctDiff( r.u(T, p), 0.241169160e+4) < eps)
        assert(PctDiff( r.s(T, p), 0.852238967e+1) < eps)
        assert(PctDiff(r.cp(T, p), 0.191300162e+1) < eps)
        #assert(PctDiff( r.w(T, p), 0.427920172e+3) < eps)
        # Column 2 test cases
        T = 700  # K
        p = 0.0035 # MPa
        assert(PctDiff( r.v(T, p), 0.923015898e+2) < eps)
        assert(PctDiff( r.h(T, p), 0.333568375e+4) < eps)
        assert(PctDiff( r.u(T, p), 0.301262819e+4) < eps)
        assert(PctDiff( r.s(T, p), 0.101749996e+2) < eps)
        assert(PctDiff(r.cp(T, p), 0.208141274e+1) < eps)
        #assert(PctDiff( r.w(T, p), 0.644289068e+3) < eps)
        # Column 3 test cases
        T = 700  # K
        p = 30   # MPa
        assert(PctDiff( r.v(T, p), 0.542946619e-2) < eps)
        assert(PctDiff( r.h(T, p), 0.263149474e+4) < eps)
        assert(PctDiff( r.u(T, p), 0.246861076e+4) < eps)
        assert(PctDiff( r.s(T, p), 0.517540298e+1) < eps)
        assert(PctDiff(r.cp(T, p), 0.103505092e+2) < eps)
        #assert(PctDiff( r.w(T, p), 0.480386523e+3) < eps)
    def TestRegion3():
        '''Test Cases:
        1.  Recommended test values from IAPWS paper [1], page 32
        '''
        r = iapws97.Region3()
        eps = 0.001 # Allowed % difference published values
        # Column 1 test cases
        T   = 650 # K
        rho = 500 # kg/m^3
        assert(PctDiff( r.p(T, rho), 0.255837018e+2) < eps)
        assert(PctDiff( r.h(T, rho), 0.186343019e+4) < eps)
        assert(PctDiff( r.u(T, rho), 0.181226279e+4) < eps)
        assert(PctDiff( r.s(T, rho), 0.405427273e+1) < eps)
        assert(PctDiff(r.cp(T, rho), 0.138935717e+2) < eps)
        #assert(PctDiff( r.w(T, rho), 0.502005554e+3) < eps)
        # Column 2 test cases
        T   = 650 # K
        rho = 200 # kg/m^3
        assert(PctDiff( r.p(T, rho), 0.222930643e+2) < eps)
        assert(PctDiff( r.h(T, rho), 0.237512401e+4) < eps)
        assert(PctDiff( r.u(T, rho), 0.226365868e+4) < eps)
        assert(PctDiff( r.s(T, rho), 0.485438792e+1) < eps)
        assert(PctDiff(r.cp(T, rho), 0.446579342e+2) < eps)
        #assert(PctDiff( r.w(T, rho), 0.383444594e+3) < eps)
        # Column 3 test cases
        T   = 750 # K
        rho = 500 # kg/m^3
        assert(PctDiff( r.p(T, rho), 0.783095639e+2) < eps)
        assert(PctDiff( r.h(T, rho), 0.225868845e+4) < eps)
        assert(PctDiff( r.u(T, rho), 0.210206932e+4) < eps)
        assert(PctDiff( r.s(T, rho), 0.446971906e+1) < eps)
        assert(PctDiff(r.cp(T, rho), 0.634165359e+1) < eps)
        #assert(PctDiff( r.w(T, p), 0.760696041e+3) < eps)
    def TestRegion4():
        '''Test Cases:
        1.  Recommended test values from IAPWS paper [1], page 34
        2.  pSat() and TSat() should be inverses of each other
        3.  Test against NIST saturated liquid data [3]
        '''
        r = iapws97.Region4()
        eps = 0.001
        # Test case 1
        assert(PctDiff(r.pSat(300), 0.353658941e-2) < eps)
        assert(PctDiff(r.pSat(500), 0.263889776e+1) < eps)
        assert(PctDiff(r.pSat(600), 0.123443146e+2) < eps)
        # Test case 2
        for T in xrange(274, 648):
            assert(PctDiff(r.TSat(r.pSat(T)), T) < 0.00001)
        # Test case 3
        data = ReadDataFile("sat_liquid")
        del data[0]  # Remove the titles of the columns
        eps = 0.03
        for item in data:
            T, p = item[0], item[1]
            assert(PctDiff(r.pSat(float(T)), float(p)) < eps)
    def TestThermalConductivity():
        tc = iapws97.ThermalConductivity()
        x = (
            (  0.01, 3.558899743e-2),
            (  0.1,  3.58607682e-2),
            (  1.0,  3.879928055e-2),
            ( 10.0,  6.516544952e-1),
            (100.0,  7.304069749e-1),
        )
        # The test values came from Bernhard Spang's Excel add-in (this
        # is meant to verify that I utilized his equations correctly).
        T = 500 # K
        eps = 0.001
        assert(PctDiff(tc.k(T,   0.01), 3.558899743e-2) < eps)
        assert(PctDiff(tc.k(T,   0.1),  3.586076820e-2) < eps)
        assert(PctDiff(tc.k(T,   1.0),  3.879928055e-2) < eps)
        assert(PctDiff(tc.k(T,  10.0),  6.516544952e-1) < eps)
        assert(PctDiff(tc.k(T, 100.0),  7.304069749e-1) < eps)
    def GenerateTestCases(file):
        '''Using the IAPWS95 model, generate test cases for the
        IAPWS97 model.  The range of pressures is from 1e-4 to 100 MPa
        and temperatures from 273.16 to 1273 K.
        '''

    file = "iapws97"
    mark_file = file + ".marks"
    iapws97.mark_file = mark_file
    source_file = file + ".py"
    iapws97.mark = 1
    TestRegion1()
    TestRegion2()
    TestRegion3()
    TestRegion4()
    TestThermalConductivity()
    iapws97.Marker("", done=1)
    if show_untested:
        PrintUntestedChunks(source_file, mark_file)
    else:
        num_untested = len(GetUntestedChunks(source_file, mark_file))
        if num_untested == 1:
            print "%s:  1 untested chunk" % source_file
        elif num_untested > 1:
            print "%s:  %d untested chunks" % (source_file, num_untested)


TestIAPWS95()
print "Tests passed"
