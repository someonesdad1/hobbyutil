'''
A Monte Carlo simulation of a manufacturing process that has a given
distribution of parts.  The parts are then subject to 100% inspection to
weed out the bad parts.  The twist is caused by the fact that the
measurement process has a non-negligible uncertainty.  Thus, some good
parts get thrown away and some bad parts are kept and shipped to the
customer.

This is a re-implementation of the Rocky Mountain Basic program I wrote
in the early 1980's.
'''

# Copyright (C) 2006 Don Peterson
# Contact:  gmail.com@someonesdad1
  
#
# Licensed under the Apache License, Version 2.0 (the "License"); you
# may not use this file except in compliance with the License.  You may
# obtain a copy of the License at
# 
# http://www.apache.org/licenses/LICENSE-2.0
# 
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or
# implied.  See the License for the specific language governing
# permissions and limitations under the License.
#

from __future__ import print_function, division 
from time import time, localtime, asctime
import sys
import os
import getopt
import hashlib
import numpy as np
from numpy.random import normal, seed
from random import random
from pdb import set_trace as xx

py3 = sys.version_info[0] == 3
have_matplotlib = False
try:
    import pylab as pl
    have_matplotlib = True
except ImportError:
    pass

Title = "Example Production Model"
Randomize  = True           # If true, randomize the random number generator
Plot       = True
Financials = True
bitmap     = False          # If true, put graph in file

NumberLots   = 100          # Number of production lots to make
PartsPerLot  = 1000         # Number of parts in a process lot
ProcessMean  = 5.2          # Mean of the process distribution
ProcessS     = 0.5          # Standard deviation of the process distribution
MeasurementS = 0.3          # Measurement standard deviation
LowLimit     = 4            # Discard parts if less than this value
HighLimit    = 6            # Discard parts if more than this value

ProcessDistribution          = "normal"
MeasurementErrorDistribution = "normal"

# Costs
ProductionCost   = 4        # Cost to make a part
TestCost         = 1        # Cost to test a part
ScrapCost        = 0.5      # Cost to scrap a part
ShipCost         = 1        # Cost to ship an apparently good part
VariableOverhead = 2        # Cost per part of overhead
FixedOverhead    = 10000    # Fixed overhead cost for total production
CustomerBadCost  = 10       # Cost to customer to deal with an actual bad part
CustomerCost     = 30       # What customer pays for part


# The following number indicates where there would have been a
# division by zero error.
error_num = -999

# ---------------------- Utility functions -----------------------------

def Error(msg, status=1):
    print(msg, stream=sys.stderr)
    exit(status)

def Usage(d, status=1):
    name = sys.argv[0]
    s = '''
Usage:  {name} [options] state_file [picture_directory]
  Models a production process whose characteristics are described by
  the file state_file.  A report of the simulation will be printed to
  stdout.  If matplotlib is installed and picture_directory is given,
  histograms of the simulated production will be put into the
  picture_directory.

Options:
    -s 
        Print a template state file to stdout.  Note this is
        executable python code.
'''[1:-1]
    print(s.format(**locals()))
    sys.exit(status)

def ParseCommandLine(d):
    if 0 and len(sys.argv) < 2:
        Usage(d)
    try:
        optlist, args = getopt.getopt(sys.argv[1:], "s")
    except getopt.GetoptError as str:
        msg, option = str
        print(msg)
        sys.exit(1)
    for opt in optlist:
        if opt[0] == "-s":
            PrintStateFileSample()
        if opt[0] == "-b":
            d["-b"] = opt[1]
        if opt[0] == "-h":
            Usage(d, status=0)
    if 0 and len(args) not in (1, 2):
        Usage(d)
    return args

def PrintStateFileSample():
    s = '''
'''
    print(s)
    exit(0)

def SourceFileHash():
    h = hashlib.md5()
    s = open(sys.argv[0]).read()
    h.update(s.encode("UTF-8") if py3 else s)
    return h.hexdigest()

def Comma(x):
    '''x is an integer; return a string with x formatted with commas
    separating the thousands (uses locale, so it will work with
    '.' in other locales).
    '''
    if not isinstance(x, (int, long)):  # Breaks on python 3
        raise ValueError("x must be an integer")
    import locale
    locale.setlocale(locale.LC_ALL, '') # Set to the default locale
    return format(x, "n")

# ---------------------- Functions comprising the model ----------------

def SeparateParts(parts):
    '''Return the good, bad arrays.
    '''
    passed  = np.compress(parts >= LowLimit, parts)
    passed  = np.compress(passed <= HighLimit, passed)
    failed1 = np.compress(parts < LowLimit, parts)
    failed2 = np.compress(parts > HighLimit, parts)
    failed  = np.concatenate((failed1, failed2))
    return passed, failed

def MakeProductionLot():
    # Get a sample of parts from the production distribution
    parts = normal(ProcessMean, ProcessS, (PartsPerLot,))
    actual_good, actual_bad = SeparateParts(parts)
    # Apply measurement error to each part
    # Test the good parts
    try:
        error = normal(0, MeasurementS, (len(actual_good),))
        tested = actual_good + error
    except Exception:
        tested = actual_good
    good_tested_good, good_tested_bad = SeparateParts(tested)
    # Test the bad parts
    try:
        error = normal(0, MeasurementS, (len(actual_bad),))
        tested = actual_bad + error
    except Exception:
        tested = actual_bad
    bad_tested_good, bad_tested_bad = SeparateParts(tested)
    # Return lot info
    return (
        actual_good,
        actual_bad,
        good_tested_good,
        good_tested_bad,
        bad_tested_good,
        bad_tested_bad,
    )

statistics = [
    np.arange(0),      # Actual good parts made
    np.arange(0),      # Actual bad parts made
    np.arange(0),      # Good parts tested good
    np.arange(0),      # Good parts tested bad
    np.arange(0),      # Bad parts tested good
    np.arange(0),      # Bad parts tested bad
]

def AccumulateParts(lot):
    global statistics
    (actual_good, 
     actual_bad, 
     good_tested_good, 
     good_tested_bad,
     bad_tested_good, 
     bad_tested_bad) = lot
    statistics = [
        np.concatenate((statistics[0], actual_good)),
        np.concatenate((statistics[1], actual_bad)),
        np.concatenate((statistics[2], good_tested_good)),
        np.concatenate((statistics[3], good_tested_bad)),
        np.concatenate((statistics[4], bad_tested_good)),
        np.concatenate((statistics[5], bad_tested_bad)),
    ]

def Report():
    good = len(statistics[0])
    bad  = len(statistics[1])
    N = good + bad
    good_tested_good = len(statistics[2])
    good_tested_bad  = len(statistics[3])
    bad_tested_good  = len(statistics[4])
    bad_tested_bad   = len(statistics[5])
    apparently_good  = good_tested_good + bad_tested_good
    apparently_bad   = good_tested_bad  + bad_tested_bad
    #
    c = 100/N
    pct_good = c*good
    pct_bad  = c*bad
    pct_good_tested_good = c*good_tested_good
    pct_good_tested_bad  = c*good_tested_bad
    pct_bad_tested_good  = c*bad_tested_good
    pct_bad_tested_bad   = c*bad_tested_bad
    #
    true_yield = 100*good/N
    true_scrap = 100*bad /N
    apparent_yield = c*(good_tested_good + bad_tested_good)
    apparent_scrap = c*(good_tested_bad  + bad_tested_bad )
    process_mean   = ProcessMean
    process_s      = ProcessS
    measurement_s  = MeasurementS
    low            = LowLimit
    high           = HighLimit
    lots           = NumberLots
    parts_per_lot  = PartsPerLot
    #
    to_kdollars = 1/1000
    number_shipped      = good_tested_good + bad_tested_good
    number_scrapped     = good_tested_bad  + bad_tested_bad
    production_cost     = ProductionCost*N*to_kdollars
    testing_cost        = TestCost*N*to_kdollars
    shipment_cost       = ShipCost*number_shipped*to_kdollars
    scrap_cost          = ScrapCost*number_scrapped*to_kdollars
    var_overhead_cost   = VariableOverhead*N*to_kdollars
    fix_overhead_cost   = FixedOverhead*to_kdollars
    total_cost          = (production_cost + testing_cost + shipment_cost + 
                          scrap_cost + var_overhead_cost + fix_overhead_cost)
    try:
        cost_per_shipped = total_cost/number_shipped/to_kdollars
    except Exception:
        cost_per_shipped = error_num
    cost_per_started    = total_cost/N/to_kdollars
    customer_cost       = bad_tested_good*(CustomerCost + CustomerBadCost)* \
                                to_kdollars
    pct_bad_tested_good = 100*bad_tested_good/N
    pct_good_tested_bad = 100*good_tested_bad/N
    # Now put in terms of number shipped and scrapped
    try:
        pct_bad_tested_good1 = 100*bad_tested_good/number_shipped
    except Exception:
        pct_bad_tested_good1 = error_num
    try:
        pct_good_tested_bad1 = 100*good_tested_bad/number_scrapped
    except Exception:
        pct_good_tested_bad1 = 0
    #
    production_cost_ea  = ProductionCost
    testing_cost_ea     = TestCost
    scrap_cost_ea       = ScrapCost
    shipment_cost_ea    = ShipCost
    var_overhead_ea     = VariableOverhead
    fix_overhead_ea     = FixedOverhead/N
    customer_bad_cost_ea= CustomerBadCost
    customer_cost_ea    = CustomerCost
    revenue             = CustomerCost*(good_tested_good + 
                                        bad_tested_good)*to_kdollars
    gross_profit        = revenue - total_cost
    try:
        gross_profit_ea = (gross_profit/(good_tested_good + 
                           bad_tested_good))/to_kdollars
    except Exception:
        gross_profit_ea = error_num
    try:
        pct_gross_profit = 100*(revenue - total_cost)/revenue
    except Exception:
        pct_gross_profit = error_num
    proc_dist = ProcessDistribution
    meas_dist = MeasurementErrorDistribution
    empty_string = ""
    global tm
    cols, tm = 75, asctime(localtime(time()))
    print("{0:^{1}s}".format(Title, cols))
    print("{0:^{1}s}".format(tm, cols))
    print()
    t = os.path.abspath(sys.argv[0]).replace("\\", "/")
    print("Source file = {0}".format(t))
    print("  MD5 hash of source file = {0}".format(SourceFileHash()))

    print('''
Process characteristics
-----------------------
  Process mean                    %(process_mean)-12g
  Process standard deviation      %(process_s)-12g (%(proc_dist)s distribution)
  Measurement standard deviation  %(measurement_s)-12g (%(meas_dist)s distribution)
  Part acceptance interval        [%(low)g, %(high)g]
  Number of lots made             %(lots)d
  Parts per lot                   %(parts_per_lot)d
 
True state of nature
--------------------
  Total parts       %(N)8.0f
  Actual good       %(good)8.0f
  Actual bad        %(bad)8.0f
 
What the testing process determined
-----------------------------------
  Good tested good  %(good_tested_good)8.0f %(pct_good_tested_good)8.1f%%
  Good tested bad   %(good_tested_bad)8.0f %(pct_good_tested_bad)8.1f%%
  Bad  tested good  %(bad_tested_good)8.0f %(pct_bad_tested_good)8.1f%%
  Bad  tested bad   %(bad_tested_bad)8.0f %(pct_bad_tested_bad)8.1f%%
 
Results
-------
  Parts shipped       %(number_shipped)8.0f   (%(bad_tested_good)d or %(pct_bad_tested_good1).1f%% of these are bad parts)
  Parts scrapped      %(number_scrapped)8.0f   (%(good_tested_bad)d or %(pct_good_tested_bad1).1f%% of these are good parts)
 
               Real    Measured
              ------   --------
Yield      %(apparent_yield)8.1f%% %(pct_good)8.1f%%
Scrap      %(apparent_scrap)8.1f%% %(pct_bad)8.1f%%''' % locals())
    if Financials:
        print('''
Financials in k$                               $ Per Part
----------------                               ----------
  Production cost               %(production_cost)12.1f %(production_cost_ea)10.3f
  Testing cost                  %(testing_cost)12.1f %(testing_cost_ea)10.3f
  Shipment cost                 %(shipment_cost)12.1f %(shipment_cost_ea)10.3f
  Cost to scrap                 %(scrap_cost)12.1f %(scrap_cost_ea)10.3f
  Variable overhead cost        %(var_overhead_cost)12.1f %(var_overhead_ea)10.3f
  Fixed overhead cost           %(fix_overhead_cost)12.1f %(fix_overhead_ea)10.3f
                                    --------
  Total production cost         %(total_cost)12.1f %(cost_per_started)10.3f (per part started)
                                    %(empty_string)8s %(cost_per_shipped)10.3f (per part shipped)
 
  Revenue                       %(revenue)12.1f %(customer_cost_ea)10.3f
  Gross profit                  %(gross_profit)12.1f %(gross_profit_ea)10.3f
  %% gross profit                %(pct_gross_profit)12.1f%%
 
  Customer's loss from bad parts%(customer_cost)12.1f %(customer_bad_cost_ea)10.2f
  ''' % locals())
    return locals()

def PlotGraphs(vars, dir="pictures"):
    for k in vars:  # Set up local variables
        exec("{} = vars['{}']".format(k, k))
    # Now draw some graphs
    if Plot:
        (actual_good, actual_bad, good_tested_good, good_tested_bad, 
            bad_tested_good, bad_tested_bad) = statistics
        bins = 30
        bins = np.arange(1, 9, 0.1)
        dpi = 100

        pl.clf()
        pl.hist(actual_good, bins)
        pl.title("Actual good parts produced\n%s" % tm)
        pl.savefig(os.path.join(dir, "actual_good.png"), dpi=dpi)

        pl.clf()
        pl.hist(actual_bad, bins)
        pl.title("Actual bad parts produced\n%s" % tm)
        pl.savefig(os.path.join(dir, "actual_bad.png"), dpi=dpi)

        pl.clf()
        pl.hist(good_tested_good, bins)
        pl.title("Good parts measured as good\n%s" % tm)
        pl.savefig(os.path.join(dir, "good_meas_as_good.png"), dpi=dpi)

        pl.clf()
        pl.hist(good_tested_bad, bins)
        pl.title("Good parts measured as bad\n%s" % tm)
        pl.savefig(os.path.join(dir, "good_meas_as_bad.png"), dpi=dpi)

        pl.clf()
        pl.hist(bad_tested_good, bins)
        pl.title("Bad parts measured as good\n%s" % tm)
        pl.savefig(os.path.join(dir, "bad_meas_as_good.png"), dpi=dpi)

        pl.clf()
        pl.hist(bad_tested_bad, bins)
        pl.title("Bad parts measured as bad\n%s" % tm)
        pl.savefig(os.path.join(dir, "bad_meas_as_bad.png"), dpi=dpi)

        pl.clf()
        pl.hist(np.concatenate((statistics[2], statistics[4])), bins)
        pl.title("Apparent good distribution\n%s" % tm)
        pl.savefig(os.path.join(dir, "apparent_good.png"), dpi=dpi)

        pl.clf()
        pl.hist(np.concatenate((statistics[3], statistics[5])), bins)
        pl.title("Apparent bad distribution\n%s" % tm)
        pl.savefig(os.path.join(dir, "apparent_bad.png"), dpi=dpi)

if __name__ == "__main__": 
    d = {} # Options dictionary
    args = ParseCommandLine(d)
    if not Randomize:
        seed(1, 1)
    for i in range(NumberLots):
        lot = MakeProductionLot()
        AccumulateParts(lot)
    vars = Report()
    if have_matplotlib:
        PlotGraphs(vars)
