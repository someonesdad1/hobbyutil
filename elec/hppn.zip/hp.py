'''
Search the HP part number file for the string on the command line.

Also, the file hp_parts_list_1973_74.pdf comes from
http://www.hparchive.com/hp_PARTS.htm (the file's link is
http://www.hparchive.com/PARTS/HP-Parts-List-1973-74.pdf and it's a 35 MB
file).
'''

import sys, re

if len(sys.argv) == 1:
    print '''Usage:  %s regexp1 [regexp2...]
  Searches the HP part numbers file for regular expressions and prints out
  the matches.'''
    exit(1)

file = "d:/p/electronics/hp/hp_parts"
lines = open(file).readlines()

# Compile the regexps on the command line
regexps = []
for i in sys.argv[1:]:
    regexps.append(re.compile(i))

# Search
found = []
for line in lines:
    line = line.strip()
    if not line or line[0] == "#":
        continue
    for r in regexps:
        if r.search(line):
            found.append(line)
found.sort()
for i in found:
    print i
