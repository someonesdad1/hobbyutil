/**************************************************************************

Select from on-hand resistors to make a voltage divider or a resistor
composed of a pair of resistors.  See Usage() function for details.

To build with MinGW g++ (http://www.mingw.org/):
    g++ -o resistor.exe -Wall resistor.cpp

----------------------------------------------------------------------
Copyright (C) 2009 Don Peterson someonesdad1@gmail.com

This program is free software; you can redistribute it
and/or modify it under the terms of the GNU General Public
License as published by the Free Software Foundation; either
version 2 of the License, or (at your option) any later
version.

This program is distributed in the hope that it will be
useful, but WITHOUT ANY WARRANTY; without even the implied
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
PURPOSE.  See the GNU General Public License for more
details.

You should have received a copy of the GNU General Public
License along with this program; if not, write to the Free
Software Foundation, Inc., 59 Temple Place, Suite 330,
Boston, MA 02111-1307  USA
**************************************************************************/

#include <iostream>
#include <string>
#include <vector>
#include <set>
#include <cstdlib>
#include <cstdio>
#include <fstream>
#include <sstream>
#include <cmath>
using namespace std;

// Set to true for debug printing
const bool debug = false;  

//--------------------------------------------------------------
// Program default values set here
const double default_ratio_tolerance      = 0.01;  // Also for resistor
const double default_resistance_tolerance = 0.05;  // Note:  for divider only
const bool use_parts_on_hand = true;  // If true, use the parts defined
                                      // in the parts_on_hand array.
//--------------------------------------------------------------

#ifdef USE_HIGH_BIT
const char ohm = 0xea;  // System character for capital omega
const char pm  = 0xf1;  // System character for plus/minus symbol
#else
const char ohm = ' ';
const char pm  = ' ';
#endif

#define MAX(a, b) ((a < b) ? b : a)
#define MIN(a, b) ((a > b) ? b : a)

const char * sentinel = "end";

char * parts_on_hand[] = {
    "0.025", "0.2", "1", "2.2", "4.6", "8.3", "10.1", "12",
    "14.7", "15", "17.8", "22", "27", "28.4", "30", "33", "35",
    "38.4", "46.3", "50", "55.5", "61.8", "67", "75", "78",
    "81", "100", "110", "115", "150", "170", "178", "196", "215",
    "220", "237", "268", "270", "287", "316", "330", "349", "388",
    "465", "500", "513", "546", "563", "680", "750", "808", "822",
    "980", "1k", "1.1k", "1.18k", "1.21k", "1.33k", "1.47k",
    "1.5k", "1.62k", "1.78k", "1.96k", "2.16k", "2.2k", "2.37k",
    "2.61k", "2.72k", "3k", "3.3k", "3.47k", "3.82k", "4.64k",
    "5k", "5.53k", "6.8k", "8k", "9.09k", "10k", "11.8k", "13.3k",
    "15k", "16.2k", "17.8k", "18k", "19.5k", "22k", "26.2k",
    "33k", "39k", "46k", "51k", "55k", "67k", "75k", "82k",
    "100k", "120k", "147k", "162k", "170k", "180k", "220k",
    "263k", "330k", "390k", "422k", "460k", "560k", "674k",
    "820k", "1M", "1.2M", "1.5M", "1.7M", "1.9M", "2.2M", "2.4M",
    "2.6M", "2.8M", "3.2M", "4M", "4.8M", "5.6M", "6M", "8.7M",
    "10M", "16M", "23.5M",
    const_cast<char *>(sentinel)  // Flags end of array
};

typedef vector<double> ResistanceValues;
typedef ResistanceValues::size_type Sizes;
typedef set<double> ResistanceValueSet;
typedef set<double>::iterator ResistanceValueSetIterator;
typedef enum {divider, resistor} Action;
typedef enum {E6, E12, E24, E48, E96} E_type;
typedef const double E;
typedef unsigned int uint;

struct Arguments
{
    string program_name;
    string config_file;
    Action action;
    double ratio;
    double resistance;            // Total divider res. or desired res.
    double ratio_tolerance;       // Will be >= 0 and <= 1
    double resistance_tolerance;  // Will be >= 0 and <= 1
    int    resistor_series;
};

// The following array is used to define what decades of E-series
// resistors are included.
const uint power_count = 9;
const int powers_of_10[power_count] = {-1, 0, 1, 2, 3, 4, 5, 6, 7};

// EIA recommended resistor values.  Note these arrays use a 0
// sentinel value to indicate the end of the array.
// From http://www.radio-electronics.com/info/data/resistor/resistor_standard_values.php

E e6[]  = {1.0, 1.5, 2.2, 3.3, 4.7, 6.8, 0};

E e12[] = {1.0, 1.2, 1.5, 1.8, 2.2, 2.7, 3.3, 3.9, 4.7, 5.6, 6.8, 8.2, 0};

E e24[] = {1.0, 1.1, 1.2, 1.3, 1.5, 1.6, 1.8, 2.0, 2.2, 2.4, 2.7, 3.0,
           3.3, 3.6, 3.9, 4.3, 4.7, 5.1, 5.6, 6.2, 6.8, 7.5, 8.2, 9.1, 0};

E e48[] = {1.00, 1.05, 1.10, 1.15, 1.21, 1.27, 1.33, 1.40, 1.47, 1.54, 
           1.62, 1.69, 1.78, 1.87, 1.96, 2.05, 2.15, 2.26, 2.37, 2.49,
           2.61, 2.74, 2.87, 3.01, 3.16, 3.32, 3.48, 3.65, 3.83, 4.02,
           4.22, 4.42, 4.64, 4.87, 5.11, 5.36, 5.62, 5.90, 6.19, 6.49,
           6.81, 7.15, 7.50, 7.87, 8.25, 8.66, 9.09, 9.53, 0};

E e96[] = {1.00, 1.02, 1.05, 1.07, 1.10, 1.13, 1.15, 1.18, 1.21, 1.24,
           1.27, 1.30, 1.33, 1.37, 1.40, 1.43, 1.47, 1.50, 1.54, 1.58,
           1.62, 1.65, 1.69, 1.74, 1.78, 1.82, 1.87, 1.91, 1.96, 2.00,
           2.05, 2.10, 2.16, 2.21, 2.36, 2.32, 2.37, 2.43, 2.49, 2.55,
           2.61, 2.67, 2.74, 2.80, 2.87, 2.94, 3.01, 3.09, 3.16, 3.24,
           3.32, 3.40, 3.48, 3.57, 3.65, 3.74, 3.83, 3.92, 4.02, 4.12,
           4.22, 4.32, 4.42, 4.53, 4.64, 4.75, 4.87, 4.91, 5.11, 5.23,
           5.36, 5.49, 5.62, 5.76, 5.90, 6.04, 6.19, 6.34, 6.49, 6.65,
           6.81, 6.98, 7.15, 7.32, 7.50, 7.68, 7.87, 8.06, 8.25, 8.45,
           8.66, 8.87, 9.09, 9.31, 9.59, 9.76, 0};

// Testing mode is where the internal resistance values are not used.
// This allows an automated testing script to set up precise conditions.
// Turn it on with the -x option.
bool ignore_internal_resistors = false;

// ----------------------------------------------------------------------

void Usage(const string program_name)
{
    cout << "Usage:  " << program_name << 

" [options] action [parameters]\n"
"\n"
"Actions:\n"
"  d[ivider] ratio\n"
"    Finds the pairs of resistors that yield the given ratio within the\n"
"    desired tolerance (defaults to 1%; use -t to change).\n"
"\n"
"  r[esistor] resistance\n"
"    Finds pairs of resistors that will yield the desired resistance by\n"
"    using the pairs in series or parallel.  The default search tolerance\n"
"    is 1%; use the -t option to change.\n"
"\n"
"Options:\n"
"  -c file\n"
"     Specifies the configuration file.  If not given, the resistor.dat file\n"
"     is used (same directory as executable).  The data file's resistors are\n"
"     added to the list of internally-defined resistors.  This allows you to\n"
"     add resistors to your collection without having to rebuild the code.\n"
" \n"
"     The data file consists of whitespace-separated values of the forms 22.3,\n"
"     22.3k, 22.3M, or 22.3G.  You can, of course, use the usual floating \n"
"     point exponential notation instead such as 22.3e0, 22.3e3, etc.\n"
"\n"
"  -e num\n"
"     Specifies that various resistor series should be used for searching rather\n"
"     than the on-hand resistors given by the configuration file.  num is the \n"
"     number from the following allowed series: E6, E12, E24, E48, E96.  The\n"
"     powers of ten that are used to determine the set of all resistors are\n"
"     compiled within the program in the global integer array powers_of_ten.\n"
"\n"
"  -r total_resistance[:percent_tolerance]\n"
"     (For voltage divider calculations only)\n"
"     Specifies the total resistance of the divider and the tolerance percentage\n"
"     on this value.  Only resistor pairs that have this total resistance within\n"
"     the specified tolerance will be printed.  If percent_tolerance is not\n"
"     given, the same tolerance as used for the ratio will be used.\n"
"\n"
"  -t percent_tolerance\n"
"     Changes the tolerance for searching.  For the voltage divider search,\n"
"     gives the ratio tolerance.  For the resistor pair search, the total \n"
"     resistances within the tolerance of the desired value will be printed.\n"
"\n"
"  -x\n"
"     Ignore any resistors that are defined internally to the program.  This\n"
"     means only resistors defined in the configuration file are used.  This\n"
"     option is ignored if the -e option is used.\n"
    ;
}

void GetDataFile(Arguments & arguments)
{
    // Get the name of the data file:  it will be in the same
    // directory as the executable.
    arguments.config_file = "resistor.dat";
    string config_file = arguments.program_name; 
    bool used_backslashes = false;

    // Change any backslashes to forward slashes
    for (string::size_type i = 0; i < config_file.size(); i++)
    {
        if (config_file[i] == '\\')
        {
            config_file[i] = '/';
            used_backslashes = true;
        }
    }

    // Chop off every character after the last '/'
    string::size_type last_slash = config_file.find_last_of("/");
    if (last_slash != string::npos)
    {
        config_file = config_file.substr(0, last_slash + 1);
        config_file += arguments.config_file;
        arguments.config_file = config_file;
    }

    // Restore backslashes if needed
    if (used_backslashes)
    {
        for (string::size_type i = 0; i < arguments.config_file.size(); i++)
        {
            if (arguments.config_file[i] == '/')
                arguments.config_file[i] = '\\';
        }
    }
}

void ProcessCommandLine(int argc, char **argv, Arguments & arguments)
{
    // Default values
    arguments.program_name = *argv;
    arguments.config_file = "";
    arguments.action = divider;
    arguments.ratio = 0;
    arguments.ratio_tolerance = default_ratio_tolerance;
    arguments.resistance_tolerance = default_resistance_tolerance;
    arguments.resistance = 0.0;
    arguments.resistor_series = 0;

    GetDataFile(arguments);
    argv++;
    while (*argv)
    {
        string option = *argv;
        if (option == "-c")  // Data file
        {
            argv++;
            if (not *argv)
            {
                cerr << "Need argument for -c option" << endl;
                exit(1);
            }
            else
                arguments.config_file = *argv;
        }
        else if (option == "-e")   // Divider ratio tolerance
        {
            argv++;
            if (not *argv)
            {
                cerr << "Need argument for -e option" << endl;
                exit(1);
            }
            else
                arguments.resistor_series = atoi(*argv);
            switch (arguments.resistor_series)
            {
                case 6:
                case 12:
                case 24:
                case 48:
                case 96:
                    break;
                default:
                    cerr << "Bad value for -e argument" << endl;
                    exit(1);
                    break;
            }
        }
        else if (option == "-r")  // Total resistance & tolerance
        {
            argv++;
            if (not *argv)
            {
                cerr << "Need argument for -r option" << endl;
                exit(1);
            }
            else
            {
                string arg = *argv;
                string::size_type colon = arg.find(":");
                if (colon != string::npos)
                {
                    // Got resistance and tolerance
                    string R = arg.substr(0, colon);
                    arguments.resistance = strtod(R.c_str(), NULL);
                    if (arguments.resistance <= 0)
                    {
                        cerr << "-r option:  total resistance must be > 0" << endl;
                        exit(1);
                    }
                    string pct_tolerance = arg.substr(colon+1);
                    if (pct_tolerance == "")
                    {
                        cerr << "-r option:  need percent tolerance after ':'" << endl;
                        exit(1);
                    }
                    arguments.resistance_tolerance =
                        strtod(pct_tolerance.c_str(), NULL);
                    if (arguments.resistance_tolerance < 0)
                    {
                        cerr << "-r option:  resistance tolerance must be >= 0%" << endl;
                        exit(1);
                    }
                    arguments.resistance_tolerance /= 100;
                }
                else
                {
                    // Just got total resistance
                    arguments.resistance = strtod(arg.c_str(), NULL);
                    if (arguments.resistance <= 0)
                    {
                        cerr << "-r option:  total resistance must be >= 0" << endl;
                        exit(1);
                    }
                }
            }
        }
        else if (option == "-t")    // Divider ratio tolerance or if
                                    // r action is used, resistance
                                    // tolerance.
        {
            argv++;
            if (not *argv || argv[0][0] == '-')
            {
                cerr << "-t option:  need tolerance" << endl;
                exit(1);
            }
            arguments.ratio_tolerance = strtod(*argv, NULL);
            if (arguments.ratio_tolerance < 0)
            {
                cerr << "-t option:  ratio tolerance must be >= 0" << endl;
                exit(1);
            }
            arguments.ratio_tolerance /= 100;  // Convert from % to fraction
        }
        else if (option == "-x")  // Undocumented testing mode
        {
            ignore_internal_resistors = true;
        }
        else
        {
            if (argv[0][0] == 'd')
                arguments.action = divider;
            else if (argv[0][0] == 'r')
                arguments.action = resistor;
            else
            {
                cout << "Operation can only be [d]ivider or [r]esistor" << endl;
                exit(1);
            }
            argv++;
            if (not *argv)
            {
                cout << "Need parameter on command line (ratio or resistance)" 
                     << endl;
                exit(1);
            }
            if (arguments.action == divider)
            {
                arguments.ratio = strtod(*argv, NULL);
                if (arguments.ratio <= 0 || arguments.ratio >= 1)
                {
                    cerr << "Ratio must be > 0 and < 1" << endl;
                    exit(1);
                }
            }
            else
            {
                arguments.resistance = strtod(*argv, NULL);
                if (arguments.resistance <= 0)
                {
                    cerr << "Resistance must be > 0" << endl;
                    exit(1);
                }
            }
        }
        argv++;
    }

    if (arguments.action == divider and arguments.ratio == 0)
    {
        cerr << "Need to specify the divider ratio" << endl;
        Usage(arguments.program_name);
        exit(1);
    }
    if (arguments.action == resistor and arguments.resistance == 0)
    {
        cerr << "Need to specify the total resistance" << endl;
        Usage(arguments.program_name);
        exit(1);
    }

    if (debug)
    {
        cout << "Program name         = " << arguments.program_name << endl 
             << "Config file          = " << arguments.config_file << endl 
             << "Ratio                = " << arguments.ratio << endl 
             << "Ratio tolerance      = " << arguments.ratio_tolerance << endl 
             << "Resistance           = " << arguments.resistance << endl 
             << "Resistance tolerance = " << arguments.resistance_tolerance << endl
             << "Action               = " << arguments.action << endl
             << "Resistor series      = " << arguments.resistor_series << endl
             << endl;
    }
}

double ParseNumber(const string & resistor)
{
    if (resistor.size() == 0)
    {
        cerr << "Bad resistor string size at line " << __LINE__ << endl;
        exit(1);
    }

    char last_letter = resistor[resistor.size() - 1];
    double multiplier = 1;

    if (last_letter == 'k' || last_letter == 'M' || last_letter == 'G')
    {
        switch (last_letter)
        {
            case 'k':
                multiplier = 1e3;
                break;
            case 'M':
                multiplier = 1e6;
                break;
            case 'G':
                multiplier = 1e9;
                break;
            default:
                cout << "Logic error at line " << __LINE__ << endl;
                exit(1);
        }
    }
    else if (last_letter < '0' || last_letter > '9')
    {
        cerr << "Illegal letter in resistor string:  '"
                << resistor << "'" << endl;
        exit(1);
    }

    double value = multiplier*strtod(resistor.c_str(), NULL);

    if (value <= 0)
    {
        cerr << "Illegal resistance value:  '"
                << resistor << "'" << endl;
        exit(1);
    }

    return value;
}

void GetSeries(const int series, ResistanceValues & resistors)
{
    const double * values;
    switch (series)
    {
        case 6:
            values = e6;
            break;
        case 12:
            values = e12;
            break;
        case 24:
            values = e24;
            break;
        case 48:
            values = e48;
            break;
        case 96:
            values = e96;
            break;
        default:
            cerr << "Program error:  bad series number" << endl;
            exit(1);
            break;
    }
    for (uint i = 0; i < power_count; i++)
    {
        const double p = pow(10.0, double(powers_of_10[i]));
        const double * v = values;
        while (*v)
        {
            resistors.push_back(*v*p);
            if (debug)
            {
                cout << "Stored value " << *v*p << endl;
            }
            v++;
        }
    }
}

void GetResistorStock(const Arguments & arguments, 
                      ResistanceValues & resistors, 
                      const string & config_file)
{
    if (arguments.resistor_series == 0)
    {
        if (use_parts_on_hand and not ignore_internal_resistors)
        {
            // Get resistors from array at top of file
            char ** parts = parts_on_hand;
            string resistor = *parts;
     
            while (resistor != sentinel)
            {
                if (resistor.size() == 0)
                {
                    cerr << "Empty element in parts_on_hand array." << endl;
                    exit(1);
                }
                double value = ParseNumber(resistor);
                resistors.push_back(value);
                if (debug)
                {
                    cout << "Read array string:  '" << resistor 
                            << "'   Value = " << value << endl;
                }
                parts++;
                resistor = *parts;
            }
        }
 
        // Read data from config file.  Note it's not an error if the file
        // isn't readable and we're using the parts on hand also.
        ifstream in(config_file.c_str());
        if (not in)
        {
            if (debug)
                cout << "Couldn't open data file " << config_file << endl;
            if (not use_parts_on_hand)
                exit(1);
        }
        else
        {
            string resistor;
 
            while (in >> resistor)
            {
                if (resistor.size() == 0)
                {
                    cout << "Empty element in parts_on_hand array." << endl;
                    exit(1);
                }
                double value = ParseNumber(resistor);
                resistors.push_back(value);
                if (debug)
                {
                    cout << "Read string from file:  '" << resistor 
                            << "'   Value = " << value << endl;
                }
            }

        }
    } 
    else
    {
        // Use a resistor series (E6, E12, E24, etc.)
        GetSeries(arguments.resistor_series, resistors);
    }

    // Look for duplicates by putting the elements into a set.  We'll exit
    // it a duplicate is found.
    ResistanceValueSet vs;
    ResistanceValueSetIterator vsi;
    bool duplicate_found = false;
    for (Sizes i=0; i < resistors.size(); i++)
    {
        double value = resistors[i];
        vsi = vs.find(value);
        if (vsi == vs.end())
        {
            (void) vs.insert(value);
        }
        else
        {
            cout << value << " is duplicate resistor value." << endl;
            duplicate_found = true;
        }
    }
    if (duplicate_found)
        exit(1);

    if (debug)
    {
        cout << "Finished loading data:  " << resistors.size() 
             << " values loaded." << endl << endl;
    }
}

string FormatResistance(const double resistance)
{
    ostringstream ss;
    if (resistance >= 1e3 && resistance < 1e6)
    {
        ss << resistance/1e3 << " k" << ohm;
    }
    else if (resistance >= 1e6 && resistance < 1e9)
    {
        ss << resistance/1e6 << " M" << ohm;
    }
    else if (resistance >= 1e9 && resistance < 1e12)
    {
        ss << resistance/1e9 << " G" << ohm;
    }
    else
    {
        ss << resistance << "  " << ohm;
    }
    return ss.str();
}

void PrintDividerPair
(
    const double & resistance1, 
    const double & resistance2,
    const double & ratio,
    const Arguments & arguments
)
{
    printf("%9s     %9s      %.4f      %12s\n", 
        FormatResistance(resistance1).c_str(),
        FormatResistance(resistance2).c_str(),
        ratio,
        FormatResistance(resistance1 + resistance2).c_str());
}

bool MeetTotalResistanceRequirement
(
    const double & total_resistance,
    const Arguments & arguments
)
{
    // See if a requirement was specified
    if (arguments.resistance == 0)
        return true;
    // It was; see if these two resistors meet the spec
    double ratio = total_resistance/arguments.resistance;
    if (ratio == 1.0)
    {
        return true;
    }

    if (ratio < 1)
    {
        if (ratio >= (1 - arguments.resistance_tolerance))
            return true;
    }
    else
    {
        if (ratio <= (1 + arguments.resistance_tolerance))
            return true;
    }
    return false;
}

void CheckDividerPair
(
    const double & resistance1,
    const double & resistance2,
    const Arguments & arguments
)
{
    // See if these two resistors satisfy our requirements
    double low_ratio  = arguments.ratio*(1 - arguments.ratio_tolerance);
    double high_ratio = arguments.ratio*(1 + arguments.ratio_tolerance);
    low_ratio  = MAX(low_ratio, 0);
    high_ratio = MIN(high_ratio, 100);
    const double total_r = resistance1 + resistance2;
    double ratio;

    // We need to check the resistors both ways:
    //
    //          Case 1                  Case 2
    //      o                        o                     |
    //      |                        |                     |
    //      \                        \                     |
    //      /  resistance1           /  resistance2        |
    //      \                        \                     |
    //      |                        |                     |
    //      o-----------o            o-----------o         | 
    //      |                        |                     |
    //      \                        \                     |
    //      /  resistance2           /  resistance1        |
    //      \                        \                     |
    //      |                        |                     |
    //      o-----------o            o-----------o         |
    //

    bool printed = false;
    ratio = resistance1/total_r;
    if ((low_ratio <= ratio) && (ratio <= high_ratio))
    {
        if (arguments.resistance != 0)
        {
            if (MeetTotalResistanceRequirement(total_r, arguments))
            {
                PrintDividerPair(resistance1, resistance2, ratio, arguments);
                printed = true;
            }
        }
        else
        {
            PrintDividerPair(resistance1, resistance2, ratio, arguments);
            printed = true;
        }
    }

    // No need to print equal resistors twice
    if (printed && ratio == 0.5)
        return;

    ratio = resistance2/total_r;
    if ((low_ratio <= ratio) && (ratio <= high_ratio))
    {
        if (arguments.resistance != 0)
        {
            if (MeetTotalResistanceRequirement(total_r, arguments))
                PrintDividerPair(resistance1, resistance2, ratio, arguments);
        }
        else
        {
            PrintDividerPair(resistance1, resistance2, ratio, arguments);
        }
    }
}

void PrintResistorPair
(
    const double & resistance1, 
    const double & resistance2, 
    const double & resistance, 
    const Arguments & arguments,
    const string & match_type,
    const string & percent_diff
)
{
    printf("%12s     %12s       %12s     %-9s   %-9s\n", 
        FormatResistance(resistance1).c_str(),
        FormatResistance(resistance2).c_str(),
        FormatResistance(resistance).c_str(),
        match_type.c_str(),
        percent_diff.c_str());
}

string PercentDifference(const double & value, const double & target)
{
    char buffer[20] = "";
    double diff = 100*(value - target)/target;
    sprintf(buffer, "%8.3f", diff);
    return string(buffer);
}

void CheckResistorPair
(
    const double & resistance1,
    const double & resistance2,
    const Arguments & arguments
)
{
    // Again, note we use the ratio_tolerance, as this comes from the -t
    // option.
    const double low_limit = arguments.resistance*(1 -
        arguments.ratio_tolerance);
    const double high_limit = arguments.resistance*(1 +
        arguments.ratio_tolerance);

    // See if these two resistors in series satisfy our requirements
    double resistance = resistance1 + resistance2;
    if (low_limit <= resistance and resistance <= high_limit)
    {
        PrintResistorPair(resistance1, resistance2, resistance, arguments,
            "series", PercentDifference(resistance, arguments.resistance));
    }

    // See if these two resistors in parallel satisfy our requirements
    resistance = 1/(1/resistance1 + 1/resistance2);
    if (low_limit <= resistance and resistance <= high_limit)
    {
        PrintResistorPair(resistance1, resistance2, resistance, arguments,
            "parallel", PercentDifference(resistance, arguments.resistance));
    }
}

void ResistorSearch
(
    const Arguments & arguments, 
    const ResistanceValues resistors
)
{
    // Print report header
    cout << "                      Resistor Search" << endl
         << "                      ---------------" << endl << endl
         << "Desired resistance = " << arguments.resistance
         // Note in the following that ratio tolerance is correct, as we
         // want the -t option to be used for both cases.  This will be a
         // bit confusing to the programmer.  The
         // arguments.resistance_tolerance is only used for the divider.
         << "  Tolerance = " << pm << 100*arguments.ratio_tolerance 
         << "%"
         << endl << endl;
 
    cout << "Resistor1        Resistor2        Total Resistance   Match Type"
            "    % Diff" << endl 
         << "------------     ------------     ----------------   ----------" 
            "    ------" << endl;
 
    // Check every resistor in the list with every other resistor.
    for (Sizes i = 0; i < resistors.size(); i++)
        for (Sizes j = i; j < resistors.size(); j++)
            CheckResistorPair(resistors[i], resistors[j], arguments);
}

void VoltageDividerSearch
(
    const Arguments & arguments, 
    const ResistanceValues resistors
)
{
    // Print report header
    cout << "       Voltage Divider Resistor Search" << endl
         << "       -------------------------------" << endl << endl
         << "Desired ratio = " << arguments.ratio
         << "  Tolerance = " << pm << 100*arguments.ratio_tolerance 
         << "%"
         << endl;
    if (arguments.resistance != 0)
    {
        cout << "Total resistance desired = " 
             << FormatResistance(arguments.resistance)
             << "  Tolerance = " << pm 
             << 100*arguments.resistance_tolerance
             << "%" << endl;
    }
    cout << endl;
 
    cout << "Resistor1     Resistor2      Ratio     Total Resistance" << endl 
         << "---------     ---------     --------   ----------------" << endl;
 
    // Check every resistor in the list with every other resistor.
    for (Sizes i = 0; i < resistors.size(); i++)
        for (Sizes j = i; j < resistors.size(); j++)
            CheckDividerPair(resistors[i], resistors[j], arguments);
}

void PerformSearch
(
    const Arguments & arguments, 
    const ResistanceValues resistors
)
{
    switch (arguments.action)   
    {
        case divider:
            VoltageDividerSearch(arguments, resistors);
            break;
        case resistor:
            ResistorSearch(arguments, resistors);
            break;
        default:
            cerr << "Program bug:  bad action" << endl;
            exit(1);
    }
}

int main(int argc, char **argv)
{
    Arguments arguments;
    ProcessCommandLine(argc, argv, arguments);
    ResistanceValues resistors;
    GetResistorStock(arguments, resistors, arguments.config_file);
    PerformSearch(arguments, resistors);
    return 0;
}
