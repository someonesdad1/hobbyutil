# I recommend you view this module's documentation with pydoc.py (a
# script in your python distribution).
#-----------------------------------------------------------------

__doc__ = '''
An almost drop-in Decimal replacement for the math module

From http://code.google.com/p/hobbyutil/.

The 'almost' is there because if you want e or pi, you have to call
them as functions because they need to be calculated to current
Decimal precision.  You'll also need to wrap ordinary floating point
numbers with a type conversion (see the example below).

All of the functions of the dmath library return Decimal type numbers,
even if they are just wrapping an integer.  Thus, the dmath library
should be closed under operations with respect to Decimal numbers.

If you are unfamiliar with python's Decimal numbers, they are number
objects that allow Decimal number calculations to be done to specified
precisions.  They can provide calculation accuracy in cases where
python's floating point numbers aren't adequate.  One example where
Decimal numbers are useful is to help quantify roundoff error in
floating point calculations.  Here's an example.

Suppose you want to calculate (x + delta) - x.  By algebra, the answer
is exactly delta.  However, if we have two floating point numbers, we
may not know this relationship exists.  You can run the following
example code (try it both under python 2 and python 3, as you'll
probably get different results) that uses x = 1:

    import decimal, sys
    out = sys.stdout.write
    D = decimal.Decimal

    def P(*args):
        [out(str(i)) for i in list(args) + ["\\n"]]

    def func(condition, delta):
        P(condition)
        P("  delta = ", delta)
        P("  (1 + delta) - 1 = ", (1 + delta) - 1)
        P("  1 + (delta - 1) = ", 1 + (delta - 1))
        P("")

    big, little = "1e-3", "1e-16"
    func("Python floating point numbers (OK):", float(big))
    func("Python floating point numbers (oops):", float(little))
    digits = 17
    decimal.getcontext().prec = digits
    func("Decimal numbers ({0} digits):".format(digits), D(big))
    func("Decimal numbers ({0} digits):".format(digits), D(little))
    digits = 400
    little = "1e-{0}".format(digits - 1)
    decimal.getcontext().prec = digits
    func("Decimal numbers ({0} digits):".format(digits), D(big))
    func("Decimal numbers ({0} digits):".format(digits), D(little))

Some observations made from the results:

    * Python's (binary) floating point arithmetic can be
      non-associative.  In other words, (a + b) + c may not be equal
      to a + (b + c).  This can be surprising the first time you come
      across it.  Also be aware that the distributive law can fail for
      binary floating point numbers.

    * Roundoff error _will_ appear in the usual (binary) floating
      point platform arithmetic, as we often use numbers like a
      negative integral power of ten that cannot be converted exactly
      to binary floating point.

    * If you're not aware of such potential problems, floating point
      calculations may surprise you and cause subtle bugs.

    * The native floating point implementation of most platforms
      wouldn't be able to handle the last calculation in the above
      code; Decimal arithmetic handles it easily and can handle
      numbers of arbitrary size (you may have to adjust the limits in
      the current context, however).

Note how the Decimal numbers in the example handled the calculations
properly -- this is what they were designed to do.

Example use case
----------------

If you're doing some calculations with the python math module and
you're not getting enough precision (e.g. due to roundoff error), you
can substitute this dmath module and see if that can improve your
results.  In your code, substitute

    import math

with

    import dmath as math

You should be able to continue calculations if you set dmath.strict to
False (otherwise you'll get exceptions for using floating point
numbers as input to the dmath functions).  If you're doing order
comparisons in your code, see the Warnings section below.  You may
have to perform some conversion of floating point constants; see the
following example.

Here's a sample of code you can run to demonstrate this ability.  In
particular, note that the constant 87.3 was converted to a string;
then the D() constructor lets it be either a float or Decimal object.

    if 0:
        import math
        D = float
    else:
        import dmath as math
        import decimal
        D = decimal.Decimal
        math.strict = False
        # Increase the calculation precision
        decimal.getcontext().prec = 25

    x1 = 473
    x2 = D("87.3")
    y1 = math.cos(x1)
    y2 = math.tan(math.sqrt(x1))
    y = y1 + x2*y2
    print("x1 = {0}".format(x1))
    print("x2 = {0}".format(x2))
    print("y1 = {0}".format(y1))
    print("y2 = {0}".format(y2))
    print("y  = {0}".format(y))

You may appreciate the benefits of such a capability to help you
quantify roundoff error in your calculations -- increase the precision
and calclate again and look at the difference in the results.  Another
approach is to use interval numbers; note that [mpmath] supports such
things.

Strict vs. Relaxed
------------------

The dmath.strict global variable controls whether the module's
function arguments must be Decimal numbers or not (they must be if
strict is True).  You can set strict to False to get relaxed
type-checking; non-Decimal numbers will be converted to Decimal
numbers.  However, you'll still probably need to change regular python
floating point code because the Decimal objects don't allow arithmetic
with floating point numbers.  This was a good design decision by
decimal's designers, but one that will probably frustrate casual users
-- if you _really_ need such things, you could probably write a new
class derived from decimal and add the requisite semantics.  Here's
the above example modified to illustrate this; in particular, note the
use of the dmath.f2d function as a type conversion (if you need to do
fussy floating point to Decimal conversions, you can change the
function this global variable points to).

    if 0:
        import math
        D = float
    else:
        import dmath as math
        import decimal
        D = math.f2d
        math.strict = False
        decimal.getcontext().prec = 25

    x1 = 473
    x2 = D(87.3)
    y1 = math.cos(x1)
    y2 = math.tan(math.sqrt(x1))
    y = y1 + x2*y2
    print("x1 = {0}".format(x1))
    print("x2 = {0}".format(x2))
    print("y1 = {0}".format(y1))
    print("y2 = {0}".format(y2))
    print("y  = {0}".format(y))

Here, instead of D being a numerical type like Decimal in the previous
example, it's now a function that returns the required type.  If this
conversion wasn't present, the line 'y = y1 + x2*y2' would fail
because it would be mixing floats and Decimal numbers.

In library code, returning NaN for e.g. a NaN argument may or may not
be the preferred thing to do.  I wanted to have a configuration option
that would let the user decide if such things resulted in an exception
or a best-attempt evaluation (i.e., sometimes I'd want a NaN argument
to stop a calculation and other times I'd just want it to propagate
through).  The global variable nan_exception in dmath.py controls what
happens when NaN or infinity are encountered in an argument.  If True,
such an argument results in an exception; if False, the calculation is
continued on a best-effort basis.  In most cases, a NaN argument will
result in a NaN returned value if nan_exception is False.

Warnings
--------

* While I've added tests that should catch obvious bugs, bugs could
  certainly remain in the code.  If you find any, I would ask you to
  please submit an issue to the http://code.google.com/p/hobbyutil/
  project.  Please include the version number of the file you used
  along with the code that demonstrates the bug.

* I do not recommend using this library for critical calculations
  (e.g., where someone's life or property could depend on the
  results).  There are likely some rough edges; these probably occur
  in regimes were most of us don't operate (and there of course could
  still be some bugs in regions where we do operate).  If you're
  interested in one area that I found during testing, look at the
  roundoff error that can occur in exp(x) when x is large enough to
  cause Decimal's Emax exceptions start to appear (you may need to
  reduce the global variable _precision_increment).  

* If you're doing fussy work with decimal.Decimal objects, I recommend
  you use strict type checking in the dmath module (set the strict
  global variable to True).  It's hard enough writing robust code that
  does numerical calculations without spending a bunch of time
  tracking down one of the floating point weirdnesses alluded to
  above.  If you want to get some more test cases, see [Cowlishaw].

* Be aware of the problems with floating point arithmetic in general,
  especially roundoff error.  Consult a text on numerical methods,
  Knuth, or have a quick read of
  http://en.wikipedia.org/wiki/Floating_point#Accuracy_problems.

* Mixing the decimal module and python float objects is not a good
  idea in general.  It can be done, but you have to be careful.  See
  [decpep] for some thoughts.
  
  The main area where I get bitten when doing this is in making order
  comparisons.  Here's an example:

        import decimal
        s = "1.234"
        x, dx = float(s), decimal.Decimal(s)
        print("First case s = '{0}'".format(s))
        if x == dx:
            print("  x == dx")
        elif x > dx:
            print("  x > dx")
        elif x < dx:
            print("  x < dx")
        else:
            print("  Can't decide")

        s = "-1.234"
        x, dx = float(s), decimal.Decimal(s)
        print("Second case s = '{0}'".format(s))
        if x == dx:
            print("  x == dx")
        elif x > dx:
            print("  x > dx")
        elif x < dx:
            print("  x < dx")
        else:
            print("  Can't decide")

  If you consider yourself a python expert, see if you can predict the
  output _without_ looking at python's documentation or python's
  source code (I certainly couldn't do this -- I wasn't even aware of
  the problem until I started writing test cases for this module).
  Then predict what you'll get under e.g.  python 2.6.5 and 3.2.2
  (hint: the results differ).  If I was going to use Decimal numbers a
  lot, I'd probably modify the e.g. Decimal.__lt__ type of functions
  to have self._convert_other() to set the 'raiseit' keyword parameter
  to True and I'd get an exception on ordering comparisons to floats.

References
----------

[AJ]
    Amin Al-Juffali wrote the AJDecimalMathAdditions implementation
    version 0.2.0 dated 20080701 (I'll call him AJ for short).  The
    provenance of AJ's code is not directly stated, but it appears
    that AJ derived some of his code from [old_dmath].  An unfortunate
    omission in AJ's code was a set of test cases; there were some
    bugs in his library.  For example, try the following:
        
        for x in range(50, 100):
            print(x, dCos(x), dSin(x))

    Such things were straightforward to fix, so I felt it was worth
    the effort of turning AJ's work into a library module.

    Relevant links are:

    http://pypi.python.org/pypi/AJDecimalMathAdditions/0.2.0
    http://www.ajgs.com/programming/PythonForDownload.html
    http://www.ajgs.com/download/AJDecimalMathAdditionsV020Unix.zip 

    The last link is the file I downloaded on 22 Mar 2012; its SHA-1
    hash was 2429072ec43bf3a1c96a82133eb9743e74ebe8e0.

[Cowlishaw]
    http://speleotrove.com/decimal/; scroll down to the dectest.zip
    file link.

[decpep]
    http://www.python.org/dev/peps/pep-0327

[mpmath]
    http://code.google.com/p/mpmath/

[old_dmath]
    This is an apparently defunct project at
    http://code.google.com/p/dmath/ that as of 22 March 2012 no longer
    contains any code; I'm surmising this was the original location of
    the dmath module from which AJ developed his code.  The copyright
    messages below credit Brian Beck and Christopher Hesse for this
    original dmath code.

[subst]
    This is a short chunk of code you could use (it's based on a
    regular expression) to substitute Decimal objects for floats in
    expressions.  See http://code.activestate.com/recipes/393265.

Acknowledgements
----------------

* Thanks to AJ for making his code available.

* A great deal of thanks to the authors and maintainers of python's
  decimal module.  And, while we're at it, thanks to all the folks who
  have created and contributed to python.

License
-------

The following applies to the changes and additions I have made to 
other people's code; see the attributions and other licenses in the
comments.

Copyright (C) 2012 Don Peterson
Contact:  gmail.com@someonesdad1
  
                         The Wide Open License (WOL)
  
Permission to use, copy, modify, distribute and sell this software and
its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice and this license appear in
all copies.  THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT EXPRESS OR
IMPLIED WARRANTY OF ANY KIND. See
http://www.dspguru.com/wide-open-license for more information.

'''

import decimal
import fractions
import math

D = decimal.Decimal
F = fractions.Fraction

# Useful constants.  When you see an expression like '+_one' in the
# code below, the unary plus is used to cause the "constant" _one to
# be converted to the current precision.  Thus, it's there for a
# reason, so don't delete it.
_zero, _one, _two, _three, _four = [D(_i) for _i in range(5)]

# If you want to have an exception raised if one of this module's
# function arguments is not a Decimal type, set strict to True.
# Otherwise, the arguments will be converted to Decimal type.  The
# conversion used may or may not be appropriate for your needs; see
# the decimal module's documentation for comments on this.  The global
# variable f2d (defined below in this file) is used as a function to
# convert python floats to Decimal objects.  If you're doing finicky
# work that requires more careful conversion, replace the default
# value of this variable with your own function.
strict = True

# The variable nan_exception controls how the functions behave when
# NaN (not a number) or infinity are received as arguments.  If True,
# then when NaN or infinity are received in a function, an exception
# is raised.  If False, the argument is allowed and the return value
# will reflect a reasonable answer given that input.
nan_exception = False

# The following increment in precision is used in each 'with' block
# for calculations.  I would recommend changing it only if you uncover
# some cases where the calculations aren't giving the correct
# precision (in which case try increasing it).
_precision_increment = 6

# Useful constants
_dnan  = D("nan")
_dinf  = D("inf")
_dninf = D("-inf")
_dnz = D("-0.0")    # Note D("+0.0") is same as _zero

# You can decide what you want returned when atan2 gets both arguments
# set to zero.  Mathematically, it's not defined -- but computer code
# can easily generate such cases, so it's handy to have a value that
# can be returned.  If you define atan2_zero_zero to be None, an
# exception is raised when the case is encountered.  If you define it
# to be the string "normal", then the behavior is the same as what is
# produced by python's math.atan2 module:
#   atan2( 0.0,  0.0) = 0
#   atan2(-0.0,  0.0) = 0
#   atan2( 0.0, -0.0) = pi
#   atan2(-0.0, -0.0) = -pi
# (If you're not familiar with signed zeros, see
# http://en.wikipedia.org/wiki/%E2%88%920_%28number%29).
# If you define it to be anything else, that value is returned
# when both arguments compare with the '==' operator to _zero.  
atan2_zero_zero = "normal" 

def _f2d(x):
    '''Converts a python float (or objects with similar semantics) to
    a Decimal number.  See the Decimal FAQ for comments on such
    things.  If you need something better, you can write another
    function and set the f2d global variable to that function.
    '''
    if isinstance(x, float):
        # This recipe is from the decimal module's documentation with
        # the python 2.6.5 distribution.
        n, d = x.as_integer_ratio()
        numerator, denominator = D(n), D(d)
        with decimal.localcontext() as ctx:
            ctx.prec += 60
            result = ctx.divide(numerator, denominator)
            while ctx.flags[decimal.Inexact]:
                ctx.flags[decimal.Inexact] = False
                ctx.prec *= 2
                result = ctx.divide(numerator, denominator)
        return +result
    else:
        # This will work with things like mpmath's mpf numbers.
        try:
            return D(str(x))
        except Exception:
            try:
                return D(repr(x))
            except Exception:
                raise

# This definition allows you to replace this function with something
# more suitable if desired.
f2d = _f2d

def CheckArguments(*args):
    '''Make sure the argument objects are Decimal type.  If strict is
    True, then all arguments must be Decimal types or an exception
    occurs.  If strict is False, an attempt is made to convert the
    arguments to Decimal types and return them in the same order as
    the args tuple.
    '''
    converted_args = []
    msg_not     = "Argument {0} is not a Decimal number"
    msg_nan     = "Argument {0} is NaN or infinity"
    msg_no_conv = "Cannot convert argument {0} to a Decimal number"
    if strict:
        # They must be Decimal numbers
        for i, arg in enumerate(args):
            if not isinstance(arg, D):
                raise ValueError(msg_not.format(i))
            else:
                if nan_exception and (arg.is_nan() or arg.is_infinite()):
                    raise ValueError(msg_nan.format(i))
                converted_args.append(arg)
    else:
        # Convert to Decimal types
        for i, arg in enumerate(args):
            if not isinstance(arg, D):
                # Our method of converting to a Decimal is simply to
                # convert the object to a string and use that for the
                # Decimal constructor.  See the warnings in the
                # decimal module's documentation about this.
                try:
                    x = D(str(arg))
                except Exception:
                    # Try repr
                    try:
                        x = D(repr(arg))
                    except Exception:
                        raise TypeError(msg_no_conv.format(i))
                if nan_exception and (x.is_nan() or x.is_infinite()):
                    raise ValueError(msg_nan.format(i))
                converted_args.append(x)
            else:
                if nan_exception and (arg.is_nan() or arg.is_infinite()):
                    raise ValueError(msg_nan.format(i))
                converted_args.append(arg)
    # We also make sure our global constants are at the current
    # calculation precision.
    _UpdateConstants()
    if len(args) > 1:
        return tuple(converted_args)
    else:
        return converted_args[0]

def _UpdateConstants():
    '''Before performing a calculation in one of this module's library
    functions, we update our global constants, as the Decimal
    precision may have changed since they were created.
    '''
    global _zero, _one, _two, _three, _four , atan2_zero_zero
    +_zero
    +_one
    +_two
    +_three
    +_four 
    if not isinstance(atan2_zero_zero, str) and atan2_zero_zero is not None:
        +atan2_zero_zero

def sqrt(x):
    '''Returns the positive square root of x.
    Domain:  real numbers >= 0.
    Range:   real numbers >= 0.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan
    elif x < 0:
        raise ValueError("Argument must be >= 0")
    elif x.is_infinite():
        return _dinf
    return x.sqrt()

def _Prec(precision):
    return D('0.' + '0'*(precision - 1) + '1')

# pi() a modified version of pi() in dmath.py v0.9.1 and
# at http://docs.python.org/lib/decimal-recipes.html

def pi():
    '''Return pi to the current precision.  Note:  in the math module,
    this is a module attribute, not a function.  In the dmath module,
    it needs to be a function so that it can be computed to current
    Decimal precision.
    '''
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        last_result, t, result, n, na, d, da, eight, thirty_two = (
            _zero, _three, _three, _one, _zero, _zero, D(24), D(8), D(32))
        while result != last_result:
            last_result = result
            n, na = n + na, na + eight
            d, da = d + da, da + thirty_two
            t = (t * n) / d
            result += t
    return (+result).normalize()

# sin() uses the Maclaurin series to evaluate the sine of a number.
#
#               x^3      x^5     x^7
# sin(x) = x - -----  + ----- - ----- ......
#                3!       5!      7!
#
# if:
#  a = (-1)^k
#  b = x^(2k+1)
#  c = (2K+1)!
# then:
#  sin(x) = sum(a*b/c) for k=0 to infinity.
#
# The following identity has been used:
#   sin(-x) = -sin(x)
#
# References:
#  The above formulas and identity were taken from:
#
#     Calculus with Analytic Geometry
#       by Howard Anton
#       1980 Edition
#
#  They can also be found online at:
#     http://en.wikipedia.org/wiki/Trigonometric_function
#     http://en.wikipedia.org/wiki/List_of_trigonometric_identities

def sin(x):
    '''Returns the sine of the angle x.
    Domain:  x is real and in radians.
    Range:   real numbers in [-1, 1].
    '''
    x = CheckArguments(x)
    if x.is_nan() or x.is_infinite():
        return _dnan
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        _UpdateConstants()
        x = _NormalizeRadians(x)
        delta, value, is_negative, i = D(x), D(x), False, 1
        error = _Prec(ctx.prec)
        if x < 0:
            is_negative, value, delta = True, -value, -delta
        x2 = x*x
        while abs(delta) > error:
            k = i << 1
            delta = -(delta*x2)/D(k*(k + 1))
            value += delta
            i += 1
        if is_negative:
            value = -value
        # Clamp output.  Unfortunately, this can hide calculational
        # bugs. :^(
        value = -_one if value < -_one else value
        value =  _one if value >  _one else value
    return (+value).normalize()

# cos() uses the Maclaurin series to evaluate the cosine of a number.
#
#               x^2      x^4     x^6
# cos(x) = 1 - -----  + ----- - ----- ......
#                2!       4!      6!
#
# if:
#  a = (-1)^k
#  b = x^(2k)
#  c = (2K)!
# then:
#  cos(x) = sum(a*b/c) for k=0 to infinity.
#
# The following identity has been used:
#   cos(-x) = cos(x)
#
# References:
#  The above formulas and identity were taken from:
#
#     Calculus with Analytic Geometry
#       by Howard Anton
#       1980 Edition
#
#  They can also be found online at:
#     http://en.wikipedia.org/wiki/Trigonometric_function
#     http://en.wikipedia.org/wiki/List_of_trigonometric_identities

def cos(x):
    '''Returns the cosine of the angle x.
    Domain:  x is real and in radians.
    Range:   real numbers in [-1, 1].
    '''
    x = CheckArguments(x)
    if x.is_nan() or x.is_infinite():
        return _dnan
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        _UpdateConstants()
        x = _NormalizeRadians(x)
        delta, value, prev, i, x2 = _one, _one, _zero, 1, x*x
        error = _Prec(ctx.prec)
        while abs(value - prev) > error:
            k = i << 1
            prev, delta = value, -(delta*x2)/D(k*(k - 1))
            value += delta
            i += 1
        if abs(value) < error:
            value = _zero
        # Clamp output.  Unfortunately, this can hide calculational
        # bugs. :^(
        value = -_one if value < -_one else value
        value =  _one if value >  _one else value
    return (+value).normalize()

# tan() uses the following identity:
#
#            sin(x)
# tan(x) =  ------- 
#            cos(x)
#
# References:
#  The above identity was taken from:
#
#     Calculus with Analytic Geometry
#       by Howard Anton
#       1980 Edition
#
#  It can also be found online at:
#     http://en.wikipedia.org/wiki/List_of_trigonometric_identities

def tan(x):
    '''Returns the tangent of the angle x.
    Domain:  x is real and in radians.
    Range:   real numbers.
    '''
    x = CheckArguments(x)
    if x.is_nan() or x.is_infinite():
        return _dnan
    # This only works if x isn't a multiple of pi/2, but it's still a
    # slight optimization.  It has to be outside of the 'with' block
    # so that it's calculated at the same precision as x.
    pio2 = pi()/2
    if x == pio2:
        return _dinf
    elif x == -pio2:
        return -_dinf
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        _UpdateConstants()
        c = cos(x)
        if c == _zero:
            if x > 0:
                return _dinf
            else:
                return -_dinf
        s = sin(x)
        if s == _zero:
            return _zero
        value = s/c
    return (+value).normalize()
  
# atan() uses the Maclaurin series (nested form) to evaluate the ArcTan of
# a number.
#
#                  x^3      x^5     x^7
# arctan(x) = x - -----  + ----- - ----- ......    (standard series)
#                   3        5       7
#
# if:
#  a = (2K-1)
#  b = (2K+1)
# then:
#  arctan(x) = x * Nested(1- (x^2)*a/b) for k=0 to infinity and abs(x) < 1
#
# The following identities have been used:
#
#   arctan(-x) = -arctan(x)
#   arctan(x)  = Pi/2 - arctan(1/x)
#   arctan(x)  = Pi/6 + arctan(y)    //see note 1
#                  where  y = (x*sqrt(3)-1) / (sqrt(3)+x) and abs(x) < 1
# References:
#  The above formulas and identity were taken from:
#
#     Calculus with Analytic Geometry
#       by Howard Anton
#       1980 Edition
#
#     Engineering Mathematics Handbook 3rd edition
#       by Jan J. Tuma
#
#     Computer Approximations
#      by John Fraser Hart
#      ISBN: 0-88275-642-7
#
#     http://en.wikipedia.org/wiki/List_of_trigonometric_identities
#
# Note 1:
# 
#  This identity is not in the references above. 
#  Here is the proof by Amin Al-Juffali:
#  
#  From the following two identities:
#  atan(x) = atan(x) + nPi , where n = 0,[+-]1, [+-]2,.....
#  atan(x) [+-] atan(y) = atan(t) [+-]pi , where t = (x[+-]y)/(1[-+]x*y)
#
#  Rearranging:
#  atan(x) = atan(y) + atan(t) ,  where t = (x-y)/(1+x*y)
#
#  Assume:
#  pi/6 = atan(y)
#
#  Then:
#  y = 1/sqrt(3)
#
#  Substitute y in t:
#  t = (x - 1/sqrt(3)) / (1 + x/sqrt(3))  
#  t = (x*sqrt(3) - 1)/sqrt(3)) / (sqrt(3) + x)/sqrt(3))
#  t = (x*sqrt(3) - 1) / (sqrt(3) + x)
#  
#  The limit of abs(x) < 1 is the limit imposed by the Maclaurin series used
#  to evaluate the atan below. If you want to test t instead of x, substitute
#  one in above t formula for x and work the algebra. Your final answer should
#  be abs(t) < (2-sqrt(3))

def atan(x):
    '''Returns the inverse tangent of x.  
    Domain:  real numbers
    Range:   real numbers in [-pi/2, pi/2]; result is in radians.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan
    retval = _zero
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        _UpdateConstants()
        Pi = pi()
        if x.is_infinite():
            if x < 0:
                retval = -Pi/_two
            else:
                retval = Pi/_two
        else:
            digits = ctx.prec
            is_negative, is_gt_one, t, a, d1 = False, False, x, _one, _one
            if t < _zero:
                is_negative, t = True, -t
            elif t == _zero:
                retval = _zero
            if t == _one:
                pio4 = Pi/_four
                retval = pio4 if is_negative else -pio4
            elif t > _one:
                is_gt_one = True
                t  = _one/t
            t = (t*_three.sqrt() - _one)/(t + _three.sqrt())
            counter = int((1.0 + 
                (float(-digits)/math.log10(abs(t))))/2.0)
            t2 = t*t
            for i in range(counter, 0, -1):
                a = d1 - a*t2*D(_two*i - 1)/D(_two*i + 1)
            retval = a*t + Pi/6
            if is_gt_one:
                retval = Pi/2 - retval
            if is_negative:
                retval = -retval
    return +retval

# Here's a table that describes the logic in the atan2 function. azz
# means it's controlled by atan2_zero_zero.  f means a finite nonzero
# number.  c means the result will be calculated normally.
#  
#                                  y
# x           +0      -0      +f      -f      +inf    -inf    nan
# ---------------------------------------------------------------------------
# +0          azz     azz     pi/2    -pi/2   pi/2    -pi/2   nan
# -0          azz     azz     pi/2    -pi/2   pi/2    -pi/2   nan
# +f          0       0       c       c       pi/2    -pi/2   nan
# -f          pi      pi      c       c       pi/2    -pi/2   nan
# +inf        0       -0      0       -0      pi/4    -pi/4   nan
# -inf        pi      -pi     pi      -pi     3pi/4   -3pi/4  nan
# nan         nan     nan     nan     nan     nan     nan     nan

def atan2(y, x):
    '''Returns the inverse tangent of y/x and gets the quadrant
    correct.
    Domain:  x and y are real numbers.
    Range:   real numbers in [-pi, pi]; result is in radians.
    '''
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        _UpdateConstants()
        x, y = CheckArguments(x, y)
        Pi, azz = pi(), "azz"
        retval = None
        if x.is_nan() or y.is_nan():
            retval = _dnan
        elif repr(x) == repr(_zero):
            if   repr(y) == repr(_zero):   retval = azz
            elif repr(y) == repr(_dnz):    retval = azz
            elif repr(y) == repr(_dinf):   retval = Pi/2
            elif repr(y) == repr(_dninf):  retval = -Pi/2
            elif y > 0:                    retval = Pi/2
            elif y < 0:                    retval = -Pi/2
            else:
                raise RuntimeError("Bug:  unanticipated case")
        elif repr(x) == repr(_dnz):
            if   repr(y) == repr(_zero):   retval = azz
            elif repr(y) == repr(_dnz):    retval = azz
            elif repr(y) == repr(_dinf):   retval = Pi/2
            elif repr(y) == repr(_dninf):  retval = -Pi/2
            elif y > 0:                    retval = Pi/2
            elif y < 0:                    retval = -Pi/2
            else:
                raise RuntimeError("Bug:  unanticipated case")
        elif repr(x) == repr(_dinf):
            if   repr(y) == repr(_zero):   retval = _zero
            elif repr(y) == repr(_dnz):    retval = _dnz
            elif repr(y) == repr(_dinf):   retval = Pi/4
            elif repr(y) == repr(_dninf):  retval = -Pi/4
            elif y > 0:                    retval = _zero
            elif y < 0:                    retval = _dnz
            else:
                raise RuntimeError("Bug:  unanticipated case")
        elif repr(x) == repr(_dninf):
            if   repr(y) == repr(_zero):   retval = Pi
            elif repr(y) == repr(_dnz):    retval = -Pi
            elif repr(y) == repr(_dinf):   retval = 3*Pi/4
            elif repr(y) == repr(_dninf):  retval = -3*Pi/4
            elif y > 0:                    retval = Pi
            elif y < 0:                    retval = -Pi
            else:
                raise RuntimeError("Bug:  unanticipated case")
        elif repr(y) == repr(_zero):
            if   x > 0:                    retval = _zero
            elif x < 0:                    retval = Pi
            else:
                raise RuntimeError("Bug:  unanticipated case")
        elif repr(y) == repr(_dnz):
            if   x > 0:                    retval = _zero
            elif x < 0:                    retval = -Pi
            else:
                raise RuntimeError("Bug:  unanticipated case")
        elif repr(y) == repr(_dinf):
            if   x > 0:                    retval = Pi/2
            elif x < 0:                    retval = Pi/2
            else:
                raise RuntimeError("Bug:  unanticipated case")
        elif repr(y) == repr(_dninf):
            if   x > 0:                    retval = -Pi/2
            elif x < 0:                    retval = -Pi/2
            else:
                raise RuntimeError("Bug:  unanticipated case")
        if retval == azz:
            # Both x and y are zero
            if atan2_zero_zero is None:
                raise ValueError("x and y can't both be zero")
            elif atan2_zero_zero == "normal":
                if repr(y) == repr(_dnz):
                    if repr(x) == repr(_dnz):
                        retval = -Pi
                    else:
                        retval = _dnz
                else:
                    if repr(x) == repr(_dnz):
                        retval = Pi
                    else:
                        retval = _zero
            else:
                retval = atan2_zero_zero
        elif retval is None:
            # Normal calculation
            if y == _zero:
                if x < _zero:
                    retval = Pi
                else:
                    retval = _zero
            else:
                arctan = atan(abs(y/x))
                if x > _zero:
                    if y > _zero:
                        retval = arctan
                    else:
                        retval = -arctan
                else:
                    if y > _zero:
                        retval = pi() - arctan
                    else:
                        retval = arctan - pi()
    return +retval


def asin(x):
    '''Returns the inverse sine of x.
    Domain:  real numbers.
    Range:   real numbers in [-pi/2, pi/2]; result is in radians.
    '''
    x = CheckArguments(x)
    if x.is_nan() or x.is_infinite() or abs(x) > _one:
        return _dnan
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        _UpdateConstants()
        retval = atan2(x, (_one - x*x).sqrt())
    return (+retval).normalize()

def acos(x):
    '''Returns the inverse cosine of x.
    Domain:  real numbers.
    Range:   real numbers in [0, pi]; result is in radians.
    '''
    x = CheckArguments(x)
    if x.is_nan() or x.is_infinite() or abs(x) > _one:
        return _dnan
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        _UpdateConstants()
        retval = atan2((_one - x*x).sqrt(), x)
    return (+retval).normalize()

# exp() uses the Maclaurin series to evaluate e^x.
#
#                x^2      x^3     x^4
# e^x = 1 + x + -----  + ----- + ----- ......    (standard series)
#                 2!       3!      4!
#
# if:
#  a = x^K
#  b = K!
# then:
#  e^x = sum(a/b) for k=0 to infinity for  x >= 0
#
# The following identities (by Amin Al-Juffali) has been used:
#
#   e^x = (e^(x/10))^10    
# 
# References:
#  The above formula was taken from:
#
#     Engineering Mathematics Handbook 3rd edition
#       by Jan J. Tuma
#
#     Some parts of the code have been borrowed and heavily modified from
#     the version that appeared in:
#
#       http://www.gnu.org/software/bc/manual/html_mono/bc.html
#        by Philip A. Nelson

def exp(x):
    '''Returns e raised to the x power.
    Domain:  real numbers.
    Range:   real numbers >= 0.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan
    elif x.is_infinite() and x == _dinf:
        return _dinf
    elif x.is_infinite() and x == -_dinf:
        return _zero
    elif x == _zero:
        return _one
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        _UpdateConstants()
        is_negative, v, n, _ten = False, x, _zero, D(10)
        if x < _zero:
            is_negative, v = True, -v
        # For extreme values of x (around 1e9 on my machine (Windows
        # XP running python 2.6.5 and 3.2.2)), we need more precision
        # than used in AJ's original code.  If you are using a Decimal
        # implementation that can deal with Decimal numbers
        # substantially larger than exp(1e9), you should test and
        # increase the extra_digits variable if necessary.  A similar
        # comment can apply for small numbers (e.g., exp(1e-9)).
        extra_digits = 10
        ctx.prec += int(math.log(ctx.prec) + 0.5 + extra_digits)
        while v >= _one:
            n += 1;
            v /= _ten
        result, tn, td, i, e, error = (1 + v, v, _one, _two, _zero, 
            _Prec(ctx.prec))
        while True:
            tn *= v
            td *= D(i)
            i += _one
            e = tn/td
            if e < error:
                break
            result += e
        while n > 0:
            result = result**10
            n -= 1
        if is_negative:
            result = _one/result
    return +result

def log10(x):
    '''Returns the base 10 logarithm of x.
    Domain:  real numbers >= 0.
    Range:   real numbers.
    '''
    x = CheckArguments(x)
    _ten = D(10)
    if x.is_nan():
        return _dnan
    elif x < 0:
        raise ValueError("Argument must be >= 0")
    elif x.is_infinite() and x == _dinf:
        return _dinf
    elif x == _zero:
       return -_dinf
    elif x == _one:
       return _zero
    elif x == _ten:
       return _one
    lx, lt = log(x), log(_ten)
    return (lx/lt).normalize()

# _ln10() 
# Uses the cubically convergent Halley iteration.
# The iteration formula appeared in:
# Reference: http://yacas.sourceforge.net/Algomanual.html

def _ln10():
    with decimal.localcontext() as ctx:
        # The +2 is crucial, along with the ctx.prec - 1 to make the
        # routine converge.
        ctx.prec += _precision_increment + 2
        _UpdateConstants()
        ln10 = '2.302585092994045684017991454684364207601101488628773'
        dv, error, result = D(10), _Prec(ctx.prec - 1), D(ln10)
        while (True):
            previous, g = result, exp(result)
            h, k = g - dv, g + dv
            m = _two*h/k
            result -= m
            if abs(result - previous) <= error:
                break
    return (+result).normalize()

# log() uses the following series to find the Logarithm.
#
# if:
#  a = (x-1)/(x+1)
#  b = a^(2k)
#  c = (1)/(2k+1)
# then:
#  Ln(x) = 2 * a * sum(b*c) for k=0 to infinity for  x > 0
#  This formula works best for 0 < x < 10
#
# The following identities has been used:
#
#   Log x  = Ln(x)/Ln(b)    
#      b
#   Log 1  = 0
#   Log X  = 1
#      X
#   Ln 1   = 0
# 
# References:
#  The above formula and identities were taken from:
#
#     Engineering Mathematics Handbook 3rd edition
#       by Jan J. Tuma

def log(x, b=None):
    '''Returns the natural logarithm of x if b is None; otherwise
    returns the logarithm of x in base b.
    Domain of x:  real numbers >= 0.
    Domain of b:  real numbers > 0.
    Range:   real numbers.
    '''
    if b is not None:
        x, b = CheckArguments(x, b)
    else:
        x = CheckArguments(x)
    if x.is_nan() or (b is not None and b.is_nan()):
        return _dnan
    if b is not None and b <= 0:
        raise ValueError("Base must be a number > 0")
    if x < 0:
        raise ValueError("Argument must be a number >= 0")
    elif x.is_infinite():
        return _dinf
    elif x == _zero:
       return -_dinf
    elif x == _one:
       return _zero
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        _UpdateConstants()
        sign, mantissa, exponent = x.normalize().as_tuple()
        k, a, _ten = len(mantissa) + exponent, 0, D(10)
        if (k > _zero):
            ctx.prec += k  # So we don't lose digits shifting to right
        while abs(x) > D(9):
           a += _one
           x /= _ten
        while abs(x) < _one:
           a -= _one
           x *= _ten
        error = _Prec(ctx.prec)
        previous, s, g, result, k = _zero, x, _one, _one, _one
        m = (s - _one)/(s + _one)
        n = m*m
        while previous != result:
           previous = result
           g *= n
           result += g/D(_two*k + 1)
           k += 1
        result *= _two*m
        result += a*_ln10()
        if b is not None:
            result /= log(b)
    return (+result).normalize()

def pow(x, y):
    '''Returns x**y, x to the power of y.
    Domain of x:  real number >= 0 (see note).
    Domain of y:  real number.
    Range:    real numbers >= 0.
 
    Note:  x can also be negative if y is an integer.
  
    Warning:  this function does not handle the special cases (e.g.,
    infinite arguments) in the same way the math module's pow function
    does.
    '''
    # Implementation note:  I've chosen to not implement all the
    # special cases as was done for python's math library.  This, of
    # course, was less work -- but it means dmath can't truly be a
    # drop-in replacment for the math module.  If someone wants to
    # write the switching logic for this so that the math module's
    # tests also pass (suitably-modified) for dmath, I'll happily
    # include the changes.
    x, y = CheckArguments(x, y)
    if x.is_nan() or y.is_nan():
        return _dnan
    elif x.is_infinite() or y.is_infinite():
        raise ValueError("Argument is infinite")
    elif x == _zero and y < 0:
        raise ValueError("0 to a negative power")
    elif x.is_signed():
        if not int(y) == y:
            raise ValueError("Negative number to non-integer power")
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        _UpdateConstants()
        result = exp(abs(y)*log(abs(x)))
        if y < 0:
            result = _one / result
        if x < 0:
            result *= -_one
    return (+result).normalize()

def _NormalizeRadians(x):
    '''x will be a Decimal number that is an argument in radians.
    Return a Decimal number that represents the same angle but in the
    range of 0 to 2*pi.

    Warning:  it's not difficult to construct examples where this
    routine fails miserably, causing significant errors in
    trigonometric function calculation.  As an example, calculate the
    sine of pi*1e60.  Start with the Decimal precision at 10 and go up
    to 80 or so and watch the differences in the calculations'
    results.
    '''
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        # Algorithm:  convert x to degrees, then convert the resulting
        # number to a fraction f.  Find n, the integer number of 360
        # degree units in f, which is n = int(f/Fraction(360, 1)).
        # From f, subtract n*Fraction(360, 1).  Return result as a
        # Decimal number converted back to radians.  Note:  it's
        # possible that python's/Decimal's facilities would allow the
        # mod operator '%' to do this work.  I wasn't sure without
        # testing and this fractional algorithm was the first of three
        # different methods that occurred to me.
        three_sixty = F(360, 1)
        f_degrees = F.from_decimal(x*D(180)/pi())
        n = int(f_degrees/three_sixty)
        norm = f_degrees - n*three_sixty
        result = D(norm.numerator)/D(norm.denominator)
        result *= pi()/D(180)  # Convert back to radians
    return +result

def e():
    '''Returns the value of e, Euler's constant and the base of 
    natural logarithms.  Note:  in the math module, this is a
    module attribute, not a function.  In the dmath module, it 
    needs to be a function so that it can be computed to current
    Decimal precision.
    '''
    return exp(_one)

def ceil(x):
    '''Returns the ceiling of x as a Decimal, the smallest
    integer value greater than or equal to x.
    Domain:  real numbers.
    Range:   real numbers with integral values.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan
    elif x.is_infinite():
        return _dinf if x == _dinf else -_dinf
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        _UpdateConstants()
        if x < 0:
            result = D(int(x))
        else:
            result = D(int(x + 1/_two))
    return (+result).normalize()

def isinf(x):
    '''Returns True if x is positive or negative infinity.
    '''
    x = CheckArguments(x)
    return x.is_infinite()

def isnan(x):
    '''Returns True if x is NaN.
    '''
    x = CheckArguments(x)
    return x.is_nan()

def hypot(x, y):
    '''Returns the Euclidean norm, sqrt(x*x + y*y).  To be compatible
    with the python math library, if one of the arguments is NaN and
    the other is infinite, you'll get an infinite result.
    '''
    x = CheckArguments(x)
    if x.is_nan() and y.is_nan():
        return _dnan
    if (x.is_nan() and y.is_infinite()) or (y.is_nan() and x.is_infinite()):
        return _dinf
    elif x.is_infinite() or y.is_infinite():
        return _dinf
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        retval = (x*x + y*y).sqrt()
    return (+retval).normalize()

def fsum(x):
    '''x is an iterable of Decimals.  Returns the sum of these
    iterables and avoids loss of precision.  If an element of x is NaN
    or infinite, then NaN is returned.
  
    Warning:  if the iterable x contains very large or very small
    numbers, this could result in long computation times.
    '''
    # See http://code.activestate.com/recipes/393090/ for ideas.
    #
    # Algorithm used here:  convert each element of x to a fraction
    # and sum.  Convert the result back to a Decimal.  This maintains
    # precision (until the final conversion back to Decimal), but pays
    # for it in potentially long calculation times.
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        retval = F(0, 1)
        for item in x:
            item = CheckArguments(item)
            if item.is_nan() or item.is_infinite():
                return _dnan
            retval += F.from_decimal(item)
        retval = D(retval.numerator)/D(retval.denominator)
    return (+retval).normalize()
    # Test case where there's a difference:
    # 
    # n = 10000
    # x = D("0.11458784587845878458784587845878458784587833333333016")
    # it = [x]*n
    # s1 = fsum(it)
    # s2 = (n*x).normalize()
    # s3 = sum(it)
    # print "fsum: ", abs(s1 - s2).normalize()
    # print "sum:  ", abs(s3 - s2).normalize()
    # exit(0)

def copysign(x, y):
    '''Return x with the sign of y.  Note copysign(Decimal(1),
    Decimal("-0.0")) returns Decimal("-1.0").
    Domain:  real numbers (both arguments).
    Range:   real numbers.
    '''
    x, y = CheckArguments(x, y)
    return x.copy_sign(y)

def fabs(x):
    '''Returns the absolute value of x.
    Domain:  real numbers.
    Range:   real numbers >= 0.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan
    elif x.is_infinite():
        return _dinf
    return abs(x).normalize()

def factorial(x):
    '''Returns x factorial.  
    Domain:  positive integers or 0.
    Range:   positive integers (as Decimal objects).
    This calculation is delegated to math.factorial.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan
    elif x != D(int(x)) or x < _zero:
        raise ValueError("Argument must be an integer >= 0")
    # Use the math module's function
    return D(math.factorial(int(x))).normalize()

def floor(x):
    '''Returns the largest integer <= x.
    Domain:  real numbers.
    Range:   integer as a Decimal number.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan
    elif x.is_infinite():
        return _dinf if x > 0 else -_dinf
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        if x == _zero:
            retval = _zero
        elif x < 0:
            retval = -ceil(abs(x))
        else:
            retval = D(int(x))
    return (+retval).normalize()

def fmod(x, y):
    '''Returns x - n*y where x and y are Decimal numbers and n is
    an integer such that the result has the same sign as x and 
    magnitude less than abs(y).
    Domain:  real numbers for both x and y.
    Range:   real numbers.
    '''
    x, y = CheckArguments(x, y)
    if x.is_nan() or y.is_nan():
        return _dnan
    elif x.is_infinite():
        raise ValueError("First argument can't be infinite")
    elif y == _zero:
        raise ValueError("Second argument can't be zero")
    if y.is_infinite():
        return x
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        sign, times = _one if x >= 0 else -_one, D(int(abs(x/y)))
        retval = sign*(abs(x) - times*y)
    return (+retval).normalize()

def frexp(x):
    '''Return the mantissa and exponent of x as the pair (m, e). m is
    a Decimal and e is an integer such that x == m * 2**e exactly. If
    x is zero, returns (0.0, 0), otherwise 0.5 <= abs(m) < 1. 
 
    Domain:  real numbers.
    Range:   first number is [0.5, 1) and second is an integer; 
             both numbers are Decimal numbers.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return (_dnan, 0)
    elif x.is_infinite():
        if x > 0:
            return (_dinf, 0)
        else:
            return (-_dinf, 0)
    elif x == _zero:
        return (_zero, 0)
    elif x == _one:
        return (1/_two, 1)
    elif x == -_one:
        return (-1/_two, 1)
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        # Get the base two log and turn it into an integer
        e = int(log(abs(x))/log(D(2)))
        m = x/pow(D(2), D(e))
        while m >= _one:
            m *= 1/_two
            e += 1
    return ((+m).normalize(), D(e))

def ldexp(x, i):
    '''Returns x*(2**i) and is essentially the inverse function of
    frexp().
    Domain:  real numbers for both x and i.
    Range:   real numbers.
    '''
    x, i = CheckArguments(x, i)
    if x.is_nan() or i.is_nan():
        return _dnan
    elif x.is_infinite() and i.is_infinite() and i < 0:
        return _dnan
    elif x.is_infinite() or i.is_infinite():
        return _dinf if x > 0 else -_dinf
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        retval = x*pow(_two, i)
    return (+retval).normalize()

def modf(x):
    '''Return the fractional and integer parts of x. Both results
    carry the sign of x and are Decimals.
    Domain:  real numbers.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan, _dnan
    elif x == _zero:
        return _zero, _zero
    elif x.is_infinite():
        if x > 0:   
            return (_zero, _dinf)
        else:
            return (_dnz, -_dinf)
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        sign = _one if x > 0 else -_one
        ip = D(int(abs(x)))
        fp = abs(x) - ip
        ip, fp = sign*ip, sign*fp
    return (+fp).normalize(), (+ip).normalize()

def trunc(x):
    '''Return the real value x truncated to an integer.  Delegates to
    x.__trunc__().
    Domain:  real numbers.
    Range:   integers (returned as a Decimal number).
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan
    elif x.is_infinite():
        return x
    try:
        # This is here for the day that we'll allow objects that
        # support truncation methods.  For now, this will always
        # result in an exception because x will be a Decimal.
        retval = D(x.__trunc__())
    except AttributeError:
        pass
    else:
        with decimal.localcontext() as ctx:
            ctx.prec += _precision_increment
            retval = int(abs(x))
            retval = retval if x >= 0 else -retval
    return D(retval).normalize()

def log1p(x):
    '''Returns the natural logarithm of 1 + x.
    Domain:  real numbers >= -1.
    Range:   real numbers.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan
    elif x.is_infinite():
        if x < 0:
            raise ValueError("Argument must be a positive infinity")
        else:
            return _dinf 
    elif x < -1:
        raise ValueError("Argument must be >= -1")
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        retval = log(1 + x)
    return (+retval).normalize()

def degrees(x):
    '''Converts angle x from radians to degrees.
    Domain:  real numbers.
    Range:   real numbers.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan
    elif x.is_infinite():
        return _dinf if x > 0 else -_dinf
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment + 4
        retval = x*D(180)/pi()
    return (+retval).normalize()

def radians(x):
    '''Converts angle x from degrees to radians.
    Domain:  real numbers.
    Range:   real numbers.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan
    elif x.is_infinite():
        return _dinf if x > 0 else -_dinf
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        retval = x*pi()/D(180)
    return (+retval).normalize()

def acosh(x):
    '''Returns the principle part of the inverse hyperbolic 
    cosine of x.
    Domain:  real numbers >= 1.
    Range:   real numbers >= 0.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan
    elif x < _one:
        raise ValueError("Argument must be >= 1")
    elif x.is_infinite():
        return _dinf
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        retval = log(x + (x*x - 1).sqrt())
    return (+retval).normalize()

def asinh(x):
    '''Returns the inverse hyperbolic sine of x.
    Domain:  real numbers.
    Range:   real numbers.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan
    elif x.is_infinite():
        if x > 0:
            return _dinf
        else:
            return -_dinf
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        retval = log(x + (x*x + 1).sqrt())
    return (+retval).normalize()

def atanh(x):
    '''Returns the inverse hyperbolic tangent of x.
    Domain:  real numbers in (-1, 1).
    Range:   real numbers.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan
    elif not (-_one < x < _one):
        raise ValueError("Argument must be in (-1, 1)")
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        retval = log((1 + x)/(1 - x))/_two
    return (+retval).normalize()

def cosh(x):
    '''Returns the hyperbolic cosine of x.
    Domain:  real numbers.
    Range:   real numbers >= 1.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan
    if x.is_infinite():
        return _dinf
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        e = exp(x)
        retval = (e + 1/e)/2
    return (+retval).normalize()

def sinh(x):
    '''Returns the hyperbolic sine of x.
    Domain:  real numbers.
    Range:   real numbers.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan
    elif x.is_infinite():
        return _dinf if x > _zero else -_dinf
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        e = exp(x)
        retval = (e - 1/e)/2
    return (+retval).normalize()

def tanh(x):
    '''Returns the hyperbolic tangent of x.
    Domain:  real numbers in (-1, 1).
    Range:   real numbers.
    '''
    x = CheckArguments(x)
    if x.is_nan():
        return _dnan
    elif x.is_infinite():
        return _one if x > _zero else -_one
    with decimal.localcontext() as ctx:
        ctx.prec += _precision_increment
        e = exp(x)
        oe = 1/e
        retval = (e - oe)/(e + oe)
    return (+retval).normalize()

# vim: wm=10
