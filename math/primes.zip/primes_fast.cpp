/*
From http://code.activestate.com/recipes/576559/.  Modified by DP in
non-critical ways 12 Oct 2009.  
 
Performance:  this will find the primes less than 100 million in about
3.4 seconds on my older computer (I put the commas in so you can grok
the magnitude):
 
    primes 100,000,000 >/dev/null
 
That's 29 million primes per second; it's no wonder people recognize
that it's much faster to compute primes than to look them up in a
table.
 
---------------------------------------------------------------------------
 
Copyright (c) 2008 Florian Mayer
 
Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:
 
The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.
 
THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
*/
 
#include <iostream>
#include <vector>
#include <string.h>
#include <cstdlib>

using namespace std;
typedef unsigned long num;
typedef vector<num> PrimeList;

PrimeList GetPrimes(num max, PrimeList & primes){
    char *sieve;
    sieve = new char[max/8+1];
    // Fill sieve with 1  
    memset(sieve, 0xFF, (max/8+1) * sizeof(char));
    for(num x = 2; x <= max; x++)
        if(sieve[x/8] & (0x01 << (x % 8))){
            primes.push_back(x);
            // Is prime. Mark multiplicates.
            for(num j = 2*x; j <= max; j += x)
                sieve[j/8] &= ~(0x01 << (j % 8));
        }
    delete[] sieve;
    return primes;
}

num GetMaxNumber(int argc, char **argv)
{
    num max;
    if (argc != 2)
    {
        cerr << "Usage:  primes number" << endl
             << "  Prints primes less than number." << endl;
        exit(1);
    }
    max = strtoul(argv[1], NULL, 10);
    return max;
}

int main(int argc, char **argv)
{
    num max = GetMaxNumber(argc, argv);
    PrimeList primes;
    primes = GetPrimes(max, primes);
    PrimeList::iterator it;
    for (it=primes.begin(); it < primes.end(); it++)
        cout << *it << endl;
    return 0;
}
