'''
Contains various routines related to prime numbers and factors.

If you run this file as a script, it will print out prime numbers and
factors.

Note:  there is a limit to the largest prime you can factor, as you'll
get a memory error.  It is on the order of 1e9, at least on my machine.

'''

# Copyright (C) 2011 Don Peterson
# Contact:  gmail.com@someonesdad1

#
# Licensed under the Open Software License version 3.0.
# See http://opensource.org/licenses/OSL-3.0.
#

from __future__ import division, print_function
import collections
import itertools
import math
import operator
import sys

from pdb import set_trace as xx

py3 = sys.version_info[0] == 3
Int = (int,) if py3 else (int, long)

if py3:
    from functools import reduce

nl = "\n"
ii = isinstance

all = [
    "Primes",
    "factor_gen",
    "PrimeList",
    "PrimeNumberSieve",
    "IsPrime",
    "Factor",
    "FactorList",
    "FormatFactors",
    "AllFactors",
]

def IsPositiveInteger(n, msg):
    if n < 1 or not ii(n, Int):
        raise ValueError(msg)

def Primes(n, show=False):
    ''' Returns a list of primes < n.  From
    http://stackoverflow.com/questions/2068372/fastest-way-to-list-all-primes-below-n-in-python/3035188#3035188
    The pure python method used here is named rwh_primes1.  If show is 
    True, print out the sieve's contents for each iteration.
    '''
    # Times on 2.5 GHz Intel quad core:
    #     log10(n)       s        num primes
    #        6           0.4      78498
    #        7           1.0      664579
    #        8           8.3      5761455
    #        9    memory error
    IsPositiveInteger(n, "n must be an integer > 0")
    def Show(count, sieve):
        if show:
            # Make a string of 0's and 1's
            s = str([0 + i for i in sieve])
            if not count:
                # Print a ruler
                print(" "*4, ("    .    |")*(len(sieve)//10))
            print("%3d " % count, s[1:-1].replace(",", "").replace(" ",
                  "").replace("0", " ").replace("1", "x"))
    sieve = [True]*(n//2)  # Boolean array representing odd numbers
    if show:
        Show(0, sieve)
    # Iterate from 3 to sqrt(n), odd numbers only
    for i in range(3, int(n**0.5) + 1, 2):
        # If this element's value is true, then set each multiple of i to
        # false by using the proper stride.  This is very fast because it
        # will all be done in C code.  The RHS is the tricky part -- it's
        # the remaining number of items in the Boolean array.
        if sieve[i//2]:
            sieve[i*i//2::i] = [False]*((n-i*i-1)//(2*i)+1)
            if show:
                Show(i, sieve)
    return [2] + [2*i + 1 for i in range(1, n//2) if sieve[i]]

def factor_gen(N):
    '''This is a generator that factors an integer N.  We get a list of
    possible factors that are primes less than N.  Then we reverse the
    list and test each factor to see if it divides N.  
 
    Example:  for N = 84, returns [7, 3, 2, 2].
    '''
    IsPositiveInteger(N, "N must be an integer > 0")
    n = N
    for i in reversed(Primes(n)):
        while n > 1 and n % i == 0: 
            yield i     # i is a factor of n
            n //= i 
        if n == 1:
            break

def PrimeList(m, n):
    '''Return a list of the primes that are between n and m inclusively.
    '''
    IsPositiveInteger(n, "n must be an integer > 0")
    IsPositiveInteger(m, "m must be an integer > 0")
    if m > n:
        m, n = n, m
    p = Primes(n + 1)
    # Find the last prime that is < m.  Put the lowest primes at the
    # end so we can efficiently use pop().
    p.reverse()
    while p and p[-1] < m:
        p.pop()
    p.reverse()
    return p

def PrimeNumberSieve(n=0):
    '''Provides an infinite generator that generates primes.  From
    http://code.activestate.com/recipes/577318-infinite-list-of-primes-yay/?in=lang-pythonhttp://code.activestate.com/recipes/577318-infinite-list-of-primes-yay/?in=lang-python
    If n is nonzero, the generator is terminated when it reaches n.
    '''
    if n:
        IsPositiveInteger(n, "n must be an integer > 0")
    D = {}
    yield 2
    for q in itertools.islice(itertools.count(3), 0, None, 2):
        p = D.pop(q, None)
        if p is None:
            D[q*q] = q
            if n and q > n:
                break
            yield q
        else:
            x = p + q
            while x in D or not (x & 1):
                x += p
            D[x] = p

def IsPrime(n):
    '''Return True if n is prime; False otherwise.
    '''
    IsPositiveInteger(n, "n must be an integer > 0")
    return False if Factor(n) else True

def Factor(n, check=False):
    '''Return a dictionary of the factors of n; the values are the power of
    each factor.  If a number is prime, an empty dictionary is returned.
    If check is True, the calculated factors are multiplied together
    to verify that the original number is gotten.
    '''
    IsPositiveInteger(n, "n must be an integer > 0")
    if n < 4:
        return {}
    factors, d = list(factor_gen(n)), collections.defaultdict(int)
    if check and factors and reduce(operator.mul, factors) != n:
        raise RuntimeError("Bug in Factor for n = %d" % n)
    if factors == [n]:
        return dict(d)  # n is prime
    for i in factors:   # Populate d with factors
        d[i] += 1
    return dict(d)

def FactorList(n, check=False):
    '''Return a sorted list of the prime factors of n.  The list will be
    empty if n is prime.  If check is True, the calculated factors are
    multiplied together to verify that the original number is gotten.
    '''
    IsPositiveInteger(n, "n must be an integer > 0")
    factors = sorted(list(factor_gen(n)))
    if check and factors and reduce(operator.mul, factors) != n:
        raise RuntimeError("Bug in FactorList for n = %d" % n)
    return factors

def FormatFactors(n, factor_dict=None):
    '''Returns a string of the prime factors of n.  The form is e.g.
        n: 2^3 3 7 11549
    If n is prime, just the number is returned with no colon character.
    If factor_dict is given, use it instead of calculating d again.
    '''
    IsPositiveInteger(n, "n must be an integer > 0")
    if factor_dict is not None:
        d = factor_dict
    else:
        d = Factor(n)
    if not d:
        return str(n)
    keys = list(d.keys())
    keys.sort()
    s = [str(n) + ":"]
    for key in keys:
        if d[key] > 1:
            s.append("%d^%d" % (key, d[key]))
        else:
            s.append("%d" % key)
    return ' '.join(s)

def AllFactors(n):
    '''Return a sorted tuple of all the integer factors of n; n must
    be greater than 1.
    '''
    IsPositiveInteger(n, "n must be an integer > 0")
    assert n > 1
    factors = list(factor_gen(n))
    all_factors = set(factors)
    for num_factors in range(2, len(factors)):
        for comb in itertools.combinations(factors, num_factors):
            all_factors.add(reduce(operator.mul, comb))
    numbers = list(all_factors)
    numbers.sort()
    return tuple(numbers)

if __name__ == "__main__":
    # If run as a script, list primes and factors.
    if 0:
        # Test Factor() over a reasonable number range
        for i in range(int(1e5)):
            Factor(i, check=True)
        print("Factor tested OK")
        exit(0)
    nl = "\n"
    def Usage():
        name = sys.argv[0]
        print('''
Usage:  {name} n [m]
  Prints primes and factors for numbers <= n or between n and m.  Each
  number is printed on a separate line with its factors; if it is prime,
  no factors and no ":" character are printed.

  Examples:
    * Show the factors of 64:
        {name} 64 64
    * Show all primes less than 100:
        {name} 100 | grep -v ":"
    * Show all numbers less than 100000 that have 911 as a factor:
        {name} 100000 | grep "\<911\>"
'''[1:-1].format(**locals()))
        exit(1)
    if len(sys.argv) == 1:
        Usage()
    m, n = 2, int(sys.argv[1])
    if len(sys.argv) == 3:
        m = int(sys.argv[1])
        n = int(sys.argv[2])
    if m < 1 or n < 1:
        raise ValueError("n and m must be integers greater than 0")
    for i in range(m, n + 1):
        print(FormatFactors(i))
