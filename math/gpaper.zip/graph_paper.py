'''
This script will generate a variety of graph papers.  All dimensions are in
inches.

To use this script, you'll need to download the g graphics library from
http://code.google.com/p/pygraphicsps/.  Just put the three python files
g.py, go.py, and gco.py into the directory where this script is and run the
script.  You'll get a number of Postscript output files.  I use GSview to
convert them to PDF files.
'''

from __future__ import print_function, division
import debug
import sys
from g import *
from pdb import set_trace as xx

debug_color = False  # Set to true to get colored lines for debugging
plot_B = False

mm2in = 1/25.4

if len(sys.argv) > 1:
    debug.SetDebugger()  # Unhandled exception goes into debugger

lw = 0.005
LW = {  # Line widths
    "x_major"   : lw,
    "x_minor1"  : lw*0.9,
    "x_minor2"  : lw*0.8,
    "x_minor3"  : lw*0.7,

    "y_major"   : lw,
    "y_minor1"  : lw*0.9,
    "y_minor2"  : lw*0.8,
    "y_minor3"  : lw*0.7,
}

if debug_color:
    C = {
        "x_major"   : dodgerblue,
        "x_minor1"  : lightblue,
        "x_minor2"  : wheat,
        "x_minor3"  : wheat,

        "y_major"   : dodgerblue,
        "y_minor1"  : lightblue,
        "y_minor1"  : wheat,
        "y_minor3"  : wheat,
    }
else:
    C = {
        "x_major"   : gray(0.5),
        "x_minor1"  : gray(0.7),
        "x_minor2"  : gray(0.8),
        "x_minor3"  : gray(0.9),

        "y_major"   : gray(0.5),
        "y_minor1"  : gray(0.7),
        "y_minor2"  : gray(0.8),
        "x_minor3"  : gray(0.9),
    }

settings = {
    "paper_width"       : 0,
    "paper_height"      : 0,
    "x_offset"          : 0,    # Plot origin from lower left corner
    "y_offset"          : 0,    # Plot origin from lower left corner

    "x_num"             : 0,    # Defines width of plot x_num*x_major
    "x_major"           : 0,    # Spacing between major plot lines
    "x_minor1"          : 0,
    "x_minor2"          : 0,
    "x_minor3"          : 0,

    "y_num"             : 0,    # Defines height of plot y_num*y_major
    "y_major"           : 0,    # Spacing between major plot lines
    "y_minor1"          : 0,
    "y_minor2"          : 0,
    "y_minor3"          : 0,

    "ignore" : {  # If True, the lines don't get plotted
        "x_major"       : False,
        "x_minor1"      : False,
        "x_minor2"      : False,
        "x_minor3"      : False,

        "y_major"       : False,
        "y_minor1"      : False,
        "y_minor2"      : False,
        "y_minor3"      : False,
    },
}

def DebugPlot():
    # Use to plot colored circles at diagonally-opposite points.  Note
    # you'll have to set the (x, y) variables appropriately for the size of
    # the paper used.
    SetUp("a.ps")
    move(0, 0)
    d = 0.3
    LineColor(red)
    circle(d)
    x, y = 297*mm2in, 210*mm2in
    x, y = 11, 8.5
    move(x, y)
    LineColor(blue)
    circle(d)

def SetUp(file, orientation=landscape, units=inches):
    '''Convenience function to set up the drawing environment and return a
    file object to the output stream.
    '''
    ofp = open(file, "w")
    ginitialize(ofp, wrap_in_PJL=0)
    setOrientation(orientation, units)
    return ofp

def LE(x, x_target):
    '''Less than or equal to, allowing for some floating point rounding.
    '''
    eps = 1e-14
    if x - x_target <= eps:
        return True
    return False

# In the following two functions, note we use the LE function instead of
# just saying e.g. "while x <= width", as this lets us get the exact number
# of lines we want.

def VerticalLines(width, dx, y0, y1):
    x = 0
    while LE(x, width):
        line(x, y0, x, y1)
        x += dx

def HorizontalLines(height, dy, x0, x1):
    y = 0
    while LE(y, height):
        line(x0, y, x1, y)
        y += dy

def Lines(key, S, LW, C):
    s = "x_" + key
    width, height = S["x_num"]*S["x_major"], S["y_num"]*S["y_major"]
    if S[s] and not S["ignore"][s]:
        LineColor(C[s])
        LineWidth(LW[s])
        VerticalLines(width, S[s], 0, height)
    s = "y_" + key
    if S[s] and not S["ignore"][s]:
        LineColor(C[s])
        LineWidth(LW[s])
        HorizontalLines(height, S[s], 0, width)

def Plot(file, S, LW, C, orientation=landscape):
    '''Plot the graph as indicated in the settings S, line widths LW, and
    colors C dictionaries.
    '''
    ofp = SetUp(file, orientation=orientation)
    push()
    translate(S["x_offset"], S["y_offset"])
    Lines("minor3", S, LW, C)
    Lines("minor2", S, LW, C)
    Lines("minor1", S, LW, C)
    Lines("major", S, LW, C)
    pop()

def Plot_5mm():  # Paper with 5 mm squares
    S, lw, c = settings.copy(), LW.copy(), C.copy()
    color = lightskyblue
    # ANSI A paper
    w, h, d = 11, 8.5, 5*mm2in
    nx, ny = 52, 40
    S["x_num"] = nx
    S["x_major"] = d
    S["y_num"] = ny
    S["y_major"] = d
    S["x_offset"] = (w - d*nx)/2
    S["y_offset"] = (h - d*ny)/2
    c["x_major"] = c["y_major"] = color
    Plot("5mm_A.ps", S, lw, c)
    # ANSI B paper (in GSview, use ledger paper, upside-down view)
    if plot_B:
        w, h, d = 17, 11, 5*mm2in
        nx, ny = 80, 50
        S["x_num"] = nx
        S["x_major"] = d
        S["y_num"] = ny
        S["y_major"] = d
        S["x_offset"] = (w - d*nx)/2
        S["y_offset"] = (h - d*ny)/2
        c["x_major"] = c["y_major"] = color
        Plot("5mm_B.ps", S, lw, c, portrait)

def Plot_QuarterInch():  # Paper with quarter inch squares
    S, lw, c = settings.copy(), LW.copy(), C.copy()
    color = lightskyblue
    # ANSI A paper
    w, h, d = 11, 8.5, 0.25
    nx, ny = 42, 32
    S["x_num"] = nx
    S["x_major"] = d
    S["y_num"] = ny
    S["y_major"] = d
    S["x_offset"] = (w - d*nx)/2
    S["y_offset"] = (h - d*ny)/2
    c["x_major"] = c["y_major"] = color
    Plot("quarter_inch_A.ps", S, lw, c)
    # ANSI B paper (in GSview, use ledger paper, upside-down view)
    if plot_B:
        w, h = 17, 11
        nx, ny = 84, 54
        S["x_num"] = nx
        S["x_major"] = d
        S["y_num"] = ny
        S["y_major"] = d
        S["x_offset"] = (w - d*nx)/2
        S["y_offset"] = (h - d*ny)/2
        c["x_major"] = c["y_major"] = color
        Plot("quarter_inch_B.ps", S, lw, c, portrait)

def Plot_Engineering():  # Paper with 0.2 inch squares, 7" x 10" 1" grid
    S, lw, c = settings.copy(), LW.copy(), C.copy()
    color = lightskyblue
    # ANSI A paper
    w, h, d = 11, 8.5, 1
    nx, ny = 10, 7
    S["x_num"] = nx
    S["x_major"] = d
    S["y_num"] = ny
    S["y_major"] = d
    S["x_offset"] = (w - d*nx)/2
    S["y_offset"] = (h - d*ny)/2  # + 0.25  # Offset for 3-ring holes
    S["x_minor1"] = d/5
    S["y_minor1"] = d/5
    c["x_major"] = c["y_major"] = color
    c["x_minor1"] = c["y_minor1"] = color
    l = 0.01
    lw["x_major"] = lw["y_major"] = l
    lw["x_minor1"] = lw["y_minor1"] = l*0.5
    Plot("engineering_A.ps", S, lw, c)

def Plot_Drafting():  # Paper with 0.1 inch squares, 8" x 10" 1" grid
    S, lw, c = settings.copy(), LW.copy(), C.copy()
    # ANSI A paper
    w, h, d = 11, 8.5, 1
    nx, ny = 10, 8
    S["x_num"] = nx
    S["x_major"] = d
    S["y_num"] = ny
    S["y_major"] = d
    S["x_offset"] = (w - d*nx)/2
    S["y_offset"] = (h - d*ny)/2
    S["x_minor1"] = d/2
    S["y_minor1"] = d/2
    S["x_minor2"] = d/10
    S["y_minor2"] = d/10
    Plot("drafting_A.ps", S, lw, c)

def Plot_LetterRuled():
    '''Paper in portrait mode with heavy horizontal lines.  Use by putting
    under another piece of paper to help guide writing on blank pages.  The
    line spacing d is tuned to what I feel comfortable with when writing
    longhand.
    '''
    S, lw, c = settings.copy(), LW.copy(), C.copy()
    # ANSI A paper
    w, h, d = 11, 8.5, 0.28
    nx, ny = 36, 28
    S["x_num"] = nx
    S["x_major"] = d
    S["y_num"] = ny
    S["y_major"] = d
    S["x_offset"] = (w - d*nx)/2
    S["y_offset"] = (h - d*ny)/2
    c["x_major"] = black
    lw["x_major"] = 0.03
    S["ignore"]["y_major"] = True
    Plot("letter_ruled_A.ps", S, lw, c)

def Dots(file, S, LW, C, orientation=landscape):
    '''Plots dots at the intersection of the major lines.  S contains the
    dot diameter under the key dot_diameter.
    '''
    ofp = SetUp(file, orientation=orientation)
    translate(S["x_offset"], S["y_offset"])
    width, height = S["x_num"]*S["x_major"], S["y_num"]*S["y_major"]
    y, dx, dy = 0, S["x_major"], S["y_major"]
    # Note we don't need to fill, as the small dots will work fine as
    # circles.  This cuts down on PDF file size by about a factor of 3.
    FillOff()
    LineColor(C["x_major"])
    while LE(y, height):
        x = 0
        while LE(x, width):
            move(x, y)
            circle(S["dot_diameter"])
            x += dx
        y += dy
    ofp.close()

def Plot_Dots():
    '''Plot dots at the intersections of the graph's lines.
    '''
    S, lw, c = settings.copy(), LW.copy(), C.copy()

    if 0:
        # Note:  there appears to be a bug in the g library, as I cannot
        # plot both of these plots successively.  This is the first serious
        # bug in the library in > 12 years of use.
        #
        # ANSI A paper, 0.2 inches
        w, h, d = 11, 8.5, 0.2
        nx, ny = 53, 41
        S["x_num"] = nx
        S["x_major"] = d
        S["y_num"] = ny
        S["y_major"] = d
        S["x_offset"] = (w - d*nx)/2
        S["y_offset"] = (h - d*ny)/2
        c["x_major"] = lightskyblue
        S["dot_diameter"] = 0.01
        Dots("dots_2tenths_A.ps", S, lw, c)
    else:
        # ANSI A paper, 5 mm
        w, h, d = 11, 8.5, 5*mm2in
        nx, ny = 54, 42
        S["x_num"] = nx
        S["x_major"] = d
        S["y_num"] = ny
        S["y_major"] = d
        S["x_offset"] = (w - d*nx)/2
        S["y_offset"] = (h - d*ny)/2
        c["x_major"] = gray(0.8)
        S["dot_diameter"] = 0.01
        Dots("dots_5mm_A.ps", S, lw, c)

if __name__ == "__main__":
    #DebugPlot()
    Plot_5mm()
    Plot_QuarterInch()
    Plot_Engineering()
    Plot_Drafting()
    Plot_LetterRuled()
    Plot_Dots()
