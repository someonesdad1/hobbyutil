from __future__ import division, print_function
import sys
from lwtest import run, raises, assert_equal
from path import (RectilinearPath, Circle, Ellipse, Sinusoid,
    EllipseCircumference, Rotation, Rectangle, IsNumberSequence,
    IsIterable, RegularPolygon, ParameterizedCurve)
from math import pi, sqrt, sin, cos
from cmath import sin as complex_sin
from decimal import Decimal
from fractions import Fraction

from pdb import set_trace as xx
 
pyver = sys.version_info[0]
if pyver > 2:
    long = int
    String = str
else:
    String = (str, unicode)

try:
    from mpmath import mpf
except ImportError:
    mpf = float

sequence = (
    (0, int(0)),
    (1, long(1)),
    (2, float(2)),
    (3, Decimal(3)),
    (4, Decimal("4.0")),
    (5, Fraction("15/3")),
)
param = (-1, 1)
rp = RectilinearPath(sequence, param)
sr2, sr3 = sqrt(2), sqrt(3)
eps = 1e-15

def TestEuclideanDistance():
    assert(all([i == sr2 for i in rp.lengths]))

def TestProperties():
    # Length:  number of points
    assert(len(rp) == len(sequence))
    # Property dim:  dimension of Euclidean space
    assert(rp.dim == len(sequence[0]))
    # Property seq:  sequence of points in Euclidean space as floats
    x = tuple([(float(i), float(i)) for i in range(len(rp))])
    assert(rp.seq == x)
    # Property path_length:  total length of all subpaths
    assert(rp.total_arc_length == 
                    (len(rp) - 1)*sr2)
    # Property lengths:  tuple of lengths of subpaths
    lengths = (sr2,)*(len(rp) - 1)
    assert(rp.lengths == lengths)
    # Property parameter:  tuple of low & high parameter values
    assert(rp.parameter == param)

def Test_2_space():
    seq = ((0, 0), (1, 1), (2, 2))
    rp = RectilinearPath(seq)
    assert(rp.lengths == (sr2, sr2))
    assert(rp(0) == seq[0])
    assert(rp(0.5) == seq[1])
    assert(rp(1) == seq[2])

def Test_3_space():
    seq = ((1, 1, 1), (2, 2, 2), (3, 3, 3))
    rp = RectilinearPath(seq)
    assert(rp.lengths == (sr3, sr3))
    assert(rp(0) == seq[0])
    assert(rp(1) == seq[-1])

def TestLength():
    seq = ((0, 0), (1, 1), (2, 2))
    rp = RectilinearPath(seq)
    assert(rp.length(0) == 0)
    assert(rp.length(0.5) == sr2)
    assert(rp.length(1) == 2*sr2)

def TestCircle():
    c = Circle((0, 0), 2, parameter=[0, 360])
    c.eps = eps
    for deg, res in (
        ( 0,  ( 1,  0)),
        (90,  ( 0,  1)),
        (180, (-1,  0)),
        (270, ( 0, -1)),
        (360, ( 1,  0)),
    ):
        assert(c(deg) == res)

def TestEllipse():
    #----------------------------------------------------------
    # Map the parameter onto [0, 360] (i.e., degrees of angle);
    # then at 45 degrees with a flattening of 1/2, the height
    # should be half the x value.
    ff = 45
    c = Ellipse((0, 0), 2, 1, parameter=(0, 360))
    x, y = c(1*ff)
    assert(abs(x - sr2/2) - eps)
    assert(abs(y == x/2) - eps)
    # Also should work similarly at other angles mod 45 degrees
    x, y = c(3*ff)
    assert(abs(-x - sr2/2) - eps)
    assert(abs(y == -x/2) - eps)
    #
    x, y = c(5*ff)
    assert(abs(-x - sr2/2) - eps)
    assert(abs(y == x/2) - eps)
    #
    x, y = c(7*ff)
    assert(abs(x - sr2/2) - eps)
    assert(abs(y == -x/2) - eps)
    # Check attributes
    assert(c._a == 2)
    assert(c._b == 1)
    circumference = 4.8442241102738377
    assert(c.total_arc_length == circumference)
    # Show can change parameter tuple by attribute.  We'll use the
    # last value of (x, y) to confirm.
    c.parameter = (0, 1)
    res = c(7/8)  # At 315 degrees
    assert(res == (x, y))
    c.parameter = (0, 360)
    res = c(315)
    assert(res == (x, y))
    # eps
    x, y = c(90)
    assert(x != 0 and abs(x) < eps)
    c.eps = eps
    x, y = c(90)
    assert(x == 0)
    # complex
    x, y = c(ff)
    c.complex = True
    z = c(ff)
    assert(z.real == x and z.imag == y)
    c.complex = False
    # xfm  Transform point after the call c()
    def f(x, y, x0=1):
        # Translate origin to (x0, 0)
        return x - x0, y
    x, y = c(ff)
    c.xfm = f
    x1, y1 = c(ff)
    assert(x1 == x - 1 and y == y1)
    # xfm_kw
    c.xfm_kw = {"x0" : 2}
    x1, y1 = c(ff)
    assert(x1 == x - 2 and y == y1)
    # is_closed
    assert(c.is_closed == True)
    # Clockwise
    c = Ellipse((0, 0), 2, 2, cw=True)  # This is actually a unit circle
    c.parameter = (0, 360)
    c.eps = eps
    c(90)
    assert(c(90) == (0, -1))
    # angle_origin
    c.angle_origin = pi/2
    assert(c(90) == (1, 0))

def EllipticE(k):
    '''Returns the complete elliptic integral of the 2nd kind for
    modulus k.  From Robert Weaver's website:
        http://electronbunker.sasktelwebsite.net/CalcMethods2c.html
    '''
    if k == 1:
        return 1
    else:
        kk, c, a, ci, co = k*k, 1, 1, 1, 2
        b = sqrt(1-kk)
        E = 1 - kk/2
        while c < co:
            co = c
            c = (a - b)/2
            E = E - ci*c*c
            ao = (a + b)/2
            b = sqrt(a*b)
            ci *= 2
            a = ao
        return E*pi/(a + a)

def TestEllipseCircumference():
    # Check with unit circle, as it's easy to calculate
    assert_equal(EllipseCircumference(2, 2), 2*pi)
    # True ellipses
    a, b = 2, 1
    k = sqrt(1 - (b/a)**2)
    assert_equal(EllipseCircumference(a, b), 2*a*EllipticE(k))
    a, b = 200, 1
    k = sqrt(1 - (b/a)**2)
    assert_equal(EllipseCircumference(a, b), 2*a*EllipticE(k), reltol=eps)

def TestRotation():
    r = Rotation(pi/2)
    assert_equal(r(1, 0), (0, 1), abstol=eps)
    r.theta = pi
    assert_equal(r(1, 0), (-1, 0), abstol=eps)
    r.theta = 3*pi/2
    assert_equal(r(1, 0), (0, -1), abstol=eps)
    r.theta = 2*pi
    assert_equal(r(1, 0), (1, 0), abstol=eps)

def TestRectangle():
    r = Rectangle((0, 0), 2, 2)
    assert(r(0) == (-1, -1))
    assert(r(1/4) == (1, -1))
    assert(r(1/2) == (1, 1))
    assert(r(3/4) == (-1, 1))
    assert(r(1) == (-1, -1))
    r.complex = True
    assert(r(0) == -1-1J)
    assert(r(1/4) == 1-1J)
    assert(r(1/2) == 1+1J)
    assert(r(3/4) == -1+1J)
    assert(r(1) == -1-1J)
    assert(r.total_arc_length == 8)
    r = Rectangle((0, 0), 1, 10)
    assert(r.total_arc_length == 22)

def TestIsNumberSequence():
    assert(not IsNumberSequence("abc", 1))
    assert(not IsNumberSequence((1, "abc"), 2))
    assert(IsNumberSequence((1,), 1))
    assert(IsNumberSequence((1, 2), 2))
    assert(IsNumberSequence(range(10), None))
    # The following is True because "2" can be converted to the base
    # number type.
    assert(IsNumberSequence((1, "2"), 2))

def TestIsIterable():
    assert(not IsIterable("", 0))
    assert(not IsIterable("ab", 2))
    assert(IsIterable((0,), 1))
    assert(IsIterable((0, 1), 2))
    assert(IsIterable([0], 1))
    assert(IsIterable([0, 1], 2))
    assert(IsIterable([0, "1"], 2))

def TestRegularPolygon():
    # Square
    p = RegularPolygon((0, 0), 4, 2)
    p.eps = eps
    assert(p(0) == (1, 0))
    assert(p(1/4) == (0, 1))
    assert(p(1/2) == (-1, 0))
    assert(p(3/4) == (0, -1))
    assert(p(1) == (1, 0))
    # Hexagon
    p = RegularPolygon((0, 0), 6, 2)
    p.eps = eps
    assert(p(0) == (1, 0))
    assert_equal(p(1/6), (1/2, sr3/2), abstol=eps)
    assert_equal(p(2/6), (-1/2, sr3/2), abstol=eps)
    assert_equal(p(3/6), (-1, 0), abstol=eps)
    assert_equal(p(4/6), (-1/2, -sr3/2), abstol=eps)
    assert_equal(p(5/6), (1/2, -sr3/2), abstol=eps)
    assert(p(6/6) == (1, 0))

def TestRectilinearPath():
    # Path from origin to (1, 0)
    p = RectilinearPath(((0, 0), (1, 0)))
    for i in (0, 1/8, 1/7, 1/4, 1/2, 3/4, 1):
        assert(p(i) == (i, 0))
    assert(p.dim == 2)
    assert(p.seq == ((0, 0), (1, 0)))
    assert(p.lengths == (1,))
    # Path from origin to (1, 1)
    p = RectilinearPath(((0, 0), (1, 1)))
    for i in (0, 1/8, 1/7, 1/4, 1/2, 3/4, 1):
        p.complex = False
        assert(p(i) == (i, i))
        p.complex = True
        assert(p(i) == i+i*1J)
    # 3-D space from origin to (1, 1, 1)
    p = RectilinearPath(((0, 0, 0), (1, 1, 1)))
    for i in (0, 1/8, 1/7, 1/4, 1/2, 3/4, 1):
        assert_equal(p(i), (i, i, i), abstol=eps)
    assert(p.dim == 3)
    assert(p.seq == ((0, 0, 0), (1, 1, 1)))
    assert(p.lengths == (sr3,))
    with raises(ValueError):
        p.complex = True
    # 4-D space from origin to (1, 1, 1, 1)
    p = RectilinearPath(((0, 0, 0, 0), (1, 1, 1, 1)))
    for i in (0, 1/8, 1/7, 1/4, 1/2, 3/4, 1):
        assert_equal(p(i), (i, i, i, i), abstol=eps)
    assert(p.dim == 4)
    assert(p.seq == ((0, 0, 0, 0), (1, 1, 1, 1)))
    assert(p.lengths == (2,))
    with raises(ValueError):
        p.complex = True

def TestSinusoid():
    A = 22.3
    s = Sinusoid(A=A)
    s.eps = A*eps
    assert(s(0) == (0, 0))
    assert(s(1/4)[1] == A)
    assert(s(1/2)[1] == 0)
    assert(s(3/4)[1] == -A)
    assert(s(1)[1] == 0)
    assert(s(2)[1] == 0)
    # Cosine
    s = Sinusoid(A=A, phase=1/4)
    s.eps = A*eps
    assert(s(0) == (0, A))
    assert(s(1/4)[1] == 0)
    assert(s(1/2)[1] == -A)
    assert(s(3/4)[1] == 0)
    assert(s(1)[1] == A)

def TestNumberTypes():
    # Check that we can construct paths using other number types.
    # Note int and long can't be used.
    for t in (float, Fraction, Decimal, mpf):
        s = Sinusoid(number_type=t)
        assert(type(s(0)[1]) == type(t(0)))

def TestResidue():
    # Integrate sin(z)/z**4 around the unit circle (pg. 675, Kreyszig,
    # "Advanced Engineering Mathematics", 2nd ed., Wiley, 1967).
    def f(z):
        return complex_sin(z)/z**4
    n, answer, s = 1000, -pi*1J/3, 0
    # Note the convenience of being able to set the parameterization.
    c = Circle(parameter=(0, n))
    c.complex, c.eps = True, eps
    for i in range(n):
        z = c(i)
        dz = c(i + 1 % n) - z
        s += f(z)*dz
    # The test passes if the absolute values are nearly equal
    assert_equal(abs(s), abs(answer), abstol=1e-5)

def TestParameterizedCurve():
    # Generate a parameterized unit circle and compare its output to a
    # Circle() object.
    n = 360
    X, Y = lambda x:  cos(2*pi*x/n), lambda x:  sin(2*pi*x/n)
    c = Circle(parameter=[0, n])
    d = ParameterizedCurve((X, Y), parameter=[0, n])
    for i in range(n):
        assert_equal(c(i), d(i), abstol=eps)

if __name__ == "__main__":
    exit(run(globals())[0])
