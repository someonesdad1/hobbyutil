'''Calculate parameters of an Archimedean spiral.  The units of length are
arbitrary; the program assumes that the diameters, lengths, and thicknesses
all have the same physical unit.
 
Examples:
    1.  I have a toilet paper roll.  The paper is 0.068 mm thick, the
 
        roll is 120 mm in outside diameter, and the inside diameter is 44
        mm.  What is the length of paper on the roll?
 
            Choose problem 1; enter t = 0.068, D = 120, d = 44.  Get
                n = 558.824 turns
                L = 143959 mm = 144 m
 
    2.  How big in diameter will be 1000 turns of sheet metal 0.01 units
        thick?
            Choose problem 3; enter number of turns n and thickness t.  Get
                L = 31415.9
                D = 20
 
    3.  I have a piece of 2" steel pipe that has an ID of 2.07 inches.  If
        a US dollar bill is 6.1 inches long, 2.61 inches wide, and
        0.0043 inches thick, how many dollar bills could I roll up and
        put into the pipe?
            Choose problem 1 and input t = 0.004, D = 2.07, d= 0.  Get
                L = 782.6"
                n = 240.7
        If we take int(782.6/6.1), we get 128 bills.  Practically, there
        are some physical limitations that would reduce this number.  The
        bills couldn't be wound tightly starting from zero radius.  You'd
        also probably want to use some tape to hold the ends of the bills
        together; this would add to the thickness, reducing the number of
        bills in the roll.  Finally, bills that had been crumpled probably
        wouldn't lie quite as flat as new bills.  I would thus probably
        reduce the estimate by 10-20% and declare the amount to be 100
        bills.  Thus, if the bills were $100 bills, a 2 inch pipe
        could then store $10k for every 2.7 inches of length.
'''
 
# Copyright (C) 2010 Don Peterson
# Contact:  gmail.com@someonesdad1
 
#
# Licensed under the Open Software License version 3.0.
# See http://opensource.org/licenses/OSL-3.0.
#
 
from __future__ import print_function, division
import sys
from math import *
from u import u, fromto, ParseUnit
from pnumber import PhysicalNumber as PN, PhysicalNumberFactory

from pdb import set_trace as xx
if 1:
    import debug
    debug.SetDebugger()

py3 = True if sys.version_info[0] > 2 else False
if not py3:
    input = raw_input

# Number of significant figures for calculations
PN.digits = 6

problem_description = '''
Select the problem to solve (enter nothing or q to quit):
    1.  Have D, d, and t; want n and L.
    2.  Have L and t; want n and D.
    3.  Have n and t; want D and L.
    4.  Print the equations that are used.
'''

# Format string for printing results of calculations
fmt = "%.6g"

def NewtonRaphson(f, fd, x, tolerance=1e-9, maxit=200, show=False):
    '''Newton-Raphson algorithm for solving f(x) = 0 where a root is
    repeatedly estimated by xnew = x - f(x)/f'(x) until
    |dx|/(1+|x|) < tolerance is achieved. This termination condition
    is a compromise between |dx| < tolerance, if x is small;
    |dx|/|x| < tolerance, if x is large.
 
    Adapted from
    http://www.phys.uu.nl/~haque/computing/WPark_recipes_in_python.html
    '''
    # f is the function; fd is its derivative.
    count = 0
    while 1:
        dx = f(x) / float(fd(x))
        if abs(dx) < tolerance * (1 + abs(x)):
            return x - dx
        x = x - dx
        count += 1
        if count > maxit:
            raise Exception("Too many iterations")
        if show:
            print("NewtonRaphson[%d]: x = %s" % (count, x))

def PrintReport(D, d, t, n, L, theta):
    fig = L.digits
    deg = theta*180/pi
    print('''
Significant figures = {fig}
Outside diameter    = {D}
Inside diameter     = {d}
Thickness           = {t}
Number of turns     = {n}
Length              = {L}
Angle               = {theta} rad = {deg} deg'''.format(**locals()))

def GetNum(msg, zero_ok=False, is_length=True):
    '''Prompt for the number; if is_length is True, the dimension of the
    unit must be a length.  Either a Length() object or float is
    returned.
    '''
    e = "Number must be {} 0".format(">" + "="*zero_ok)
    while True:
        print(msg, end=" ")
        s = input().strip()
        if not s or s.lower() == "q":
            exit(0)
        try:
            if is_length:
                num = Length(s)
            else:
                num = float(s)
            if (num < 0) or (not num and not zero_ok):
                print(e)
            return num
        except Exception:
            print("'{}' is not a valid length".format(s))

def Problem1():
    '''Given D, d, t find n, L.
 
    Test case:
        D = 1000 m
        d =    0 m
        t =    0.001 m
    gives
        n = 5000000.0
        L = 7.85398e12 mm
        Angle = 3.14159e+07 rad = 1.8e+09°
    '''
    if 1:
        D = GetNum("Outside diameter = D =")
        d = GetNum("Inside diameter  = d =", zero_ok=True)
        t = GetNum("Thickness        = t =")
    else:
        D = PN("1000 m")
        d = PN("0 m")
        t = PN("0.1 mm")
    # Calculation assuming D
    nD = float(D/(2*t))     # float() makes dimensionless
    thetaD = 2*pi*nD
    aD = t/(2*pi)
    AD = sqrt(thetaD*thetaD + 1)
    LD = aD*(thetaD*AD + log(thetaD + AD))/2
    # Calculation assuming d
    nd = float(d/(2*t))
    thetad = 2*pi*nd
    ad = t/(2*pi)
    Ad = sqrt(thetad*thetad + 1)
    Ld = ad*(thetad*Ad + log(thetad + Ad))/2
    # Calculate results
    n = nD - nd
    theta = PN(thetaD - thetad)
    L = LD - Ld
    PrintReport(D, d, t, n, L, theta)

def Problem2():
    '''Given L, t find n, D.  Assumes d = 0.
    Test case:
        L = 7.85398e12 mm
        t = 0.1 mm
    gives
        Outside diameter    = 1000000 mm
        Number of turns     = 4999999.479889938
        Length              = 7.85398e12 mm
        Angle               = 31415923.26795003 rad = 1799999812.7603774 deg
    '''
    if 1:
        L = GetNum("Length           = L =")
        t = GetNum("Thickness        = t =")
    else:
        L = PN("7.85398e12 mm")
        t = PN("0.1 mm")
    a = t/(2*pi)
    # We need to find a root for theta; use Newton-Raphson.
    f = lambda x: (a/2*(x*sqrt(x*x + 1) + log(x + sqrt(x*x + 1))) - L)
    fd = lambda x: (a/2*(sqrt(x*x+1) + 2*x*x/sqrt(x*x+1) +
                    (1 + 2*x/sqrt(x*x+1))/(x + sqrt(x*x+1))))
    # Initial guess
    theta = sqrt(float(L/(2*a)))
    theta = NewtonRaphson(f, fd, theta)
    n = theta/(2*pi)
    D = 2*n*t
    d = PN(0)
    PrintReport(D, d, t, n, L, theta)

def Problem3():
    '''Given n, t find L, D.  Assumes d = 0.
    Test case:
        n = 5e6
        t = 0.1 mm
    gives
        Outside diameter    = 1.00000e6 mm
        Inside diameter     = 0.00000
        Length              = 7.85398e12 mm
        Angle               = 31415926.535897933 rad = 1800000000.0 deg
    '''
    if 1:
        n = GetNum("Number of turns  = n =", is_length=False)
        t = GetNum("Thickness        = t =")
    else:
        n = 5e6
        t = PN("0.1 mm")
    a = t/(2*pi)
    theta = 2*pi*n
    A = sqrt(theta*theta + 1)
    L = a/2*(theta*A + log(theta + A))
    D = 2*n*t
    d = PN(0)
    PrintReport(D, d, t, n, L, theta)

def PrintEquations():
    print('''
                        Equations
                        ---------
 
The arc length L is gotten from integrating the polar equation
of an Archimedean spiral:  r = a*theta.

    L = a/2*(theta*A + ln(theta + A))   = length
      where A = sqrt(theta*theta + 1)
    theta = 2*pi*n                      = angle of rotation
    D = 2*n*t                           = outside diameter
    t = 2*pi*a                          = thickness of material

While the equations are exact, the numbers are most meaningful when
t << D.
'''[1:-1])

def GetDefaultLengthUnit():
    default_unit = "mm"
    print("\nEnter default length unit [{}]:  ".format(default_unit), end="")
    while True:
        s = input().strip()
        if not s:
            s = "mm"
            break
        elif s.lower() == "q":
            exit(0)
        else:
            try:
                # See if it's a valid length unit
                if u.dim(s) == u.dim("m"):
                    break
            except Exception as e:
                pass
            print("Not a valid length unit -- try again:  ", end="")
    return s

if __name__ == "__main__":
    print('''
Dimensions of a Archimedean spiral
----------------------------------
      Given a material of uniform thickness t of length L wound in a
      spiral of n turns.  A roll of this material will have an outside
      diameter D and an inside diameter d (can be zero).  Ideally, t <<
      D; if t and D are comparable, then only the calculations for theta
      and L are exact; calculated values for n and D will be
      approximate.  Use any common physical length units.
'''[1:-1])
    default_unit = GetDefaultLengthUnit()
    Length = PhysicalNumberFactory(default_unit)
    while True:
        print(problem_description)
        problem = GetNum("Problem?", zero_ok=True, is_length=False)
        if problem == 1:
            Problem1()
            break
        elif problem == 2:
            Problem2()
            break
        elif problem == 3:
            Problem3()
            break
        elif problem == 4:
            PrintEquations()
            break
        else:
            print("Unrecognized problem number")
            exit(1)

#----------------------------------------------------------------------
"""ToDo:  Add an option to plot a spiral:

    from math import sqrt, sin, cos, pi, log
    from g import *
    def DrawSpiral(file, a, theta1, theta2):
        '''Generate a PostScript file showing a spiral.
        '''
        import pdb, sys, string
        wrap_in_PJL = 0
        def SetUp(file, orientation=portrait, units=inches):
            '''Convenience function to set up the drawing environment and
            return a file object to the output stream.
            '''
            ofp = open(file, "w")
            ginitialize(ofp, wrap_in_PJL)
            setOrientation(orientation, units)
            return ofp
        def Seq(start, stop, increment):
            N = int((stop - start)/increment) + 1
            return [start + i*increment for i in range(N)]
        def Rect(r, theta):
            return (r * cos(theta), r * sin(theta))
        def Draw(num_revolutions, a, dtheta, cw=0):
            push()
            move(0, 0)
            xlast, ylast = 0, 0
            for theta in Seq(0, num_revolutions*pi, dtheta):
                if cw:
                    theta = -theta
                x, y = Rect(r=a*theta, theta=theta)
                line(xlast, ylast, x, y)
                xlast, ylast = x, y
            pop()
        def main():
            ofp = SetUp(file, landscape)
            translate(11/2, 8.5/2)
            # Polar equation of an archimedian spiral is r = a*theta
            Nrevolutions = 10
            dtheta = pi/100
            Draw(Nrevolutions, a, dtheta)
            ofp.close()
        main()
    DrawSpiral("a.ps", 0.1, 0, 10*pi)
    exit()
"""
