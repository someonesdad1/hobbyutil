'''
Functions to calculate a solution to Kepler's equation.  Ref. Meeus
"Astronomical Algorithms", pg 206.

----------------------------------------------------------------------

The equation is E = M + e*sin(E).  E is to be solved for given M and
e.  M will be between 0 and 2*pi and e >= 0.

The iterative methods include a third parameter precision, which is
what two successive iterations must be less than for the function to
return.

SolveKepler1 and SolveKepler2 return a tuple (E, n) where E is the
eccentric anomaly and n is the number of iterations to get the answer.
SolveKepler3 just returns E.  The test examples demonstrate how much
faster Newton's method is over plain iteration.
'''

# Copyright (C) 2002 Don Peterson
# Contact:  gmail.com@someonesdad1

#
# Licensed under the Open Software License version 3.0.
# See http://opensource.org/licenses/OSL-3.0.
#

from __future__ import division, print_function
import math
import sys
from frange import frange

all = ["Kepler"]

allowed_iterations = 120
d2r = math.pi/180
r2d = 1/d2r
twopi = 2*math.pi
pio2 = math.pi/2
signum = lambda x: 0 if not x else -1 if x < 0 else 1

def Kepler(m, e, abstol=1e-8, algorithm=3):
    '''Call one of the Kepler equation solving methods.  Return the
    value of E (eccentric anomaly) and the number of iterations
    required.
    '''
    def SolveKepler0(m, e, abstol=1e-8):
        '''Use simple iteration to the indicated precision.
        '''
        E0, E, count = m/2, m, 0
        while abs(E - E0) > abstol/10 and count <= allowed_iterations:
            E0 = E
            count += 1
            E = m + e*math.sin(E0)
        if count > allowed_iterations:
            msg = "Too many iterations ({0}) in SolveKepler1"
            raise ValueError(msg.format(count))
        return (E, count)
    def SolveKepler1(m, e, abstol=1e-8):
        '''Use Newton's method to solve for the root.
        '''
        E0, E, count = m/2, m, 0
        while abs(E - E0) > abstol and count <= allowed_iterations:
            E0 = E
            count += 1
            E = E0 + (m+e*math.sin(E0)-E0)/(1-e*math.cos(E0))
        if count > allowed_iterations:
            msg = "Too many iterations ({0}) in SolveKepler2"
            raise ValueError(msg.format(count))
        return (E, count)
    def SolveKepler2(m, e, abstol=1e-8):
        '''SolveKepler3 uses Sinnott's binary search algorithm.  abstol is
        ignored.
        '''
        m, f = math.fmod(m, twopi), 1
        m = m + twopi if m < 0 else m
        if m > math.pi:
            m, f = twopi - m, -1
        e0, d = pio2, pio2/2
        for i in range(1, 54, 1):
            m1 = e0 - e*math.sin(e0)
            e0 = e0 + d*signum(m - m1)
            d = d/2
        return (e0*f, 54)
    def SolveKepler3(m, e, abstol=1e-8):
        '''Translated from C code at
        http://www.projectpluto.com/kepler.htm.  "Meeus" refers to
        "Astronomical Algorithms" by J. Meeus.  I've modified the routine
        slightly for e < 0.3 because it was not converging to the desired
        precision.  It also required adding checks for too many iterations.
        '''
        neg, count, thresh = False, 0, abstol*math.fabs(1 - e)
        if not m:
            return (0, 0)
        if e < 0.3:     # Low-eccentricity formula from Meeus, p. 195
            curr = math.atan2(math.sin(m), math.cos(m) - e)
            err = curr - e*math.sin(curr) - m
            while math.fabs(err) > thresh:
                curr -= err/(1 - e*math.cos(curr))
                err = curr - e*math.sin(curr) - m
                if count > allowed_iterations:
                    msg = ("Too many iterations ({0}) in SolveKepler3 "
                           "for e < 0.3 case")
                    raise ValueError(msg.format(count))
                count += 1
            return (curr, count)
        if m < 0:
            m = -m
            neg = True
        curr = m
        if e > 0.8 and m < math.pi/3 or e > 1:  # Up to 60 degrees
            trial = m/math.fabs(1 - e)
            if trial**2 > 6*math.fabs(1 - e):   # Cubic term is dominant
                if m < math.pi:
                    trial = (6*m)**(1/3)
                else:  # Hyperbolic w/ 5th & higher-order terms predominant
                    trial = asinh(m/e)
            curr = trial
        if e < 1:
            err = curr - e*math.sin(curr) - m
            while math.fabs(err) > thresh:
                curr -= err/(1 - e*math.cos(curr))
                err = curr - e*math.sin(curr) - m
                if count > allowed_iterations:
                    msg = ("Too many iterations ({0}) in SolveKepler3 "
                           "for e < 1 case")
                    raise ValueError(msg.format(count))
                count += 1
        else:
            err = e*math.sinh(curr) - curr - m
            while math.fabs(err) > thresh:
                curr -= err/(e*math.cosh(curr) - 1)
                err = e*math.sinh(curr) - curr - m
                if count > allowed_iterations:
                    msg = ("Too many iterations ({0}) in SolveKepler3 "
                           "for e >= 1 case")
                    raise ValueError(msg.format(count))
                count += 1
        curr = -curr if neg else curr
        return (curr, count)
    if algorithm == 0:
        return SolveKepler0(m, e, abstol=abstol)
    elif algorithm == 1:
        return SolveKepler1(m, e, abstol=abstol)
    elif algorithm == 2:
        return SolveKepler2(m, e, abstol=abstol)
    elif algorithm == 3:
        return SolveKepler3(m, e, abstol=abstol)
    else:
        raise ValueError("Bad algorithm number")

def Show(m, e, p):
    def P(N, E, n, p, s):
        digits = int(math.log10(1/p)) + 1
        msg = "  Method {N} = {E:.{digits}f} n = {n:2}  ({s})"
        print(msg.format(**locals()))
    E, n = Kepler(m*d2r, e, p, algorithm=0)
    P(1, E, n, p, "Simple iteration")
    E, n = Kepler(m*d2r, e, p, algorithm=1)
    P(2, E, n, p, "Newton's method")
    E, n = Kepler(m*d2r, e, algorithm=2)
    P(3, E, n, p, "Sinnott's binary search")
    E, n = Kepler(m*d2r, e, p, algorithm=3)
    P(4, E, n, p, "Projectpluto algorithm")
    print()

if __name__ == "__main__":
    # Show some example cases
    p = 1e-15
    Show(90, 1/2, p)
    Show(80, 1/3, p)
    Show(40, 1/8, p)
