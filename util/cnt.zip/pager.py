'''
- Make the pager work with marked text like is done in cal.py (\x00
  bytes to flag a color change).  The following byte can contain the
  foreground and background color, as it's usable directly by wconio.

- Allow the pager to have different vertical windows which can be
  paged independently.  For example, the year display of the cal.py
  script could be displayed at the top and the list of all the events
  for that year could be in a lower window.

- Since the typical use scenario is in some other script, the Pager
  object needs to have an interface that can be mixed in with other
  objects.  In particular, the containing object needs to be able to
  override the Loop() and control how the information is displayed.

----------------------------------------------------------------------
Provide a Pager object that can be used to provide paging
functionality.  The things that are paged are objects that represent a
line of text.  These objects know how to display themselves to stdout.
'''[:-1]

# Copyright (C) 2014 Don Peterson
# Contact:  gmail.com@someonesdad1

#
# Licensed under the Open Software License version 3.0.
# See http://opensource.org/licenses/OSL-3.0.
#
import sys
import wconio as w
from color import (black, blue, green, cyan, red, magenta, brown, white,
                   gray, lblue, lgreen, lcyan, lred, lmagenta, yellow,
                   lwhite, fg, normal)
from time import sleep
from out import out

from pdb import set_trace as xx
import debug
if 0 and len(sys.argv) > 1:
    debug.SetDebugger()

esc = "\x1b"
cr = "\r"

class Line(object):
    '''Abstract object that your line objects must derive from.  You
    are responsible for ensuring that the object does not print beyond
    the end of the screen (to avoid accidental screen scrolling).  You
    are also responsible for setting the current foreground and
    background colors to the default values.
    '''
    def __init__(self):
        '''You must make sure to call this constructor; use a line
        such as
            super(YourClass'sName, self).__init__()
        '''
        ti = w.gettextinfo()
        self.W, self.H = ti[8], ti[7]   # Width and height of display
    def display(self, y, style=None):
        '''Put this object's text on line y; you can color the text as
        desired.  Numbering is zero-based.  You'll want to ensure that
        the number of characters you output is less than the width of
        the screen to avoid wrap-around and scrolling.

        You can just print the string to stdout or use WConio's
        cputs() function.

        Style None is the default style.  If you want to use the
        Choose() method of the Pager object, you must support style
        "hl", which is a highlighted line.
        '''
        raise RuntimeError("This is an abstract method")

class Pager(object):
    '''This pager allows you to display a sequence of Line objects.
    If you call Choose() to display the data, you can use the various
    keys to select a single item; when you press the Enter key, its
    index in the sequence will be returned.  If you instead call
    Show(), you see a paged presentation like the UNIX more or less
    commands.

    If you press the 'q' key (or its equivalents) while using
    Choose(), None is returned.

    Initialize with a dictionary that defines actions when keys are
    pressed.  These actions are denoted by strings and most are part
    of the WConio implementation.
    '''
    def __init__(self, keydict=None, status_color=(lwhite, green)):
        '''You can define key behaviors by supplying a key dictionary.
        status_color is the (foreground, background) colors of the
        status line (used to show line and page numbers).
        '''
        if keydict is None:
            self.keys = {
                "J" : "DOWN",       "D" : "DOWN",       "K" : "UP",
                "U" : "UP",         "d" : "down",       "j" : "down",
                "u" : "up",         "k" : "up",         " " : "pgdn",
                "v" : "pgdn",       "n" : "pgdn",       "V" : "pgup",
                "b" : "pgup",       "0" : "ctrlhome",   "G" : "ctrlend",
                "^" : "home",       "H" : "home",       "$" : "end",
                "L" : "end",        "z" : "center",     "M" : "center",
                "p" : "get_page",   esc : "quit",       "q" : "quit",
                "Q" : "quit",       cr : "enter",
            }
            for i in ["down", "up", "pgdn", "pgup", "ctrlhome", "ctrlend",
                      "home", "end"]:
                self.keys[i] = i
        else:
            self.keys = keydict
        ti = w.gettextinfo()
        self.W, self.H = ti[8], ti[7]   # Width and height of display
        self.status_color = status_color
    def SetLines(self, lines):
        '''Define the lines to display.  lines must be a sequence of
        Line objects.
        '''
        # Check the content of lines
        if not lines:
            raise ValueError("'lines' can't be an empty sequence")
        self.lines = lines
        for i, line in enumerate(lines):
            if not isinstance(line, Line):
                msg = "lines[%d] is not a Line object" % i
                raise ValueError(msg)
        # Divide up the lines into pages
        self.lpp = lpp = self.H - 1     # Lines per page
        self.page = 0
        page_num, self.pages, self.n = 0, [], len(lines)
        while True:
            n, m = lpp*page_num, lpp*(page_num + 1)
            self.pages.append(lines[n:m])
            page_num += 1
            if m >= len(lines):
                break
        self._y = 0         # Current line position
        self.fresh = True   # Just loaded new lines
    def DisplayLine(self, linenum, highlight=False):
        '''Display the indicated line; note linenum indexes into the
        self.lines array of Line objects.  If highlight is True, then
        this line will be highlighted.  Set self.fresh to True if you
        want to force the whole page to be redrawn.
        '''
        linenum = max(0, min(linenum, self.n - 1))
        page, index = divmod(linenum, self.lpp)
        if page != self.page or self.fresh:
            # Build the page from scratch
            w.clrscr()
            self.fresh = False
            for y, line in enumerate(self.pages[page]):
                if index == y and highlight:
                    line.display(y, style="hl")
                else:
                    line.display(y)
        else:
            index = max(0, min(index, len(self.pages[page]) - 1))
            line = self.pages[page][index]
            if highlight:
                line.display(index, style="hl")
            else:
                line.display(index)
        self.page = page
    def EraseStatusLine(self):
        w.gotoxy(0, self.H - 1)
        normal()
        w.clreol()
    def DisplayStatus(self):
        '''Update the status line at the bottom of the screen.
        '''
        self.EraseStatusLine()
        # Build up string to be centered
        if self.choose:
            n = self.n
            digits = (0 if n <= 100 else 1 if n <= 1000 else 2 if n <=
                      10000 else 3)
            s = " Line %d of %d   %.*f%%   Page %d of %d "
            pct = 100*(self.y/self.n)
            s = s % (self.y + 1,
                     self.n,
                     digits,
                     pct,
                     self.page + 1,
                     len(self.pages))
        else:
            s = "Page %d of %d" % (self.page + 1, len(self.pages))
        # Center on screen
        x = (self.W - len(s))//2
        w.gotoxy(x, self.H - 1)
        fg(self.status_color)
        w.cputs(s)
        normal()
    def GetPage(self):
        '''Prompt the user for a page number and return the line
        number corresponding to that page.  Note you can include a '%'
        character after the number and that will be converted to a
        line number instead.
        '''
        # Be able to restore the screen because the screen will scroll
        # when the user presses the Enter key.
        L, T, R, B, fg, bg, vmode, H, W, x, y = w.gettextinfo()
        buffer = w.gettext(L, T, R, B)
        restore = lambda x:  w.puttext(L, T, R, B, buffer)
        w.setcursortype(1)
        normal()
        # Get input
        while True:
            self.EraseStatusLine()
            # Get user's input
            s = raw_input("Page number? ").strip()
            if not s:
                restore(None)
                w.setcursortype(0)
                return self.y
            if s[-1] == "%":
                # Used typed in a percentage.  It will be clamped to
                # the 0% to 100% range.
                try:
                    pct = max(0, min(float(s[:-1])/100, 1))
                except Exception as e:
                    restore(None)
                    self.EraseStatusLine()
                    w.cputs("'%s' is not a valid percentage" % s)
                    sleep(2)
                else:
                    restore(None)
                    w.setcursortype(0)
                    return int(pct*(self.n - 1))
            else:
                try:
                    # User will count pages in 1-based arithmetic, but
                    # we need 0-based for indexing.
                    pg = int(s) - 1
                except ValueError:
                    restore(None)
                    self.EraseStatusLine()
                    w.cputs("'%s' is not an integer" % s)
                    sleep(2)
                else:
                    restore(None)
                    w.setcursortype(0)
                    pg = max(0, min(pg, len(self.pages) - 1))
                    # Get the line number on page pg that corresponds
                    # to the current line so that the highlighted item
                    # stays on the same place on the page.
                    n = self.y % self.lpp
                    return pg*self.lpp + n
    def Loop(self, highlight=False):
        '''The page has been displayed, so wait for a key to be
        pressed and take appropriate action.  If a selection is made,
        return the line object selected.
        '''
        w.setcursortype(0)  # Cursor off
        try:
            if highlight:
                self.DisplayLine(self.y, highlight=True)
            self.DisplayStatus()
            while True:
                old_y = self.y
                key = w.getkey()
                if key in self.keys:
                    # If highlight is on, turn off the highlighting of the
                    # last line highlighted.
                    if highlight:
                        self.DisplayLine(self.y, highlight=False)
                    resp = self.keys[key]
                    if resp == "DOWN" and self.choose:
                        self.y += 10
                    elif resp == "down" and self.choose:
                        self.y += 1
                    if resp == "UP" and self.choose:
                        self.y -= 10
                    elif resp == "up" and self.choose:
                        self.y -= 1
                    elif resp == "pgdn":
                        self.y += self.lpp
                    elif resp == "pgup":
                        self.y -= self.lpp
                    elif resp == "ctrlhome":
                        self.y = 0
                    elif resp == "ctrlend":
                        self.y = self.n - 1
                    elif resp == "home":
                        self.y = self.page*self.lpp
                    elif resp == "end":
                        self.y = (self.page + 1)*self.lpp - 1
                    elif resp == "center" and self.choose:
                        y = self.page*self.lpp
                        n = len(self.pages[self.page])//2
                        self.y = y + n
                    elif resp == "get_page":
                        self.y = self.GetPage()
                    elif resp == "enter":
                        w.setcursortype(1)  # Normal cursor
                        return self.lines[self.y]
                    elif resp == "quit":
                        w.setcursortype(1)  # Normal cursor
                        return None
                    self.DisplayLine(self.y, highlight=self.choose)
                    self.DisplayStatus()
        except Exception as e:
            # This code is here to help catch problems; if this wasn't
            # used, the typical behavior is that the script exits with
            # no indication of what went wrong, making it hard to
            # debug.
            w.clrscr()
            w.setcursortype(1)
            w.gotoxy(0, 0)
            out("Had exception:")
            out(" ", str(e))
            debug.DumpException()
            return -1
    def Show(self):
        '''Display the current page.  There is no highlighting.
        Returnthe selected Line object or None (-1 on a debugging
        error).
        '''
        p, lpp = self._y//self.lpp, self.lpp
        for linenum in range(p*lpp, (p + 1)*lpp):
            self.DisplayLine(linenum)
        w.setcursortype(0)  # Turn cursor off
        self.choose = False
        return self.Loop()
    def Choose(self):
        '''Display the current page and turn highlighting on.  Return
        the selected Line object or None (-1 on a debugging error).
        '''
        p, lpp = self._y//self.lpp, self.lpp
        for linenum in range(p*lpp, (p + 1)*lpp):
            self.DisplayLine(linenum)
        w.setcursortype(0)  # Turn cursor off
        self.choose = True
        return self.Loop(highlight=True)
    # y is the line to display as the current line
    def _set_y(self, y):
        self._y = max(0, min(int(y), self.n - 1))
    def _get_y(self):
        return self._y
    y = property(_get_y, _set_y)

if __name__ == "__main__":
    from atexit import register
    # Save screen info
    ti = w.gettextinfo()
    buffer = w.gettext(*ti[:4])
    def Restore():
        L, T, R, B, f, b, vmode, H, W, x, y = ti
        w.puttext(L, T, R, B, buffer)
        w.gotoxy(x, y)
        w.setcursortype(1)
        normal()
    if len(sys.argv) == 1:
        register(Restore)
    # You should see two pages of text.  Press the space bar to toggle
    # between them and 'q' to quit.  The first few letters of each
    # line will be randomly colored.
    from random import randint, choice
    class MyLine(Line):
        def __init__(self, s, normal=(white, black)):
            super(MyLine, self).__init__()
            self.s = s if s else " "
            self.normal = normal
        def display(self, y, style=None):
            '''y is the screen row to print on.
            '''
            # Check y coordinate
            if y < 0 or y > self.H - 1:
                raise ValueError("y must be between 0 and %d" % (self.H - 1))
            w.gotoxy(0, y)
            w.clreol()
            if 1:
                if style is "hl":
                    fg((lwhite, lblue))
                    w.cputs(self.s[:self.W])
                    fg(self.normal)
                else:
                    if 0:
                        # Randomly color the first few letters
                        c = (blue, green, cyan, red, magenta, brown, white,
                             gray, lblue, lgreen, lcyan, lred, lmagenta,
                             yellow, lwhite)
                        color = [choice(c), black]
                        t = self.s[:self.W]
                        fg(color)
                        m = 4
                        w.cputs(t[:m])
                        fg(self.normal)
                        w.cputs(t[m:])
                    else:
                        # No coloring, but use highlighting
                        w.cputs(self.s[:self.W])
            else:
                fg(self.normal)
                w.cputs(self.s[:self.W])
        def __repr__(self):
            return "Line(%s)" % hex(hash(self))
    W, H = ti[8], ti[7]   # Width and height of display
    s, lines = "This is the text of line number %d", []
    if 1:
        # Load PnP text (13000 lines)
        pnp = "d:/ebooks/JaneAusten/pnp.txt"
        L = [i.rstrip() for i in open(pnp).readlines()]
        # Note:  Multiplying L by 100 resulted in the script working
        # with a document of 1313400 lines and 19603 pages; it took 70
        # seconds to load.
        for s in L:
            lines.append(MyLine(s[:W]))
    else:
        if 1:
            # 8 full pages and 1 extra line
            n = int(8*(H - 1) + 1)
        else:
            # Make sure it works with only one line
            n = 1
        for i in range(n):
            lines.append(MyLine(s % (i + 1)))
    p = Pager()
    p.SetLines(lines)
    #try:
    if 1:
        if 1:
            chose = p.Choose()
            if 1 and chose != -1:
                w.clrscr()
                out("Chose '%s'" % lines[chose].s)
                w.getkey()
        else:
            p.Show()
    #except Exception as e:
    #    out("Exception", str(e))
