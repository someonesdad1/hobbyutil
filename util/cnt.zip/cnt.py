'''
Utility to count 8-bit characters in a stream or file(s); can also act
as a filter.  Run with the -h option to see a manpage.
'''

# Copyright (C) 2012 Don Peterson
# Contact:  gmail.com@someonesdad1

#
# Licensed under the Open Software License version 3.0.
# See http://opensource.org/licenses/OSL-3.0.
#

from __future__ import print_function, division
import sys
import os
import getopt
import string
from collections import defaultdict
from columnize import Columnize
from fpformat import FPFormat
from pdb import set_trace as xx

py3 = True if sys.version_info[0] > 2 else False

if py3:
    from io import StringIO
else:
    from StringIO import StringIO

ii = isinstance

# Used for formatting the percentage in the -l/-L format because it
# can align decimal points.
_fp = FPFormat(num_digits=3)

_ASC = ("nul", "soh", "stx", "etx", "eot", "enq", "ack", "bel",
        "bs", "ht", "nl", "vt", "np", "cr", "so", "si", "dle", "dc1",
        "dc2", "dc3", "dc4", "nak", "syn", "etb", "can", "em", "sub",
        "esc", "fs", "gs", "rs", "us", "sp")

_manpage = '''
Usage:  {name} [options] [file1 [file2 ...]]
  Construct a histogram of the counts of the 8-bit characters in one
  or more files (stdin if no files are given).  The count is given as
  an integer from 0 to 100 and is relative to the count of the
  most-frequent character.

  In the histogram, a '.' is printed where a character count is at
  least 1.  When it is divided by the count of the most-frequent
  character, it may round down to an integer or zero -- but the '.'
  tells you that there was at least one of those characters present.

  Note:  this script reads and interprets files as binary bytes.
  Thus, it knows nothing about Unicode or any particular character
  encoding; it just makes a histogram of the bytes' ASCII values.

Options:
    -2
        Print out the 2x2 byte correlation table.  To save space, the
        counts are scaled from 0 to 99.  Note:  you'll need an editor
        that can display a page over 1000 characters wide to view this
        (typically very sparse) table in its entirety.
    -7
        Only show the low 7-bit characters in the histogram.  You'll
        get a warning if there are non-zero counts of characters with
        the 8th bit set.
    -a s
        When using the -P option, this uses the string s as the title
        of the plot.
    -d
        Instead of showing the actual characters in the table, show
        their ASCII decimal value.
    -h
        Print out a usage statement.
    -L
        Produce a long listing, one character per line, with actual
        counts and percentage of total count.
    -l
        Same as -L, but only show characters with nonzero counts.
    -P
        Plot the histogram using matplotlib.  Use the -a option to
        supply a title for the plot.  This plot is a good way to get
        an easy-to-compare "fingerprint" of a file's byte frequencies.
        Some vertical lines are drawn with abbreviations to annotate
        where certain bytes are.
    -T
        Run self tests (not implemented yet).
    -w
        Remove whitespace from input.
    -x
        Instead of showing the actual characters in the table, show
        their ASCII hex value.

Examples
  * This script can display the differences bewteen plain text files
    and binary files.  Compare the output from an 'ls' listing to the
    contents of a compressed file (e.g., zip, bzip, or gzip).  For a
    more dramatic demonstration, use the -2 option.

  * Gather character frequency statistics from text.  For example, to
    compare the letter frequency characteristics between "Pride and
    Prejudice" to "Tom Sawyer", use e.g.

        python {name} -l pride_and_prejudice.txt >count.pp
        python {name} -l tom_sawyer.txt >count.ts
        diff count.pp count.ts

Notes

  * The chr and Cnt output lines may not line up properly, depending on
    the console encoding you're using (e.g., on my Linux console with
    UTF-8 encoding, the cr and esc lines have misalignments).
  * You may want to invoke this script with python's -u option to turn
    off buffering, which also ensures the standard streams are treated
    in a binary file fashion (e.g., no conversion of nl to cr-nl on
    systems where it matters).

'''.strip()

def ParseCommandLine(d):
    d["-2"] = False
    d["-7"] = False
    d["-a"] = ""
    d["-d"] = False
    d["-L"] = False
    d["-l"] = False
    d["-P"] = False
    d["-T"] = False
    d["-w"] = False
    d["-x"] = False
    try:
        optlist, args = getopt.getopt(sys.argv[1:], "27a:cdhLlPpTwx")
    except getopt.GetoptError as str:
        msg, option = str
        print(msg)
        sys.exit(1)
    for opt in optlist:
        if opt[0] == "-2":
            d["-2"] = not d["-2"]
        if opt[0] == "-7":
            d["-7"] = not d["-7"]
        if opt[0] == "-a":
            d["-a"] = opt[1].strip()
        if opt[0] == "-d":
            d["-d"] = not d["-d"]
        if opt[0] == "-h":
            Usage(d, 0)
        if opt[0] == "-L":
            d["-L"] = not d["-L"]
        if opt[0] == "-l":
            d["-l"] = not d["-l"]
        if opt[0] == "-P":
            d["-P"] = not d["-P"]
        if opt[0] == "-T":
            d["-T"] = not d["-T"]
        if opt[0] == "-w":
            d["-w"] = not d["-w"]
        if opt[0] == "-x":
            d["-x"] = not d["-x"]
    return args

def Error(msg):
    print(msg, file=sys.stderr)
    exit(1)

def Usage(d, status=1):
    name = os.path.split(sys.argv[0])[1]
    print(_manpage.format(**locals()))
    sys.exit(status)

def asc(n, center=False):
    '''n is in [0, 255]; return the character it represents.  If n <
    33, then return a mnemonic.
    '''
    if n > 32:
        if center:
            return " " + chr(n)
        else:
            return chr(n)
    else:
        return _ASC[n]

def FileSize(n):
    '''Convert the number of bytes n to an abbreviated form using k,
    M, G, or T.
    '''
    fmt = "%.2g"
    if n < 1e3:
        return str(n) + " Bytes"
    elif n < 1e6:
        return fmt % (n/10**3) + " kBytes"
    elif n < 1e9:
        return fmt % (n/10**6) + " MBytes"
    elif n < 1e12:
        return fmt % (n/10**9) + " GBytes"
    else:
        return fmt % (n/10**12) + " TBytes"

def CorrelationTable(bytes, d):
    '''Print a table showing how often one character follows another.
    We'll do this by counting each character and its predecessor and
    putting the results in a dictionary cnt.  The keys are 'i j' where
    i and j are the ord() of the characters and the values are the
    counts of that pair.

    The report will have the largest count scaled to 99; all other
    values will then be between 0 and 99.  Actual 0's don't print;
    those scaled numbers that are 0 but had actual counts will be
    replaced by '.'.
    '''
    sio = d["sio"]
    cnt = defaultdict(int)
    for i in range(1, len(bytes)):
        if ii(bytes[i], int):
            char = bytes[i]
            pred = bytes[i - 1]
        else:
            char = ord(bytes[i])
            pred = ord(bytes[i - 1])
        key = "%d %d" % (pred, char)
        cnt[key] += 1
    maxcnt = max(cnt.values())
    scale = 99.0/maxcnt
    # Print results.  Note we use hex for saving space.
    L, hdr, sep = range(256), " "*6, " | "
    print(hdr + sep, file=sio)
    for i in L:
        print("{0:02x}  ".format(i), file=sio)
    print(file=sio)
    print(hdr + sep, file=sio)
    for i in L:
        if i <= 32:
            c = _ASC[i]
        else:
            c = chr(i)
        print("{0:4}".format(c), file=sio)
    print(file=sio)
    print("-"*(1 + len(hdr)), file=sio)
    print("+", file=sio)
    print(("-"*4)*256, file=sio)
    for row in L:
        print("{0:02x} ".format(row), file=sio)
        if row <= 32:
            c = _ASC[row]
        else:
            c = chr(row)
        print("{0:4}| ".format(c), file=sio)
        for col in L:
            key = "%d %d" % (row, col)
            scaled = int(scale*cnt[key])
            if not scaled:
                if cnt[key]:
                    c = "."
                else:
                    c = ""
            else:
                c = str(scaled)
            print("{0:^4}".format(c), file=sio)
        print(file=sio)

def MakeHistogram(bytes, d, noprint=False):
    cnt = [0]*256
    # Print the counts.  Note we don't print 0.
    n, sio = d["size"], d["sio"]
    print("File(s) =", d["files"], file=sio)
    print("File size =", n, "=", hex(n), "=", FileSize(n), file=sio)
    if d["-w"]:
        # Remove whitespace
        for c in string.whitespace:
            bytes = bytes.replace(c, "")
        n = len(bytes)
        print("File size (no whitespace) =", n, "=", hex(n), "=",
              FileSize(n), file=sio)
    # Make the count
    for i in bytes:
        if ii(i, int):
            cnt[i] += 1
        else:
            cnt[ord(i)] += 1
    if noprint:
        d["cnt"] = cnt
        return
    maxcnt, L, n = max(cnt), range(len(cnt)), len(bytes)
    if d["-l"] or d["-L"]:
        # Show one character per line & actual counts
        print(file=sio)
        print("ASCII  Hex  Char   Count      Percent", file=sio)
        fmt = " %3d    %02x  %-3s %8s     %8s"
        for i in L:
            if cnt[i]:
                p = 100*float(cnt[i])/n
                pct = _fp.dp(p, width=10, dpoint=4)
                if pct.lstrip()[:2] == "0.":
                    # Remove the leading 0 if that's all there is before
                    # the decimal point.
                    pct = pct.replace("0.", " .")
                print(fmt % (i, i, asc(i), str(cnt[i]), pct), file=sio)
            else:
                if not d["-l"]:
                    print(fmt % (i, i, asc(i), "", ""), file=sio)
    else:
        # Show summary histogram
        output, fmt = [], "%-3s %3s"
        print("Maximum count =", maxcnt, "=", hex(maxcnt), "=",
              FileSize(maxcnt), file=sio)
        print(file=sio)
        factor = 4 if "-7" in d and d["-7"] else 8
        N = 128 if "-7" in d and d["-7"] else 256
        if "-d" in d and d["-d"]:
            print("Dec Cnt  "*factor, file=sio)
        elif "-x" in d and d["-x"]:
            print("Hex Cnt  "*factor, file=sio)
        else:
            print("chr Cnt  "*factor, file=sio)
        for i in range(N):
            p, nz = int(100*cnt[i]/maxcnt), cnt[i] > 0
            if "-d" in d and d["-d"]:     # Show decimal index
                c = str(i)
            elif "-x" in d and d["-x"]:   # Hex for ASCII index
                c = "%02x" % i
            else:           # Show character
                c = asc(i)
                if i == 127:
                    c = " "  # Problem with character 0x7f
            if p >= 1:
                # Put in the count
                output.append(fmt % (c, str(p)))
            elif nz:
                # Put in '.' because the count was at least 1
                output.append(fmt % (c, "."))
            else:
                # Empty because count was zero
                output.append(fmt % (c, ""))
        if "-7" in d and d["-7"]:
            print(Columnize(output, columns=4, width=79, col_width=8,
                  to_string=True), file=sio)
            if sum(cnt[128:]):
                print("Warning:  there are 8-bit counts not shown",
                      file=sio)
        else:
            print(Columnize(output, width=79, col_width=8, to_string=True),
                  file=sio)
    if "-2" in d and d["-2"]:
        print(file=sio)

# Make a set of 256 characters
_CHARS = []
for i in range(256):
    _CHARS.append(chr(i))
_CHARS = set(_CHARS)
del i

def GetChars(char_set):
    '''Return a set of the characters in the indicated set.
    '''
    s = []
    if char_set == "7":     # ASCII values between 32 and 127
        for i in range(32, 128):
            s.append(chr(i))
        s = set(s)
    elif char_set == "a":   # Letters
        s = set(string.letters)
    elif char_set == "C":   # Control characters
        for i in range(32):
            s.append(chr(i))
        s = set(s)
    elif char_set == "c":   # Carriage return
        s = set("\r")
    elif char_set == "d":   # Digits
        s = set(string.digits)
    elif char_set == "h":   # Hex digits
        s = set(string.hexdigits)
    elif char_set == "l":   # Lowercase letters
        s = set(string.lowercase)
    elif char_set == "L":   # Lowercase letters
        s = set(string.lowercase)
    elif char_set == "n":   # Newline
        s = set("\n")
    elif char_set == "o":   # Octal digits
        s = set(string.octdigits)
    elif char_set == "p":   # Printable characters
        s = set(string.printable)
    elif char_set == "P":   # Punctuation
        s = set(string.punctuation)
    elif char_set == "u":   # Uppercase letters
        s = set(string.uppercase)
    elif char_set == "U":   # Uppercase letters
        s = set(string.uppercase)
    elif char_set == "w":   # Whitespace
        s = set(string.whitespace)
    return s

def keep(bytes, char_set, nl=False):
    '''Keep only the characters indicated by char_set and return the
    filtered string.  If nl is True, make sure any newlines are kept.
    '''
    chars = GetChars(char_set)
    if nl:
        chars.add("\n")
    return string.translate(bytes, None, ''.join(_CHARS - chars))

def remove(bytes, char_set, nl=False):
    '''Remove the characters indicated by char_set and return the
    filtered string.  If nl is true, then newlines are not removed.
    '''
    chars = GetChars(char_set)
    if nl and "\n" in chars:
        chars.remove("\n")
    return string.translate(bytes, None, ''.join(chars))

def GetBytes(args, d):
    bytes = []
    d["sio"] = StringIO()
    if args:
        d["files"] = ', '.join(args)
        for file in args:
            #bytes.append(open(file, "rb").read())
            #bytes.append(open(file, "rb").read())
            bytes += open(file, "rb").read()
    else:
        d["files"] = "stdin"
        bytes = sys.stdin.read()
    return bytes

def MakeOutput(bytes, d):
    d["size"] = len(bytes)
    MakeHistogram(bytes, d)
    if d["-2"]:
        CorrelationTable(bytes, d)

def SelfTests(d):
    raise Exception("Self-tests not implemented yet")

def Plot(bytes, d):
    '''Plot the histogram using matplotlib.
    '''
    MakeHistogram(bytes, d, noprint=True)
    try:
        import matplotlib.pyplot as p
    except ImportError:
        Error("You need to have matplotlib installed to use -P")
    maxcnt = float(max(d["cnt"]))
    c = [i/maxcnt for i in d["cnt"]]
    p.plot(range(256), c, ".-")
    a = 5
    p.xlim(-a, 255 + a)
    a = 0.025
    p.ylim(-a, 1 + a)
    p.grid()
    if d["-a"]:
        p.title(d["-a"])
    # Find the character with the maximum count
    maxcnt = max(d["cnt"])
    index = d["cnt"].index(maxcnt)
    p.xlabel("ASCII byte value (max count is at x = %d = '%c')" %
             (index, chr(index)))
    p.ylabel("Maximum count = %d" % max(d["cnt"]))
    # Put some vertical lines and labels to make it easier to
    # interpret the graph
    c = "r"
    p.axvline(x=31.5, color=c)      # < ctrl
    p.axvline(x=64.5, color=c)      # < punc
    p.axvline(x=90.5, color=c)      # < uc
    p.axvline(x=96.5, color=c)      # < punc
    p.axvline(x=122.5, color=c)     # < lc
    p.axvline(x=127, color=c)       # < remaining 7 bit
    y, sz = 0.7, 16
    p.text(7, y, "ctrl", size=sz)
    p.text(37, y, "punc", size=sz)
    p.text(72, y, "uc", size=sz)
    p.text(107, y, "lc", size=sz)
    p.show()
    exit()

if __name__ == "__main__":
    d = {}  # Options dictionary
    args = ParseCommandLine(d)
    if d["-T"]:
        SelfTests(d)
    bytes = GetBytes(args, d)
    MakeOutput(bytes, d)
    if d["-P"]:
        Plot(bytes, d)
    else:
        print(d["sio"].getvalue())
