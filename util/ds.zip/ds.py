'''
Open a data sheet file if it's the only match to the regexp on the
command line.  Otherwise print out the matches.

Example:

    ds 3456

  will prompt you for manuals/datasheets/catalogs that contain the
  string 3456.
'''

# Copyright (C) 2014 Don Peterson
# Contact:  gmail.com@someonesdad1

#
# Licensed under the Open Software License version 3.0.
# See http://opensource.org/licenses/OSL-3.0.
#
import sys
import os
import getopt
import re
import glob
import subprocess
from os.path import join, isfile, split

# Try to import the color module
_have_color = False
try:
    import color as c
    _have_color = True
except ImportError:
    # Dummy object that will swallow calls to the color module
    class _C:
        def __setattr__(self, attr, x):
            pass
        def __getattr__(self, attr):
            return None
        def fg(self, *p):
            pass
        def normal(self):
            pass
    c = _C()
    del _C

py3 = True if sys.version_info[0] > 2 else False
if py3:
    raw_input = input

unix = 0

# app to open a file with registered application
if unix:
    app = "/usr/bin/exo-open"       # Linux
else:
    # Windows
    #app = "<dir>/app.exe"
    app = "c:/cygwin/bin/cygstart.exe" 

# Colors for output; colors available are:
#   black   gray
#   blue    lblue
#   green   lgreen
#   cyan    lcyan
#   red     lred
#   magenta lmagenta
#   brown   yellow
#   white   lwhite

(black, blue, green, cyan, red, magenta, brown, white, gray, lblue,
 lgreen, lcyan, lred, lmagenta, yellow, lwhite) = (
    c.black, c.blue, c.green, c.cyan, c.red, c.magenta, c.brown,
    c.white, c.gray, c.lblue, c.lgreen, c.lcyan, c.lred, c.lmagenta,
    c.yellow, c.lwhite)

c_norm = (white, black)  # Color when finished
c_plain = (white, black)

# The following variable can be used to choose different color styles
colorstyle = 0
if colorstyle == 0:
    c_dir = (lred, black)
    c_match = (yellow, black)
elif colorstyle == 1:
    c_dir = (lred, black)
    c_match = (white, blue)
elif colorstyle == 2:
    c_dir = (lgreen, black)
    c_match = (black, green)
elif colorstyle == 3:
    c_dir = (lmagenta, black)
    c_match = (yellow, black)
elif colorstyle == 4:
    c_dir = (lgreen, black)
    c_match = (lwhite, magenta)
elif colorstyle == 5:
    c_dir = (lred, black)
    c_match = (black, yellow)

def Usage(d, status=1):
    name = sys.argv[0]
    s = '''
Usage:  {name} [options] regexp
  Open a data sheet, manual, etc. file if it's the only match to the
  regexp.  Otherwise print out the matches and choose which one to
  display.

Options
    -i
        Make the search case sensitive.
'''[1:-1]
    print(s.format(**locals()))
    sys.exit(status)

def ParseCommandLine(d):
    d["-i"] = False     # If True, then case-sensitive search
    if len(sys.argv) < 2:
        Usage(d)
    try:
        optlist, args = getopt.getopt(sys.argv[1:], "il")
    except getopt.GetoptError as e:
        msg, option = e
        print(msg)
        exit(1)
    for opt in optlist:
        if opt[0] == "-i":
            d["-i"] = True
        elif opt[0] == "-l":
            d["-l"] = True
    if len(args) != 1:
        Usage(d)
    return args

def PrintMatch(num, s, start, end, d):
    '''For the match in s, print things out in the appropriate colors.
    Note start and end are the indices into just the file part of the
    whole path name.
    '''
    c.fg(c_plain)
    print("%3d  " % num, end="")
    dir, file = split(s[len(d["root"]) + 1:])  # Gets rid of leading stuff
    dir += "/"
    print(dir, end="")
    print(file[:start], end="")
    c.fg(c_match)
    print(file[start:end], end="")
    c.fg(c_plain)
    print(file[end:])

def Normalize(dir):
    return dir.replace("\\", "/")

def J(D, other):
    return Normalize(join(D, other))

def GetFiles(d):
    '''Get a list of files to display.
    '''
    files = []
    for dir in d["dir"]:
        f = [Normalize(i) for i in glob.glob(dir + "/*")]
        for file in f:
            if isfile(file):
                files.append(file)
    return files

if __name__ == "__main__":
    d = {}  # Options dictionary
    if unix:
        d["root"] = D = "/manuals"
    else:
        d["root"] = D = "d:/d/manuals"
    # Directories to check
    d["dir"] = (
        J(D, "datasheets"),
        J(D, "datasheets/batteries"),
        J(D, "datasheets/obsolete"),
        J(D, "datasheets/starrett"),
        J(D, "app_notes"),
        J(D, "app_notes/Tektronix"),
        J(D, "catalogs"),
        J(D, "catalogs/Jergens"),
        J(D, "catalogs/hp"),
        J(D, "catalogs/old"),
        J(D, "manuals"),
        #J(D, "manuals/Dixon_ZTR3362"),
        #J(D, "manuals/Dixon_ZTR3362/dixon"),
        J(D, "manuals/Hustler_mower"),
        J(D, "manuals/RadioShack"),
        J(D, "manuals/agilent"),
        J(D, "manuals/bk"),
        J(D, "manuals/bk/dc_load"),
        J(D, "manuals/bk/dmm"),
        J(D, "manuals/bk/function_generators"),
        J(D, "manuals/bk/misc"),
        J(D, "manuals/bk/power_supplies"),
        J(D, "manuals/bk/scopes"),
        J(D, "manuals/calculators"),
        J(D, "manuals/cameras"),
        J(D, "manuals/computers"),
        J(D, "manuals/fluke"),
        J(D, "manuals/gr"),
        J(D, "manuals/hp"),
        J(D, "manuals/hp/pictures"),
        J(D, "manuals/misc"),
        J(D, "manuals/tek"),
        J(D, "msds"),
    )
    regexp = ParseCommandLine(d)[0]
    r = re.compile(regexp) if d["-i"] else re.compile(regexp, re.I)
    # Get list of data files
    files = GetFiles(d)
    matches = []
    for i in files:
        # Only search for match in file name
        dir, file = split(i)
        mo = r.search(file)
        if mo:
            matches.append((i, mo))
    # Each match item will be (full_filename, match_object) where
    # match_object is the mo for _only_ the actual file name (not the
    # path).
    if len(matches) > 1 or (matches and d["-l"]):
        print("Choose which file to open:")
        for num, data in enumerate(matches):
            file, mo = data
            PrintMatch(num + 1, file, mo.start(), mo.end(), d)
        # Get which one to open
        while True:
            answer = raw_input("? ").strip()
            if not answer or answer == "q":
                exit(0)
            try:
                choice = int(answer) - 1
                if 0 <= choice < len(matches):
                    break
                else:
                    print("Answer must be between 1 and %d" % len(matches))
            except Exception:
                print("Improper number -- try again")
        # Send stderr to /dev/null because some apps on Linux have annoying
        # bug messages sent to the console.
        if py3:
            subprocess.Popen([app, matches[choice][0]],
                             stderr=subprocess.DEVNULL)
        else:
            subprocess.Popen([app, matches[choice][0]], stderr=None)
    elif len(matches) == 1:
        # Open this file.  Send stderr to /dev/null because some apps on
        # Linux have annoying bug messages sent to the console.
        if py3:
            subprocess.Popen([app, matches[0][0]], stderr=subprocess.DEVNULL)
        else:
            subprocess.Popen([app, matches[0][0]], stderr=None)
    else:
        print("No matches")
