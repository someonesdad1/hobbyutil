'''
Return the path on the command line as an absolute path.
'''

from __future__ import print_function
import os
import sys
from pdb import set_trace as xx

# Copyright (C) 2014 Don Peterson
# Contact:  gmail.com@someonesdad1

#
# Licensed under the Open Software License version 3.0.
# See http://opensource.org/licenses/OSL-3.0.
#
if len(sys.argv) == 1:
    print("Need a path argument", file=sys.stderr)
    exit(1)
s = os.path.abspath(sys.argv[1]).replace("\\", "/")
print(s)
