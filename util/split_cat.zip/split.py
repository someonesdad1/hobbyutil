'''
Split a file into pieces and print the SHA1 hash of the pieces
to stdout.
'''
 
# Copyright (C) 2008 Don Peterson
# Contact:  gmail.com@someonesdad1
 
#
# Licensed under the Open Software License version 3.0.
# See http://opensource.org/licenses/OSL-3.0.
#
 
from __future__ import print_function, division
import sys
import os
import hashlib

def Error(msg):
    print(msg, file=sys.stderr)
    exit(1)

def Usage():
    name = sys.argv[0]
    print('''Usage:  {name}  size_in_MB  prefix  file_to_split
  Splits a file into pieces of size_in_MB.  The files are named prefix0000,
  prefix0001, etc.  The SHA1 hashes of the pieces are printed to stdout.
  These hashes can be used with the cat.py script when reconstructing the
  input file -- they will validate that the file pieces haven't changed.
'''[:-1].format(**locals()))
    exit(1)

def Process(buffer, prefix, number):
    file = prefix + ("%04d" % number)
    # Check to see if file exists; if so, stop.
    if os.path.exists(file):
        Error("File '%s' exists -- won't overwrite." % file)
        exit(1)
    output_stream = open(file, "wb")
    output_stream.write(buffer)
    output_stream.close()
    print(hashlib.sha1(buffer).hexdigest() + " " + file)

def main():
    if len(sys.argv) != 4:
        Usage()
    try:
        chunk_size_in_bytes = int(float(sys.argv[1])*1e6)
    except:
        Error("size_in_MB improper")
        sys.exit(1)
    prefix, input_file = sys.argv[2:]
    file_size_in_bytes = int(os.stat(input_file)[6])
    num_files_to_write = file_size_in_bytes//chunk_size_in_bytes
    if num_files_to_write < 2:
        Error("File doesn't need splitting")
        sys.exit(1)
    input_stream = open(input_file, "rb")
    print("SHA1 hashes for each file:")
    for i in range(num_files_to_write):
        buffer = input_stream.read(chunk_size_in_bytes)
        Process(buffer, prefix, i)
    # Process any remaining bytes
    buffer = input_stream.read()
    Process(buffer, prefix, num_files_to_write)

main()
