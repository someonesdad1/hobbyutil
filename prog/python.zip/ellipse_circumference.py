'''
Plot how well Ramanujan's approximate formulas predicts the circumference of
an ellipse.

See
http://mathforum.org/dr/math/faq/formulas/faq.ellipse.circumference.html
'''

from __future__ import division
from pylab import *
from scipy.special import ellipe  # Complete elliptical integral of 2nd kind
from scipy.integrate import romberg  # Romberg numerical integration

a, delta = 1, 0.01
eccentricity = lambda a, b: sqrt((a**2 - b**2)/a)

def Integrand(x, a, b):
    e = eccentricity(a, b)
    return sqrt(1 - e**2*sin(x)**2)

def Ramanujan1(a, b):
    x = (a-b)/(a+b)
    return pi*(a+b)*(1 + 3*x**2/(10 + sqrt(4 - 3*x**2)))

def Ramanujan2(a, b):
    return pi*(3*(a+b) -sqrt(10*a*b+3*(a**2+b**2)))

def Romberg():
    '''Demonstrates the use of the SciPy Romberg integration routine to
    calculate an exact value of the ellipse's circumference.  Note we do
    it for each point, rather than the usual "all at once" using numpy.
    '''
    y = []
    for b in arange(0, 1 + delta, delta):
        val = 4*romberg(Integrand, 0, pi/2, (1, b)) 
        y.append(val)
    return array(y)

b = arange(0, 1 + delta, delta)
e = eccentricity(a, b)

exact = 4*a*ellipe(e**2)
p, factor = plot, 1
p(b, factor*Romberg()/exact, label="Romberg integration")
p(b, factor*Ramanujan1(a, b)/exact, label="Ramanujan1")
p(b, factor*Ramanujan2(a, b)/exact, label="Ramanujan2")

x, y, dy, fs = 0.2, 0.999, 6e-4, 16
text(x, y, r"$x = \frac{a-b}{a+b}$", fontsize=fs)
text(x, y - dy, r"$Ramanujan1 = \pi (a+b)(1 + \frac{3x^2}{10 + \sqrt{4-3x^2}})$", fontsize=fs)
text(x, y - 2*dy, r"$Ramanujan2 = \pi (3(a+b) - \sqrt{10ab + 3(a^2+b^2)}$", fontsize=fs)
text(x, y - 3*dy, r"$\mathrm{Note\/in\/the\/plots\/that\/} a = 1$", fontsize=fs)

legend(loc="lower right")
xlabel("b")
ylabel("Fraction of exact value")
title("Approximations to the circumference of an ellipse")
grid(True)

if 1:
    show()
else:
    savefig("ellipse_circumference.png", dpi=100)
