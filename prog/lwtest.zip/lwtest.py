'''
Lightweight testrunner framework
 
Typical usage:
    from lwtest import run, raises, assert_equal
 
    def TestExample():
        f = lambda x: set(x)
        # Two ways to check for expected exceptions
        raises(TypeError, f, 1)
        with raises(ZeroDivisionError):
            1/0
        # How to compare floating point numbers
        eps = 1e-6
        a, b = 1, 1 + eps
        assert_equal(a, b, abstol=eps)
 
    if __name__ == "__main__":
        failed, messages = run(globals())
 
run() will find test functions and execute them; its single parameter
must be a dictionary containing the names and their associated
function objects.  Call run(dryrun=True) to see which functions will
be executed and their execution order.

Use the ToDoMessage() function to cause a colored message to be printed to
stdout to remind you of something that needs to be done.
 
Tested under python 2.7.6 and 3.4.0.
'''
# Copyright (C) 2014 Don Peterson
# Contact:  gmail.com@someonesdad1
 
#
# Licensed under the Open Software License version 3.0.
# See http://opensource.org/licenses/OSL-3.0.
#
 
# Derived from some code by Raymond Hettinger 8 May 2008:
# http://code.activestate.com/recipes/572194/.  Downloaded 27 Jul 2014.
# The ActiveState web page appears to state Hettinger's code was
# released under the PSF (Python Software Foundation) License.
# Hettinger's code includes a search for test functions that are
# generators; if such functionality is important to you, you might want
# to add it to this file.
 
from __future__ import print_function, division
import os
from math import isnan, isinf, copysign
from decimal import Decimal
import re
import sys
from time import time
import traceback
from collections import Iterable
from pdb import set_trace as xx

# Try to import the color.py module; if not available, the script
# should still work (you'll just get uncolored output).
try:
    import color
    _have_color = True
except ImportError:
    # Make a dummy color object to swallow function calls
    class Dummy:
        def fg(self, *p, **kw): pass
        def normal(self, *p, **kw): pass
        def __getattr__(self, name): pass
    color = Dummy()
    _have_color = False

'''
Possible enhancements:
 
    * Add a seq keyword to assert_equal to let any two sequences be
      compared pairwise.  Basic functionality similar to
      unittest.assertSequenceEqual.
    * Analogously, add a Dict keyword that allows comparisons of both
      keys and values of two dictionaries.
    * If an argument passed on the command line is a directory, search
      it recursively for all files that appear to be test scripts and
      run them.
    * Add a verbose keyword to run() which prints the file name and the
      function/class to be executed, like 'nosetests -v' does.  Another
      thing to consider would be to let run look at sys.argv and process
      options there in lieu of keywords (this would be handy for command
      line work, as the command line options would overrule the
      keywords).
 
'''
'''
Note:  the motivation for generating this lightweight testrunner framework
was my frustration with the unittest module in conjunction with the way I
develop code.  I write my unit tests before or during code development and
often need to drop into the debugger or add a print statement to see what's
going wrong.  The unittest module traps stdout and makes this more painful
to do.  I liked some of the available testrunners like nose or pytest, but
I decided that if I was going to add a new dependency, it might as well be
a dependency I could tune to my own preferences.  The other major desire
was to allow fairly comprehensive coverage of comparing numerical results.
'''

__all__ = [
    "run",
    "assert_equal",
    "raises",
    "default_regexp",
    "ToDoMessage",
]

py3 = True if sys.version_info[0] == 3 else False
if py3:
    String = (str,)
    Int = (int,)
    long = int
else:
    String = (str, unicode)
    Int = (int, long)

python_version = '.'.join([str(i) for i in sys.version_info[:3]])

# This is the regular expression used to identify test functions
default_regexp = "^_*test|test$"

# Optional imports of numpy and mpmath
try:
    import numpy
    have_numpy = True
except ImportError:
    have_numpy = False
try:
    import mpmath
    have_mpmath = True
except ImportError:
    have_mpmath = False

def run(names_dict, **kw):
    '''Discover and run the test functions in the names_dict
    dictionary (name : function pairs).  Return (failed, s) where
    failed is a Boolean that is True if one or more failures occurred
    and s is the information string that was sent (or would have been
    sent) to the stream.  A failure is an unhandled exception.
 
    Keyword options [default]:
        broken:     If True, testing code is acknowledged to be broken;
                    a warning message is printed and tests are not run.
                    [False]
        dbg:        If True, don't handle exceptions (allows you to trap
                    them in a debugger).  Also can set the environment
                    variable 'dbg' to do this. [False]
        dryrun:     Just print the functions to be executed. [False]
        halt:       Stop at the first failure.  [False]
        quiet:      If True, no output.  [False]
        regexp:     Regular expression that identifies a test function.
                    Default is in global variable default_regexp.
        reopts:     Regular expression's options. [re.I]
        stream:     Where to send output [stdout].  None = no output.
    '''
    # Keyword arguments
    broken = bool(kw.get("broken", False))
    dbg = bool(kw.get("dbg", False)) or "dbg" in os.environ
    dryrun = bool(kw.get("dryrun", False))
    halt = bool(kw.get("halt", False))
    quiet = kw.get("quiet", False)
    reopts = kw.get("reopts", re.I)
    regexp = kw.get("regexp", default_regexp)
    stream = kw.get("stream", sys.stdout)
    # If broken, print error message and return
    if broken:
        # Get the name of the file that called us
        file = traceback.extract_stack()[0][0]
        color.fg(color.lred)
        print("{}:  Error:  tests are broken".format(file))
        color.normal()
        return (1, "Tests are broken")
    # Find test functions in names_dict to run
    istest = re.compile(regexp, reopts)
    tests = [(name, func) for name, func in names_dict.items()
             if istest.search(name)]
    # Reverse the list so they can be popped in alphabetical order
    tests = sorted(tests, reverse=True)
    try:
        filename = names_dict["__file__"]
    except KeyError:
        # Use the current file's name; put angle brackets around it to
        # indicate it might not be the correct file (e.g., the user
        # manually invoked run() with a hand-crafted dictionary and
        # forgot to add a "__file__" key).
        filename = "<%s ?>" % __file__
    pass_count = fail_count = 0
    fail_messages = []
    if dryrun:
        fail_messages = ["Test functions in %s:" % filename]
    nl = "\n"
    start_time = time()
    # Run the test functions
    while tests:
        name, func = tests.pop()
        try:
            if dryrun:
                fail_messages.append("  %s" % name)
                fail_count += 1
            else:
                func()
        except TypeError as e:
            # Probably trying to run the module.
            if str(e) == '''TypeError("'module' object is not callable",)''':
                print("xx lwtest.py:  need to test TypeError catch")
            else:
                raise
        except Exception as e:
            if dbg:
                raise
            fail_count += 1
            lines = ["%s failed:  %s" % (name, repr(e))]
            # Append an indented stack trace
            for line in traceback.format_exc().split(nl):
                lines.append("  " + line)
            fail_messages += lines
            if halt:
                break
        else:
            pass_count += 1
    stop_time = time()
    output = (nl.join(fail_messages) if fail_messages else
              "{}:  {} {} passed in {} [python {}]".
              format(filename, 
                     pass_count, 
                     "test" if pass_count == 1 else "tests", 
                     GetTime(stop_time - start_time), 
                     python_version))
    if stream and not quiet:
        stream.write(output + nl)
    return (fail_count > 0, output)

def GetTime(duration_s):
    if duration_s > 3600:
        return "%.3f hr" % (duration_s/3600)
    elif duration_s > 60:
        return "%.2f min" % (duration_s/60)
    else:
        return "%.2f s" % (duration_s)

def raises(ExpectedExceptions, *args, **kw):
    '''Asserts that a function call raises one of a sequence of expected
    exceptions.  ExpectedExceptions can either be a single exception
    type or a sequence of such types.  If args is empty, then a context
    manager instance is returned for use in a 'with' statement.  Examples:
        Function call:
            raises((Exception1, Exception2), func, 0, akw=True)
        Context manager:
            with raises(ZeroDivisionError):
                1/0
    '''
    if args:
        try:
            args[0](*args[1:], **kw)
        except ExpectedExceptions:
            return
        else:
            raise AssertionError("Did not raise expected exception")
    return RaisesContextManager(ExpectedExceptions)

class RaisesContextManager(object):
    def __init__(self, ExpectedExceptions):
        try:
            self.expected = set(ExpectedExceptions)
        except TypeError:
            self.expected = set([ExpectedExceptions])
    def __enter__(self):
        return None
    def __exit__(self, exception, exception_value, traceback):
        if exception in self.expected:
            return True
        raise AssertionError("Did not raise expected exception")

def check_float(a, b, reltol=None, abstol=None, use_min=False):
    # Some of these checks were patterned after the checks in
    # Lib/test/test_cmath.py in the python distribution (probably
    # version 2.6.5).
    if not isinstance(a, (Int, float)):
        raise ValueError("a needs to be a float")
    if not isinstance(b, float):
        # Convert b to float
        try:
            b = float(str(b))
        except Exception:
            raise ValueError("b must be convertible to a float")
    fail = None
    # Handle NaN and infinite values
    if ((isnan(a) and not isnan(b)) or (not isnan(a) and isnan(b))):
        fail = []
    if ((isinf(a) and not isinf(b)) or (not isinf(a) and isinf(b))):
        fail = []
    sign_a, sign_b = copysign(1., a), copysign(1., b)
    if isinf(a) and isinf(b):
        # a and b can be infinite, but they must have the same sign
        if sign_a != sign_b:
            fail = ["a and b are infinity with opposite signs"]
    elif not a and not b:  # Zeros must have the same sign
        if sign_a != sign_b:
            fail = ["a and b are zero with opposite signs"]
    else:
        try:
            # Check for overflow (mentioned as a rare corner case in
            # Lib/test/test_cmath.py).
            absdiff = abs(b - a)
        except OverflowError:
            fail = ["Arguments not equal (overflow occurred)"]
        else:
            abstol = 0 if abstol is None else abstol
            reltol = 0 if reltol is None else reltol
            minmax = min if use_min else max
            tolerance = minmax(abstol, reltol*abs(a))
            if not a and b:  # Relative to b if a is zero
                tolerance = minmax(abstol, reltol*abs(b))
            if absdiff > tolerance:
                fail = [
                    "Unacceptable numerical difference:",
                    "  abstol     = %s" % abstol,
                    "  reltol     = %s" % reltol,
                    "  tolerance  = %s" % tolerance,
                    "  difference = %s" % absdiff,
                    "  difference - tolerance = %s" % (absdiff - tolerance),
                ]
    return fail

def check_decimal(a, b, reltol=None, abstol=None, use_min=False):
    fail = None
    if not isinstance(a, Decimal):
        raise ValueError("a needs to be a Decimal")
    if not isinstance(b, Decimal):
        # Convert b to Decimal
        try:
            b = Decimal(str(b))
        except Exception:
            raise ValueError("b must be convertible to a Decimal")
    # Handle NaN and infinite values
    if ((a.is_nan() and not b.is_nan(b)) or (not a.is_nan() and b.is_nan())):
        fail = []
    if ((a.is_infinite() and not b.is_infinite()) or
            (not a.is_infinite() and b.is_infinite())):
        fail = []
    sign_a, sign_b = a.copy_sign(Decimal(1)), b.copy_sign(Decimal(1))
    if a.is_infinite() and b.is_infinite():
        # a and b can be infinite, but they must have the same sign
        if sign_a != sign_b:
            fail = ["a and b are infinity with opposite signs"]
    elif not a and not b:  # Zeros must have the same sign
        if sign_a != sign_b:
            fail = ["a and b are zero with opposite signs"]
    else:
        try:
            # Check for overflow
            absdiff = abs(b - a)
        except OverflowError:
            fail = ["Arguments not equal (overflow occurred)"]
        else:
            D, zero = Decimal, Decimal(0)
            abstol = zero if abstol is None else D(str(abstol))
            reltol = zero if reltol is None else D(str(reltol))
            minmax = min if use_min else max
            tolerance = minmax(abstol, reltol*abs(a))
            if not a and b:  # Relative to b if a is zero
                tolerance = minmax(abstol, reltol*abs(b))
            if absdiff > tolerance:
                fail = [
                    "Numerical difference",
                    "  abstol     = %s" % abstol,
                    "  reltol     = %s" % reltol,
                    "  tolerance  = %s" % tolerance,
                    "  difference = %s" % absdiff,
                    "  difference - tolerance = %s" % (absdiff - tolerance),
                ]
    return fail

def check_complex(a, b, reltol=None, abstol=None, use_min=False):
    if not isinstance(a, complex) or not isinstance(b, complex):
        raise ValueError("Both a and be need to be complex")
    # The real and imaginary parts must satisfy the requirements
    # separately.
    fail = check_float(a.real, b.real, reltol=reltol, abstol=abstol,
                       use_min=use_min)
    f = check_float(a.imag, b.imag, reltol=reltol, abstol=abstol,
                    use_min=use_min)
    if f is not None:
        if fail is not None:
            fail += f
        else:
            fail = f
    return fail

def check_equal(a, b, reltol=None, abstol=None, use_min=False):
    '''a and b are not sequences, so they can be compared directly.
    The comparison semantics are determined by reltol and abstol; if
    either is nonzero, then a and b are compared as floating point
    types; which type comparison is used is determined by the type
    of a.  Otherwise, a and b are compared directly.
    '''
    fail = None
    R, A, U = reltol, abstol, use_min
    if reltol is not None or abstol is not None:
        # Floating point comparisons
        if isinstance(a, (Int, float)):
            fail = check_float(a, b, reltol=R, abstol=A, use_min=U)
        elif isinstance(a, complex):
            fail = check_complex(a, b, reltol=R, abstol=A, use_min=U)
        elif isinstance(a, Decimal):
            fail = check_decimal(a, b, reltol=R, abstol=A, use_min=U)
        elif have_mpmath and isinstance(a, mpmath.mpf):
            fail = check_float(a, b, reltol=R, abstol=A, use_min=U)
        elif have_mpmath and isinstance(a, mpmath.mpc):
            fail = check_complex(a, b, reltol=R, abstol=A, use_min=U)
        else:
            raise RuntimeError("a is unrecognized type '%s'" % type(a))
    else:
        # Object comparison
        if isinstance(a, String):
            if a != b:
                fail = ["Unequal strings"]
        else:
            if a != b:
                fail = ["{} != {}".format(repr(a), repr(b))]
    return fail

def assert_equal(a, b, reltol=None, abstol=None, use_min=False, 
                 msg="", halt=True):
    '''Raise an AssertionError if a != b.  a and b can be objects,
    numbers, or sequences of numbers (sequence elements are compared
    pairwise).  reltol and abstol are the relative and absolute
    tolerances.  No exception will be raised if for each number
    element (if a is zero, reltol*b is used instead)
            abs(a - b) <= reltol*a
    or
            abs(a - b) <= abstol
    If both abstol and reltol are defined, the one with the larger
    tolerance range will be used unless use_min is True, in which case
    the smaller tolerance will be used.
 
    If msg is present, include it in the printout as a message.
 
    If halt is True, a failed assertion causes an exception to be
    raised; if halt is False, the error message is printed to stderr and
    the function returns (this allows you to e.g. start a debugger).
    '''
    # fail will be None if all things compared are equal.  Otherwise,
    # it will be a list of error message strings detailing where the
    # comparison(s) failed.
    fail = None
    if not isinstance(a, String) and isinstance(a, Iterable):
        if reltol is None and abstol is None:
            # Compare them as objects.  Note they could be numpy
            # arrays.
            if have_numpy and type(a) == numpy.ndarray:
                if any(a != b):
                    fail = []
            else:
                if a != b:
                    fail = []
        else:
            # Sequences:  compare each corresponding element.  Note
            # dictionaries are sequences too, but this may not give
            # you the comparison semantics you want because the
            # dictionaries' values are ignored.
            try:
                for i, j in zip(a, b):
                    f = check_equal(i, j, reltol=reltol, abstol=abstol,
                                    use_min=use_min)
                    if f is not None:
                        if fail is not None:
                            fail += f
                        else:
                            fail = f
            except Exception:
                m = "Could not pairwise compare a and b"
                raise AssertionError(m)
    else:
        fail = check_equal(a, b, reltol=reltol, abstol=abstol, use_min=use_min)
    if fail is None:
        return      # a and b were equal
    else:
        arg_not_eq = "Arguments are not equal [pyver {}]:".format(python_version)
        try:
            # Assume they're sequences
            diff = [a[i] - b[i] for i in range(len(a))]
        except Exception:
            try:
                # Assume they're numbers
                diff = a - b
            except Exception:
                # Should work for any other objects
                fail += [
                    arg_not_eq,
                    "  1st  = %s" % repr(a),
                    "  2nd  = %s" % repr(b),
                ]
            else:
                try:
                    rel_diff_arg1 = diff/a
                except Exception:
                    rel_diff_arg1 = None
                try:
                    rel_diff_arg2 = diff/b
                except Exception:
                    rel_diff_arg2 = None
                fail += [
                    arg_not_eq,
                    "  arg1 = %s" % repr(a),
                    "  arg2 = %s" % repr(b),
                    "  diff = %s" % repr(diff),
                ]
                if rel_diff_arg1 is not None:
                    fail += ["  diff/arg1 = %s" % repr(rel_diff_arg1)]
                if rel_diff_arg2 is not None:
                    fail += ["  diff/arg2 = %s" % repr(rel_diff_arg2)]
        else:
            fail += [
                arg_not_eq,
                "  arg1 = %s" % repr(a),
                "  arg2 = %s" % repr(b),
                "  diff = %s" % repr(diff),
            ]
    if msg:
        fail.append(msg)
    if halt:
        raise AssertionError("\n".join(fail))
    else:
        print(fail, file=sys.stderr)

def ToDoMessage(message, prefix="+"):
    '''This function results in a message to stdout; it's purpose is to
    allow you to see something that needs to be done, but won't cause
    the test to fail.  The message is decorated with a leading prefix
    string and the file and line number.
    '''
    fn, ln, method, call = traceback.extract_stack()[-2]
    vars = {"fn": fn, "ln": ln, "method": method, "msg": message,
        "prefix": prefix }
    def trace(msg, vars):
        print("{prefix}{fn}[{ln}] in {method}:  {msg}".format(**vars))
    try:
        # Print the message in red
        from color import fg, lred, normal
        fg(lred)
        trace(message, vars)
        normal()
    except ImportError:
        trace(message, vars)

if __name__ == "__main__":
    print('''
lwtest:  Lightweight test framework -- typical usage:
    from lwtest import run, assert_equal, raises
    if __name__ == "__main__":
        failed, messages = run(globals())
 
run()'s kw arguments (default value in square brackets):
    broken:  If True, testing is acknowledged to be broken and a warning
             message to this effect is printed.
    dryrun:  Only print the functions to be executed. [False]
    halt:    Stop at the first failure.  [False]
    regexp:  Regular expression that identifies a test function.
             ["{0}"]
    reopts:  Regular expression's options. [re.I]
    stream:  Where to send output [stdout].  None = no output.
 
Utility functions:
    Check that two numbers are close:
        assert_equal(a, b, reltol=None, abstol=None, use_min=False)
    Check that something raises an exception:
        raises(exception_object, func, *p, **kw)
        raises(sequence_of_exception_objects, func, *p, **kw)
        with raises(exception_object):
            <code that must raise an exception>
    Send a colored reminder message to stdout:
        ToDoMessage(message, prefix="+")
'''[1:-1].format(default_regexp))
