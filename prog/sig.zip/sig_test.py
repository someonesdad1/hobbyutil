# coding: utf-8
from __future__ import division, print_function
import sys
from sig import (sig, SigFig, Dec, GetSigFig, locale, Fraction, decimal,
    _Complex, D, atan2, _zero, _one, pi,
    _have_uncertainties, _have_mpmath, _have_numpy,
    )
import traceback as tb
from lwtest import run, assert_equal, raises
from pdb import set_trace as xx

if _have_numpy:
    from sig import np
if _have_uncertainties:
    from sig import unc
if _have_mpmath:
    from sig import mp

py3 = True if sys.version_info[0] > 2 else False
if py3:
    long = int
else:
    chr = unichr

ii = isinstance

def init():
    '''We set the SigFig class variables here so that the default
    settings the user chooses won't affect the tests.
    '''
    SigFig._digits          = 3
    SigFig._dp              = "."
    SigFig._edigits         = 1
    SigFig._esign           = True
    SigFig._fit             = 0
    SigFig._fractions       = True
    SigFig._high            = "1e5"
    SigFig._idp             = True
    SigFig._ignore_none     = False
    SigFig._lead_zero       = True
    SigFig._low             = "1e-3"
    SigFig._separator       = " "
    SigFig._sign            = False
    SigFig._zero_limit      = 0
    # Complex stuff
    SigFig._imag_before     = False
    SigFig._imag_deg        = True
    SigFig._imag_deg_sym    = "*"
    SigFig._imag_limit      = 0
    SigFig._imag_polar      = False
    SigFig._imag_polar_sep  = "/_"
    SigFig._imag_post       = ""
    SigFig._imag_pre        = ""
    SigFig._imag_sep        = ""
    SigFig._imag_full       = False
    SigFig._imag_pair       = False
    SigFig._imag_pair_sep   = "|"
    SigFig._imag_pair_left  = "<"
    SigFig._imag_pair_right = ">"
    # Uncertainties stuff
    SigFig._unc_short       = True
    SigFig._unc_digits      = 1
    SigFig._unc_sep         = "+/-"
    SigFig._unc_pre         = "("
    SigFig._unc_post        = ")"
    global sig
    sig = SigFig() # Uses our settings

def check(got, expected):
    if got != expected:
        # Print the line number that failed and continue
        st = tb.extract_stack()[-2]
        msg = '''Failure[{0}]:  {1}
  Got     : '{2}'
  Expected: '{3}\' '''.format(st[1], st[3], got, expected)
        if py3:
            assert 1 == 0, msg
        else:
            assert 1 == 0, msg.decode("utf-8")

def test_check_float():
    sig.reset()
    # We'll get a TypeError exception if it fails
    f, nm = sig._check_float, "'unit test'"
    if _have_mpmath:
        f(mp.mpf("0"), nm)
    f(1.23, nm)
    f(1, nm)
    f("1", nm)
    f(Dec("1"), nm)
    f(Fraction("1/2"), nm)
    raises(TypeError, f, [], nm)

def test_helper_functions():
    sig.reset()
    nm = "unit test"
    # Test _convert_number
    check(sig._convert_number(1, nm), 1)
    check(sig._convert_number("1", nm), 1)
    check(sig._convert_number(1.0, nm), 1)
    check(sig._convert_number(Dec(1), nm), 1)
    check(sig._convert_number(Fraction(1, 1), nm), 1)
    #----------------------------
    # Test _convert_fraction
    check(sig._convert_fraction(Fraction(1, 1)), 1)
    assert(isinstance(sig._convert_fraction(Fraction(1, 1)), Dec))
    raises(TypeError, sig._convert_fraction, 1)
    # Test _is_iterable
    check(sig._is_iterable(""), False)
    check(sig._is_iterable([]), True)
    check(sig._is_iterable((1,)), True)
    check(sig._is_iterable({}), True)
    check(sig._is_iterable(set()), True)
    check(sig._is_iterable(frozenset()), True)
    check(sig._is_iterable(1), False)
    check(sig._is_iterable(1.0), False)
    check(sig._is_iterable(Dec("1.0")), False)
    check(sig._is_iterable(Fraction("1.0")), False)
    if _have_numpy:
        a = np.array(range(4))
        check(sig._is_iterable(np.array(a)), True)
        a.shape = (2, 2)    # Square array
        check(sig._is_iterable(np.array(a)), True)
        a = np.matrix(a)    # Can iterate on matrix
        check(sig._is_iterable(np.array(a)), True)
    if _have_mpmath:
        # Check with mpmath matrices and vectors ('list' needed to
        # work with python 3, as range is an iterator there).
        v = mp.matrix(list(range(5)))
        check(sig._is_iterable(mp.matrix(list(range(5)))), True)
        check(sig._is_iterable(mp.matrix(3,2)), True)

def test_format_zero():
    sig.reset()
    # Can format 0 correctly
    check(sig(0, 8), "0.0000000")
    check(sig(0, 3), "0.00")
    check(sig(-0, 3), "0.00")
    sig.idp = True
    check(sig(0, 1), "0.")
    sig.idp = False
    check(sig(0, 1), "0")
    check(sig(0, 2), "0.0")
    sig.dp = ","
    check(sig(0, 2), "0,0")

def test_change_dp_string():
    sig.reset()
    # Can change string used for decimal point
    x = 123
    sig.dp = ","
    check(sig(0, 3), "0,00")
    sig.dp = "!@"
    check(sig(0, 3), "0!@00")
    sig.dp = ","
    check(sig(x, 2), "120,")
    check(sig(-x, 2), "-120,")
    sig.reset()

def test_format_positive_numbers():
    sig.reset()
    x = 123
    check(sig(x*10, 2), "1200.")
    check(sig(x, 2), "120.")
    check(sig(x/10, 2), "12.")
    check(sig(x/100, 2), "1.2")
    check(sig(x/1000, 2), "0.12")
    check(sig(x/10000, 2), "0.012")

def test_format_negative_numbers():
    sig.reset()
    x = 123
    check(sig(-x*10, 2), "-1200.")
    check(sig(-x, 2), "-120.")
    check(sig(-x/10, 2), "-12.")
    check(sig(-x/100, 2), "-1.2")
    check(sig(-x/1000, 2), "-0.12")
    check(sig(-x/10000, 2), "-0.012")

def test_underflow_overflow():
    sig.reset()
    x = 123
    # Underflows to scientific notation
    sig.low = 1e-1
    check(sig(-x/10000, 2), "-1.2e-2")
    check(sig(x/10000, 2), "1.2e-2")
    sig.reset()
    # Overflows to scientific notation
    sig.high = 10
    check(sig(x, 2), "1.2e+2")
    sig.reset()
    # Low and high can be adjusted as needed
    sig.low = 1e-12
    check(sig(x*1e-11, 2), "0.0000000012")
    sig.high = 1e12
    check(sig(x*1e9, 2), "120000000000.")

def test_num_digits_in_exponent():
    sig.reset()
    x = 123
    sig.high = 1e1
    sig.edigits = 1
    check(sig(x, 2), "1.2e+2")
    sig.edigits = 2
    check(sig(x, 2), "1.2e+02")
    sig.edigits = 5
    check(sig(x, 2), "1.2e+00002")
    sig.edigits = 1
    check(sig(-x, 2), "-1.2e+2")
    sig.edigits = 2
    check(sig(-x, 2), "-1.2e+02")
    sig.edigits = 5
    check(sig(-x, 2), "-1.2e+00002")
    sig.low = 1e-1
    sig.edigits = 1
    check(sig(x/10000, 2), "1.2e-2")
    sig.edigits = 2
    check(sig(x/10000, 2), "1.2e-02")
    sig.edigits = 5
    check(sig(x/10000, 2), "1.2e-00002")
    sig.edigits = 1
    check(sig(-x/10000, 2), "-1.2e-2")
    sig.edigits = 2
    check(sig(-x/10000, 2), "-1.2e-02")
    sig.edigits = 5
    check(sig(-x/10000, 2), "-1.2e-00002")
    sig.reset()

def test_idp_feature():
    sig.reset()
    x = 123
    sig.idp = True
    check(sig(0, 1), "0.")
    sig.idp = False
    check(sig(0, 1), "0")
    check(sig(0, 3), "0.00")
    sig.idp = True
    check(sig(0, 3), "0.00")
    check(sig(x, 2), "120.")
    sig.idp = False
    check(sig(x, 2), "120")
    sig.idp = True
    check(sig(-x, 2), "-120.")
    sig.idp = False
    check(sig(-x, 2), "-120")

def test_fit_feature():
    sig.reset()
    x = 123
    sig.fit = 3
    check(sig(0, 2), "0.0")
    sig.fit = -3
    check(sig(0,  2), "0.0")
    sig.fit = 4
    check(sig(0,  2), " 0.0")
    sig.fit = -4
    check(sig(0,  2), "0.0 ")
    sig.fit = 8
    check(sig(0,  4), "   0.000")
    sig.fit = -8
    check(sig(0,  4), "0.000   ")
    sig.fit = 6
    check(sig(x,  2), "  120.")
    check(sig(-x, 2), " -120.")
    sig.idp = False
    check(sig(x,  2), "   120")
    check(sig(-x, 2), "  -120")
    sig.idp = True
    sig.fit = 2
    check(sig(0,  3), "0.")
    sig.fit = 1
    check(sig(0,  3), "N")
    sig.fit = 4
    check(sig(x,  2), "120.")
    sig.fit = 3
    check(sig(x,  2), "Non")
    sig.idp = False
    check(sig(x,  2), "120")
    sig.idp = True
    sig.fit = 5
    check(sig(-x, 2), "-120.")
    sig.fit = 4
    check(sig(-x, 2), "None")
    x = 1.23e8
    sig.high = 10
    sig.fit = 5
    check(sig(x,  2), " 1e+8")
    sig.fit = 6
    check(sig(x,  2), "1.2e+8")
    sig.fit = 7
    check(sig(x,  2), " 1.2e+8")
    sig.fit = -7
    check(sig(x,  2), "1.2e+8 ")
    sig.fit = 8
    check(sig(x,  2), "  1.2e+8")
    sig.fit = -8
    check(sig(x,  2), "1.2e+8  ")
    sig.fit = 6
    check(sig(-x, 2), " -1e+8")
    sig.fit = 7
    check(sig(-x, 2), "-1.2e+8")
    x = 1.23e-8
    sig.low = 1e-1
    sig.fit = 5
    check(sig(x,  2), " 1e-8")
    sig.fit = 6
    check(sig(x,  2), "1.2e-8")
    check(sig(-x, 2), " -1e-8")
    sig.fit = 7
    check(sig(-x, 2), "-1.2e-8")
    sig.fit = 8
    check(sig(-x, 2), " -1.2e-8")
    sig.fit = -8
    check(sig(-x, 2), "-1.2e-8 ")

def test_sign_feature():
    sig.reset()
    sig.sign = True
    check(sig(0,  1), "+0.")
    check(sig(1,  1), "+1.")
    check(sig(-1, 1), "-1.")
    sig.idp = False
    check(sig(1,  1), "+1")
    check(sig(-1, 1), "-1")
    sig.sign = False
    sig.idp = True
    check(sig(0,  1), "0.")
    check(sig(1,  1), "1.")
    sig.reset()

def test_rtz_feature():
    sig.reset()
    x = 1.23
    sig.rtz = False
    check(sig(x, 5), "1.2300")
    sig.rtz = True
    check(sig(x, 5), "1.23")

def test_lead_zero_feature():
    sig.reset()
    sig.lead_zero = True
    check(sig(0.1, 2), "0.10")
    sig.lead_zero = False
    check(sig(0.1, 2), ".10")
    sig.separator = ", "
    check(sig((0.1, 0.2), 2), u"(.10, .20)")
    check(sig([0.1, 0.2], 2), u"[.10, .20]")
    sig.separator = " "
    check(sig((0.1, 0.2), 2), u"(.10 .20)")
    check(sig([0.1, 0.2], 2), u"[.10 .20]")

def test_check():
    # Since most of the attributes don't have getters/setters,
    # ensure that a faulty attribute setting can be detected by
    # running sig.check().
    #
    # Integer
    sig.edigits = 0
    raises(ValueError, sig.check)
    sig.edigits = 1
    # Float
    sig.zero_limit = "a"
    raises(ValueError, sig.check)
    sig.zero_limit = 10
    # Boolean
    sig.esign = 0
    raises(TypeError, sig.check)
    sig.esign = True
    # String
    sig.dp = 0
    raises(TypeError, sig.check)
    sig.dp = "."

def test_separator_feature():
    sig.reset()
    sig.separator = ";"
    check(sig([0.1, 0.2], 2), "[0.10;0.20]")

def test_digits_attribute():
    sig.reset()
    x = 1.23456789
    sig.digits = 5
    check(sig(x), "1.2346")
    check(sig(x, 2), "1.2")  # Show parameter overrides attribute
    # Negative numbers and zero should raise exception
    raises(ValueError, sig, 0, 0)
    raises(ValueError, sig, x, -2)
    raises(ValueError, sig, x, -2.2)
    # Show we can get template rounding too
    check(sig(x, "0.15"), "1.20")
    check(sig(x, "0.02"), "1.24")
    # Check that bad digits attribute is detected
    try:
        sig.digits = 0
        raise RuntimeError("Exception expected")
    except ValueError:
        pass
    try:
        sig.digits = -1
        raise RuntimeError("Exception expected")
    except ValueError:
        pass

def test_string_argument():
    sig.reset()
    s = "1.234"
    check(sig(s, 4), s)
    check(sig(s, 2), "1.2")

def test_sequences():
    sig.reset()
    x = (1.234, -2.234)
    sig.separator = ", "
    check(sig(x, 2), "(1.2, -2.2)")
    check(sig(list(x), 2), "[1.2, -2.2]")
    check(sig(["1.2345", (-9.87654, 1.2e-9)], 2), "[1.2, (-9.9, 1.2e-9)]")
    sig.separator = " "
    check(sig(x, 2), "(1.2 -2.2)")
    check(sig(list(x), 2), "[1.2 -2.2]")
    check(sig(["1.2345", (-9.87654, 1.2e-9)], 2), "[1.2 (-9.9 1.2e-9)]")

def test_getters_and_setters():
    sig.reset()
    d = Dec("5.2")
    sig.digits = d
    check(sig.digits, d)
    sig.low = d
    check(sig.low, d)
    sig.high = d
    check(sig.high, d)
    d = 2  # int type
    sig.low = d
    check(sig.low, d)
    d = "2"  # str type
    sig.low = d
    check(sig.low, Dec(d))
    d = "1/2"  # Fraction type
    sig.low = Fraction(d)
    check(sig.low, 1/Dec(2))
    d = "0.5"  # float type
    sig.low = float(d)
    # The following test works because 0.5 is exact as a binary
    # floating number.
    check(sig.low, 1/Dec(2))

def test_zero_limit_threshold():
    sig.reset()
    sig.zero_limit = 1e-1
    check(sig(0.0999, 3), "0.00")

def test_none_handled_correctly():
    sig.reset()
    sig.ignore_none = False
    raises(ValueError, sig, None, 1)
    sig.ignore_none = True
    check(sig(None, 1), "0.")

def test_can_iterate_on_numpy_arrays():
    sig.reset()
    if not _have_numpy:
        return
    x = np.array((1.234, -2.234))
    sig.separator = ", "
    check(sig(x, 2), "[1.2, -2.2]")
    sig.separator = " "
    check(sig(x, 2), "[1.2 -2.2]")

def test_fractions():
    sig.reset()
    # Fractions as strings:  test _ConvertFractionToDecimal
    f = Dec(3)/Dec(2)
    # Proper fractions
    check(sig._ConvertFractionToDecimal("1-1/2"), f)
    check(sig._ConvertFractionToDecimal("-1-1/2"), -f)
    check(sig._ConvertFractionToDecimal("1+1/2"), f)
    check(sig._ConvertFractionToDecimal("-1+1/2"), -f)
    f = Dec(1)/Dec(2)
    # Normal fractions
    check(sig._ConvertFractionToDecimal("1/2"), f)
    check(sig._ConvertFractionToDecimal("+1/2"), f)
    check(sig._ConvertFractionToDecimal("-1/2"), -f)
    f = Dec(11)/Dec(2)
    # Improper fractions
    check(sig._ConvertFractionToDecimal("11/2"), f)
    check(sig._ConvertFractionToDecimal("+11/2"), f)
    check(sig._ConvertFractionToDecimal("-11/2"), -f)
    # Check fraction conversions
    t, f = "-2.188", 4
    check(sig("1-1/2", 3), "1.50")
    check(sig("-2-3/16", f), t)
    check(sig("-2+3/16", f), t)
    t = "2.188"
    check(sig("2-3/16", f), t)
    check(sig("2+3/16", f), t)
    check(sig("+2-3/16", f), t)
    check(sig("+2+3/16", f), t)

def test_string_array():
    sig.reset()
    s = '''1.2345 1-1/4 3-4i -12.222j
    -2-1/8;3,                       4;5
-12234.355
'''
    r = "[1.2 1.2 3.0-4.0i -12.i -2.1 3.0 4.0 5.0 -12000.]"
    check(sig(s, 2), r)

def test_template_rounding():
    sig.reset()
    x, xs, ts, r, rs, rf = 1.234, "1.234", "1.25", 0.05, "0.05", "1/20"
    f = sig._TemplateRound
    sig.digits = 4
    check(Dec(sig(f(x, r))),              Dec(ts))
    check(Dec(sig(f(-x, r))),             Dec("-" + ts))
    check(Dec(sig(f(x, rs))),             Dec(ts))
    check(Dec(sig(f(-x, rs))),            Dec("-" + ts))
    check(Dec(sig(f(x, rf))),             Dec(ts))
    check(Dec(sig(f(-x, rf))),            Dec("-" + ts))
    check(Dec(sig(f(xs, r))),             Dec(ts))
    check(Dec(sig(f(xs, rs))),            Dec(ts))
    check(Dec(sig(f(xs, rf))),            Dec(ts))
    check(Dec(sig(f(1, r))),              Dec(1))
    check(Dec(sig(f(1, rs))),             Dec(1))
    check(Dec(sig(f(1, rf))),             Dec(1))
    if _have_mpmath:
        x = mp.mpf(xs)
        check(Dec(sig(f(x, r))),          Dec(ts))
        check(Dec(sig(f(x, rs))),         Dec(ts))
        check(Dec(sig(f(x, rf))),         Dec(ts))
        check(Dec(sig(f(x, mp.mpf(rs)))), Dec(ts))
    # Check that we can round to fractions
    x = Dec("3.456789")
    sig.mixed = True
    check(sig(x, Fraction(1, 16)), "3+7/16")
    sig.mixed = False
    check(sig(x, Fraction(1, 16)), "55/16")
    check(sig("17/64", Fraction(1, 16)), "1/4")
    check(sig("1+3/16", Fraction(3, 16)), "9/8")

def test_complex_rectangular():
    sig.reset()
    z = _Complex(Dec("0"), Dec("0"))
    x1 = _Complex(Dec("1.2345"), Dec("-9.8765"))
    x2 = _Complex(Dec("1.2345"), Dec("0"))
    x3 = _Complex(Dec("0"), Dec("-1.2345"))
    sig.imag_pre = sig.imag_post = ""
    sig.imag_polar = False
    sig.imag_before = False
    sig.idp = False
    check(sig(x1, 2), "1.2-9.9i")
    check(sig(x1, 1), "1-10i")
    sig.idp = True
    check(sig(x1, 1), "1.-10.i")
    # Pure real
    check(sig(x2, 2), "1.2")
    check(sig(z, 2), "0.0")
    # zero_limit affects the real part only
    sig.zero_limit = 2
    check(sig(x2, 2), "0.0")
    sig.zero_limit = 0
    # Pure imaginary
    check(sig(x3, 2), "-1.2i")
    check(sig(x3, 4), "-1.234i")
    # Can put imaginary unit before Im
    sig.imag_before = True
    check(sig(x1, 2), "1.2-i9.9")
    check(sig(x3, 2), "-i1.2")
    # Unit separator
    sig.imag_sep = ";"
    check(sig(x3, 2), "-i;1.2")
    # Can change imaginary unit
    sig.imag_unit = "j"
    check(sig(x3, 2), "-j;1.2")
    sig.imag_unit = "i"
    sig.imag_sep = ""
    sig.imag_before = False
    # Check that we can use mpmath's complex numbers
    if _have_mpmath:
        x1 = mp.mpc("1.2345", "-9.8765")
        check(sig(x1, 2), "1.2-9.9i")
    sig.reset()
    # Can fit a complex number
    sig.fit = 10
    check(sig(x1, 2), "  1.2-9.9i")
    sig.fit = -sig.fit
    check(sig(x1, 2), "1.2-9.9i  ")
    sig.fit = 4
    check(sig(x1, 2), "None")
    sig.fit = 2
    check(sig(x1, 2), "No")

def test_complex_polar():
    sig.reset()
    z = _Complex(Dec("0"), Dec("0"))
    x1 = _Complex(Dec("1.2345"), Dec("-9.8765"))
    x2 = _Complex(Dec("1.2345"), Dec("0"))
    x3 = _Complex(Dec("0"), Dec("-1.2345"))
    sig.imag_polar = True
    sig.imag_deg_sym = "*"
    # Can get angle in degrees
    sig.imag_deg = True
    check(sig(x1, 2), "10./_-83.*")
    sig.idp = False
    check(sig(x1, 2), "10/_-83*")
    # Can change degree symbol 
    sig.imag_deg_sym = "@"
    check(sig(x1, 2), "10/_-83@")
    sig.imag_deg_sym = "*"
    # Can get angle in radians
    sig.imag_deg = False
    check(sig(x1, 2), "10/_-1.4")
    # Can separate magnitude from angle
    sig.imag_pre = sig.imag_post = ":"
    check(sig(x1, 2), "10:/_:-1.4")
    # Can change polar separator
    sig.imag_polar_sep = "|"
    sig.imag_pre = sig.imag_post = ""
    check(sig(x1, 2), "10|-1.4")

def test_complex_pair():
    sig.reset()
    sig.digits = 2
    sig.imag_pair = True
    sig.imag_pair_left = "C("
    sig.imag_pair_sep = ","
    sig.imag_pair_right = ")"
    z = _Complex(Dec("0"), Dec("0"))
    x1 = _Complex(Dec("1.2345"), Dec("-9.8765"))
    x2 = _Complex(Dec("1.2345"), Dec("0"))
    x3 = _Complex(Dec("0"), Dec("-1.2345"))
    check(sig(z), "C(0.0,0.0)")
    check(sig(x1), "C(1.2,-9.9)")
    check(sig(x2), "C(1.2,0.0)")
    check(sig(x3), "C(0.0,-1.2)")

def test_Decimal_mpmath():
    sig.reset()
    # Check Decimal and mpmath number types
    sig.reset()
    def ExtPrec(D=None):
        '''D is the number type.
        '''
        sig.reset()
        # Works for 0
        check(sig(D(0), 2), "0.0")
        x = D("1e-2")/D(3)
        sig.lead_zero = False
        check(sig(x, 4), ".003333")
        # Underflows to scientific
        x = D("1e-3")/D(3)
        check(sig(x, 4), "3.333e-4")
        x = D("1e2")/D(3)
        sig.high = 1e2
        check(sig(x, 4), "33.33")
        sig.esign = True
        check(sig(10*x, 4), "3.333e+2")
        # Overflows to scientific
        x = D("1e3")/D(3)
        sig.esign = False
        check(sig(x, 4), "3.333e2")
        # Set that we can get lots of characters
        x = D("10")/D(3)
        check(sig(x, 21), "3." + ("3"*20))
        # Check negative numbers work
        check(sig(-x, 2), "-3.3")
    # Decimal 
    d = 30
    with decimal.localcontext() as ctx:
        ctx.prec = d
        ExtPrec(Dec)
    # mpmath 
    if _have_mpmath:
        mp.mp.dps = d
        ExtPrec(mp.mpf)

def test_large_floats():
    sig.reset()
    if py3:
        # Python 3 apparently has smaller limits than python 2
        x = Dec("1.23456e123456")
        check(sig(x, 2), "1.2e+123456")
        sig.edigits = 1
        check(sig(x, 2), "1.2e+123456")
        sig.edigits = 10
        check(sig(x, 2), "1.2e+0000123456")
    else:
        x = Dec("1.23456e123456789")
        check(sig(x, 2), "1.2e+123456789")
        sig.edigits = 1
        check(sig(x, 2), "1.2e+123456789")
        sig.edigits = 10
        check(sig(x, 2), "1.2e+0123456789")

def test_deep_nesting():
    '''Show we don't get any exceptions using sig on a deeply-nested
    list, at least until the python's parser stack overflows.
    
    Note:  I haven't figured out how to get this to run successfully on
    python 3; it works on python 2.6.5 and 2.7.2.
    
    When this runs, you'll see the message 's_push: parser stack
    overflow' sent to stdout.  This is normal and indicates the parser
    failed.
    '''
    sig.reset()
    if sys.version < "3":
        n = 10
        while True:
            n += 1
            s = "mylist = " + "["*n + "0" + "]"*n
            try:
                exec(s, globals(), locals())
            except MemoryError:
                break
            else:
                # We'll get an exception here if sig somehow fails
                sig(mylist)

def test_atan2():
    '''Run some sanity checks against mpmath.  If a command line
    parameter is passed, it is the number of digits of precision to use.
    A following parameter is the number of tests to run.
    '''
    if not _have_mpmath:
        return
    import sys, mpmath as mp, random
    digits, rnd_range = 20, 1000
    prec = 10*(D(10)**D(-digits)) # Relative precision decision limit
    a = rnd_range
    if _have_mpmath:
        # Check against mpmath if available
        M = mp.mpf
        decimal.getcontext().prec = mp.mp.dps = digits
        def check(got, expected):
            if abs(got - expected) > prec:
                s = "Test failure\nGot      = {0}\nExpected = {1}"
                s = s.format(str(got), str(expected))
                assert 1 == 0, s
        mp2d = lambda x: D(str(x))
        random.seed(123)
        for i in range(100):
            xs, ys = str(random.uniform(-a, a)), str(random.uniform(-a, a))
            got = atan2(D(ys), D(xs))
            expected = mp.atan2(M(ys), M(xs))
            check(got, mp2d(expected))
    # Test some special cases.  Note this check() is needed rather
    # than check() because the atan2(_one, -_one) case is off
    # of the actual by 1 digit in the last place.
    check(atan2(_one, _zero), pi()/2)
    check(atan2(-_one, _zero), -pi()/2)
    check(atan2(_zero, _one), _zero)
    check(atan2(_zero, -_one), pi())
    check(atan2(_one, _one), pi()/4)
    check(atan2(_one, -_one), 3*pi()/4)
    check(atan2(-_one, _one), -pi()/4)
    check(atan2(-_one, -_one), -3*pi()/4)

def test_uncertainties():
    if not _have_uncertainties:
        return
    U = unc.ufloat
    # Test the long forms
    #   * Regular
    sig.unc_short = False
    x = U(123.456789, 6)
    sig.idp = True
    check(sig(x, 1), "100.+/-6.")
    sig.unc_digits = 2
    check(sig(x, 2), "120.+/-6.0")
    check(sig(x, 3), "123.+/-6.0")
    check(sig(x, 6), "123.457+/-6.0")
    sig.idp = False
    sig.unc_digits = 1
    check(sig(x, 1), "100+/-6")
    #   * Scientific notation
    x = U(1.23456789e-6, 6e-9)
    check(sig(x, 2), "1.2e-6+/-6e-9")
    check(sig(x, 6), "1.23457e-6+/-6e-9")
    # Test the short forms
    #   * Regular
    sig.idp = False
    sig.unc_short = True
    T = (
        (-5, "12345.67890(6)"),
        (-4, "12345.6789(6)"),
        (-3, "12345.679(6)"),
        (-2, "12345.68(6)"),
        (-1, "12345.7(6)"),
        (0, "12346(6)"),
        (1, "12350(60)"),
        (2, "12300(600)"),
        (3, "12000(6000)"),

        # xx I've commented out the following test case.  For some
        # reason, it works under 2.7/3.4 when this file is run as a
        # script, but when run using nosetests, it fails because the
        # string is "12300+/-60000" instead of what's shown.  I've used
        # the --pdb option to nose and it indeed evaluates to this, so
        # it will take some debugging to figure out the cause (I'm
        # betting it's some kind of race condition.
        
        #(4, "12350+/-60000"),  # Overflows to standard display
    )
    for i, expected in T:
        check(sig(U(1.23456789e4, 6*10**i)), expected)
    sig.idp = True
    T = (
        (-5, "12345.67890(6)"),
        (-4, "12345.6789(6)"),
        (-3, "12345.679(6)"),
        (-2, "12345.68(6)"),
        (-1, "12345.7(6)"),
        (0, "12346.(6)"),
        (1, "12350.(60)"),
        (2, "12300.(600)"),
        (3, "12000.(6000)"),

        # See similar comment above for why this is commented out.
        #(4, "12350.+/-60000."),  # Overflows to standard display
    )
    for i, expected in T:
        check(sig(U(1.23456789e4, 6*10**i)), expected)
    #   * Scientific notation
    x = U(1.23456789e-6, 6e-9)
    check(sig(x, 1), "1.235(6)e-6")
    check(sig(x, 2), "1.2346(60)e-6")
    check(sig(x, 3), "1.23457(600)e-6")
    # The following is needed because it's an uncertainties
    # variable of a different type (AffineScalarFunc instead of a
    # Variable).
    check(sig(x*x, 3), "1.5242(148)e-12")
    # The following test cases came about because of a bug (the fix was to
    # round the uncertainty before formatting it).
    check(sig(U(51.4, 0.099)), "51.4(1)")
    check(sig(U(51.4, 0.99)), "51.(1)")

def TestGetSigFig():
    data = '''
        # Various forms of 0
        0 1
        +0 1
        -0 1
        0. 1
        0.0 1
        00 1
        000000 1
        .0 1
        .00 2
        0.00 2
        00.00 2
        .000000 6
        0.000000 6
        00.000000 6
    #
        1 1
        +1 1
        -1 1
        1. 1
        .000001 1
        0.1 1
        .1 1
        +.1 1
        -.1 1
        1.0 2
        10 1
        100000 1
        12300 3
        123.456 6
        +123.456 6
        -123.456 6
        123.45600 8
        012300 3
        0123.456 6
        0123.45600 8
        0.00000000000000000000000000001 1
        0.000000000000000000000000000010 2
        1e4 1
        1E4 1
        01e4 1
        01E4 1
        1.e4 1
        1.E4 1
        01.e4 1
        01.E4 1
        1.0e4 2
        1.0E4 2
        01.0e4 2
        01.0E4 2
        123.456e444444 6
        123.45600e444444 8
        000000123.456e444444 6
        000000123.45600e444444 8
    # Numbers with various uncertainty forms
        1.200+/-0.1 4
        +1.200+/-0.1 4
        -1.200+/-0.1 4
        1.200+-0.1 4
        +1.200+-0.1 4
        -1.200+-0.1 4
        1.200±0.1 4
        +1.200±0.1 4
        -1.200±0.1 4
    # Numbers with short-form uncertainties
        1.200(22) 4
        0.200(22) 3
        .200(22) 3
        +1.200(22) 4
        +0.200(22) 3
        +.200(22) 3
        -1.200(22) 4
        -0.200(22) 3
        -.200(22) 3
    # Some Codata numbers from scipy.constants
        6.6446568(3)e-27        8
        5.291772109(2)e-11     10
        8.85(0)e-12             3
        -1.75882009(4)e+11      9
        9.1093829(4)e-31        8
        96485.336(2)            8
        1.26(0)e-6              3
        8.314462(8)             7
        6.6738(8)e-11           5
        6.6260696(3)e-34        8
        1.097373156854(6)e+7   13
        3.00(0)e+8              3
        9.81(0)                 3
        1.01(0)e+5              3
        1.00(0)e+5              3
    '''
    for i in data.strip().split("\n"):
        i = i.strip()
        if not i or i.startswith("#"):
            continue
        if 0:
            print(i.strip())
        try:
            s, n = i.split()
        except Exception:
            xx()
        a = GetSigFig(s)
        n = int(n)
        assert_equal(a, n)
    # Test with inttzsig
    assert_equal(GetSigFig("12300", inttzsig=False), 3)
    assert_equal(GetSigFig("12300", inttzsig=True), 5)
    # Forms that raise exceptions
    raises(ValueError, GetSigFig, 1)
    raises(ValueError, GetSigFig, 1.0)
    raises(ValueError, GetSigFig, "a")
    raises(ValueError, GetSigFig, "e2")
    raises(ValueError, GetSigFig, "1..e2")
    # Show that GetSigFig works with strings from Decimal objects
    from decimal import Decimal
    n = 50
    x = Decimal("1." + "1"*n)
    assert_equal(GetSigFig(str(x)), n + 1)

def test_integer():
    sig.reset()
    x = 894574979375947
    sig.integer = 0
    sig.digits = 3
    got = sig(x)
    check(got, "8.95e+14")
    sig.integer = 1
    got = sig(x)
    check(got, "894574979375947")
    # For locale testing.  Worked fine under cygwin under Windows
    # XP; doesn't work under Ubuntu Linux 14.04 with python 2.7.6.
    if 0:
        orig_locale = locale.getlocale()
        L = ("English_United States", "1252")
        locale.setlocale(locale.LC_ALL, L)
        sig.integer = 2
        got = sig(x)
        check(got, "894,574,979,375,947")
        locale.setlocale(locale.LC_ALL, orig_locale)

def test_dp_fit():
    sig.reset()
    sig.digits = 3
    num, ten, r, w, p = Dec("3.1415926"), Dec(10), 4, 8, 4
    expected = {
         4 : "   -.-  ",
         3 : "3140.   ",
         2 : " 314.   ",
         1 : "  31.4  ",
         0 : "   3.14 ",
        -1 : "   0.314",
        -2 : "   0.031",
        -3 : "   0.003",
        -4 : "   -.-  ",
    }
    # Fit using the function call
    for i in range(r, -r - 1, -1):
        x = num*ten**i
        got = sig.AlignDP(x, width=w, position=p)
        check(got, expected[i])
    # Fit using the attributes
    sig.fit = w
    sig.dp_position = p
    for i in range(r, -r - 1, -1):
        x = num*ten**i
        got = sig(x)
        check(got, expected[i])

def test_InterpretNumber():
    bad = (None, "")
    test_cases = ( # String, expected return value
        # Weird/wrong input
        ("", bad),
        ("   ", bad),
        ("  m/s", bad),
        ("1(.1)m", bad),
        ("1()m", bad),
        ("1[]m", bad),
        ("()m", bad),
        ("[]m", bad),
        ("(m", bad),
        (")m", bad),
        ("[m", bad),
        ("]m", bad),
        ("abc", bad),
        # Integers 
        ("0", (0, "")),
        ("0m/s", (0, "m/s")),
        ("0 m/s", (0, "m/s")),
        ("-12345m/s", (-12345, "m/s")),
        # Floats
        ("0.", (0, "")),
        (".0", (0, "")),
        ("0.m/s", (0, "m/s")),
        (".0m/s", (0, "m/s")),
        (".0 m/s", (0, "m/s")),
        ("12345.m/s", (12345., "m/s")),
    )
    for s, expected in test_cases:
        got = sig.Interpret(s)
        # If result is a ufloat, pick it apart into components.
        # This is because of the semantics of ufloat comparisons
        # (see the manual for an explanation of why).
        if (not isinstance(expected[0], (int, long, float)) and
            expected[0] is not None):
            u = expected[0]
            expected = (u.nominal_value, u.std_dev, expected[1])
            u = got[0]
            got = (u.nominal_value, u.std_dev, got[1])
        elif expected[0] is None:
            check(got[0], None)
        else:
            check(got, expected)
    # Expressions
    got = sig.Interpret("a*b/c", loc={"a":2.5, "b":4, "c":10})
    check(got[0], 1)
    got = sig.Interpret("a*b/c", glo={}, loc={"a":2.5, "b":4, "c":10})
    check(got[0], 1)
    # Assignments
    loc, n = {}, 17
    got = sig.Interpret("3 = %d" % n, loc=loc, strict=False)
    check(loc["3"], n)
    got = sig.Interpret("3 = %d" % n, loc=loc, strict=True)
    check(got[0], None)
    # Works with other float types
    s = "3.4"
    got = sig.Interpret(s, fp_type=Dec)
    check(got[0], Dec(s))
    # Now test with uncertainty stuff
    if _have_uncertainties:
        U = unc.ufloat
        test_cases = ( # String, expected return value
            # Integers 
            ("0[0]", (U(0, 0), "")),
            ("0[0] m/s", (U(0, 0), "m/s")),
            ("0[1] m/s", (U(0, 1), "m/s")),
            ("1[1000] m/s", (U(1, 1000), "m/s")),
            ("0+/-0m", (U(0, 0), "m")),
            ("0+-0m", (U(0, 0), "m")),
            ("0+-0m", (U(0, 0), "m")),
            ("0+-1m", (U(0, 1), "m")),
            ("1+-0m", (U(1, 0), "m")),
            ("1+-1m", (U(1, 1), "m")),
            ("0(0)m", (U(0, 0), "m")),
            ("0(1)m", (U(0, 1), "m")),
            ("1(1)m", (U(1, 1), "m")),
            ("-1(1)m", (U(-1, 1), "m")),
            ("-12345(1)m", (U(-12345, 1), "m")),
            ("-12345(1)", (U(-12345, 1), "")),
            ("-1000001(8) kg*m/s2", (U(-1000001, 8), "kg*m/s2")),
            # Floats
            (".0[0.1] m/s", (U(0, 0.1), "m/s")),
            (".00001[100] m/s", (U(1e-5, 100), "m/s")),
            ("-1.234e-88[0.001e-88]", (U(-1.234e-88, 1e-91), "")),
            ("1.234+/-1.234e-5m", (U(1.234, 1.234e-5), "m")),
            ("1.234+-1.234e-5m", (U(1.234, 1.234e-5), "m")),
            ("1.(1)m", (U(1, 1), "m")),
            ("1.234(45)m", (U(1.2345, 0.045), "m")),
            ("1.234(45)e-11m", (U(1.234e-11, 0.045e-11), "m")),
            (".01(45)m", (U(0.01, 0.45), "m")),
            (".000001(8)e-10 kg*m/s2", (U(1e-16, 8e-16), "kg*m/s2")),
            (".000001000(8)e-10 kg*m/s2", (U(1e-16, 8e-19), "kg*m/s2")),
            # Percentage and ppm
            ("1.234[0.45%]m", (U(1.234, 0.45*1.234/100), "m")),
            ("1.234[0.45u]m", (U(1.234, 0.45*1.234/1e6), "m")),
            ("1.234[0.45%]", (U(1.234, 0.45*1.234/100), "")),
            ("1.234[0.45u]", (U(1.234, 0.45*1.234/1e6), "")),
        )
        for s, expected in test_cases:
            got = sig.Interpret(s)
            # If result is a ufloat, pick it apart into components.
            # This is because of the semantics of ufloat comparisons
            # (see the manual for an explanation of why).
            if (not isinstance(expected[0], (int, long, float)) and
                expected[0] is not None):
                u = expected[0]
                expected = (u.nominal_value, u.std_dev, expected[1])
                u = got[0]
                got = (u.nominal_value, u.std_dev, got[1])
            elif expected[0] is None:
                check(got[0], None)
            else:
                check(got, expected)

def test_Unicode():
    sig = SigFig()
    sig.reset()
    sig.unicode = True
    sig.digits = 3
    sig.esign = True
    # Scientific notation
    check(sig(1.23e44), u"1.23×10⁺⁴⁴")
    check(sig(1.23e-44), u"1.23×10⁻⁴⁴")
    sig.esign = False
    check(sig(1.23e44), u"1.23×10⁴⁴")
    # Polar form of complex numbers
    sig.imag_polar = True
    check(sig(1+1j), u"1.41∡45.0°")
    if _have_uncertainties:
        U = unc.ufloat
        sig.unc_short = False
        x = U(123.456789, 6)
        sig.idp = True
        check(sig(x, 1), u"100.±6.")

def test_mpmath_interval():
    '''This is written to work with mpmath 0.18 inteval numbers.  Note it
    doesn't work with mpmath 0.19.
    '''
    if not _have_mpmath or mp.__version__ != "0.18":
        return
    sig = SigFig()
    sig.reset()
    x = mp.mpi(0.1)
    s = sig(x)
    assert_equal(s, "<0.100, 0.100>")


if __name__ == "__main__":
    init()
    exit(run(globals())[0])
