from __future__ import print_function, division
import sys, os, getopt
from out import Out
from lwtest import run, raises
from pdb import set_trace as xx

py3 = True if sys.version_info[0] > 2 else False
py2 = not py3

if py3:
    long = int
    from io import StringIO as sio
else:
    from StringIO import StringIO as sio

def testTypicalUsage():
    out, s = Out(), sio()
    out.stream = s
    out(1, "2", 3.1)
    assert(s.getvalue() == "1 2 3.1\n")

def test_sep():
    out, s = Out(), sio()
    out.stream = s
    out.sep = "|"
    out(1, 2)
    assert(s.getvalue() == "1|2\n")

def test_stream():
    out = Out()
    out.stream = None
    out("a", 2, 3)  # Nothing happens
    s = sio()
    out.stream = s
    out("a")
    assert(s.getvalue() == "a\n")
    # Note this tests end too
    out.end = ""
    s = sio()
    out.stream = s
    out("a")
    assert(s.getvalue() == "a")

if __name__ == "__main__":
    exit(run(globals())[0])
