'''
Provides the class Out, which is a utility class for sending output to
a stream by making a function call on the instance.  For example,

    out = Out()
    out("Hello", "world")

which prints out

    Hello world

The intent is to provide a function for python 2 that emulates the
behavior of the print function in python 3.  This is done via the
following keyword arguments:

    Keyword     Purpose                                     Default
    -------     ----------------------------------------    -------
    end         String emitted after the arguments have      "\n"
                been processed.
    sep         String between each argument                  " "
    file        Stream to send the information               stdout
    flush       If True, flush the stream                    False

These are also class attributes, so you can set them and they will
persist.  The keyword arguments override the current attributes, but
only for that particular function call.
'''

# Copyright (C) 2014 Don Peterson
# Contact:  gmail.com@someonesdad1

#
# Licensed under the Open Software License version 3.0.
# See http://opensource.org/licenses/OSL-3.0.
#

from __future__ import division, print_function
import sys
import os
import getopt

all = ["Out", "out"]

py3 = True if sys.version_info[0] > 2 else False
py2 = not py3

if py3:
    long = int

class Out(object):
    def __init__(self):
        self.stream = sys.stdout
        self.flush = False
        self.end = "\n"
        self.sep = " "
    def __call__(self, *v, **kw):
        '''Sends the string representation of each element of v to the
        stream.  Same keywords as print() in python 3, but they only
        have an effect during the function call.  Change the
        attributes if you want a permanent change.
        '''
        end = kw.setdefault("end",    self.end)
        sep = kw.setdefault("sep",    self.sep)
        stream = kw.setdefault("file",   self.stream)
        flush = kw.setdefault("flush",  self.flush)
        if v and stream:    # Print each parameter
            stream.write(str(sep).join([str(i) for i in v]))
        if end and stream:
            stream.write(end)
        if self.flush:
            self.stream.flush()
            self.flush = False

# out is a convenience instance of the Out object
out = Out()
