.[

    This is a 'comment block'.  Its text is ignored by the ts.py
    script.

    This is the source text for the documentation of the ts.py script.
    After being processed by the ts.py script, it will be a
    reStructuredText (RST) file.  Such files have the advantage of
    being reasonably readable as plain text and they can be converted
    to other forms using the docutils
    (http://docutils.sourceforge.net/index.html) utilities.  For
    example, you can convert the document to HTML format by the
    commands

        python ts.py ts.ts >ts.rst
        rst2html.py ts.rst ts.html
           ^-- I alias this to r2h

    rst2html.py is one of the docutils utilities
    (https://docutils.sourceforge.io/)
    Doc page at https://docutils.sourceforge.io/rst.html

    The main feature the ts.py script is the ability to define a chunk
    of text in one place and refer to it in a number of others; when
    it comes time to change the text, you only have to edit one
    location.  This is done below for the name of the script, ts.py,
    defined in the '.sub' line.

    The python variables 'leveln' are used to set the restructured
    text heading levels.
.]
.(
    # This is a 'code block'.  It is used to define a chunk of python
    # code that is executed after the block end command '.)' is
    # encountered.  This lets you do arbitrary processing and define
    # string variables that will later be formatted using python's
    # str.format() method.

    # Define some variables that can be used with python's text
    # formatting operator (these are converted to heading levels in
    # RST).
    m = 60
    level1 = "="*m
    level2 = "-"*m
    level3 = "+"*m
    level4 = "^"*m

    # Generate a table of contents if co is True.
    co = True
    contents = ".. contents:: Table of Contents" if co else ""
.)
.# The primary substitution for the script's name.  Note that '.#'
.# lets you define individual comment lines that are ignored by the
.# ts.py script.
.sub("$name", "``ts.py``")

.# Environment variable name
.sub("$ts_path", "``TS_PATH``")

Tests needed:

* Substitutions and options.  
* Includes:  see that cont and times work as expected.
* See that ignore works on all commands that support it.
* Need to ensure that an exception in a code block results in both a
  usable backtrace and exits the program.  

Consider adding a **namespace** keyword to the beginning of a
codeblock.  This would be a function ``namespace(s)`` that would
define the string s which names the namespace to use for evaluating
the code.  There would also be a default namespace that would be used
if there is no namespace() call.  The other commands need to have the
keyword ``namespace`` added to let them define which namespace to use
when they are evaluated.  The purpose of this is to allow
redefinitions of things based on processing outcomes.

{contents}

Text Substitution
{level1}

**Purpose**:  $name provides a text-substitution facility for text
files.  Each text file given on the command line contains regular text
and special commands that cause text substitution, file inclusion, and
formatting to occur.  Each file on the command line is processed to
produce the composite output text.  The resulting text is processed and
sent to stdout.  Key features and design goals are

* Simple tasks are simple.
* Simple syntax that's easy to remember.
* Use python to do command parsing.
* Substitutions are either simple text or regular expressions;
  backreferences are allowed.
* Python code can be embedded in the text.
* Other files containing text/substitutions/code can be included.
* Substitutions are applied in the order they're found.
* Easy to comment out chunks of text.
* Formatting blocks can be used to wrap, number lines, etc.  A format
  block's text can also be sent to an external pipeline.
* $name is a python module; use the script's text substitution
  facilities in your own python scripts.
* Verbose mode (``-v``) lets you see how text gets changed.
* It's straightforward to add new functionality.
* It's a minimum package -- you just need the $name script.

This tool is **not** a *macro processor*.  There are already a
gazillion macro processors out there and people can't help adding
features to them until their manpages will float a battleship, their
syntax will sink a battleship, and semantically they *are*
battleships [1]_.  I can use e.g.  ``m4`` if I need macro processing power
-- but I use it seldom enough that I can't remember the syntax and I
hate having to spend 15 minutes reading a manpage to do something
simple.  The $name script lets me do these simple tasks quickly and
easily by just looking at the usage statement with the ``-h`` option
at the command line.

**Basic syntax**:  text encountered by the $name script is passed
unchanged to the output stream except for a few special commands.  A
special command begins with ``.`` in the first column (this can be
changed with a command line option).  Most of what you need to know to
use the basic features are in the following lines:

 ::

    .sub(in, out)   Substitute 'out' strings for 'in' strings
    .out(expr)      Turn output on/off based on bool(expr)
    .inc(file)         Include the text from a file
    .( or .)            Code block for arbitrary python code
    .[ or .]            Comment out a block of text
    .< or .>         Formatting block (wrapping, columns, etc.)
    {{name}}         Python variable substitution via string formatting

Basic examples
{level2}

The following two examples demonstrate the primary functionality of
the $name script:  making text substitutions.  This lets you define a
term in one place in a file and have it substituted in numerous other
places -- when you want to change the text in a term, you only need to
change it in one place.  The first example uses plain text
substitution and the second example uses a regular expression and
python variable substitution.

Put the following text into a file named ``sample.ts``

 ::

    .sub("$NAME", "ts.py")
    The $NAME script is used to perform text substitutions in 
    text files.  $NAME is a python script.

When you run the command ``python ts.py sample.ts``, the following
text will be output to your screen

 ::

    The ts.py script is used to perform text substitutions in 
    text files.  ts.py is a python script.

The principle feature is that ``$NAME`` is replaced with $name wherever
it occurs in the text file.  Despite the fact that ``$NAME`` looks like
e.g. a scripting language variable, **it is interpreted purely as a text
string**.  $name knows nothing about tokens or symbols in some particular
programming language -- *it is just a dumb text substitution tool*.
You'll find through experience that you'll want to name your
substitutions with string names that will be found **only** where you
intend them to be.  For example, if instead of ``$NAME`` we used
``ext``, then the substitutions would also have occurred in the words
``text``, probably not what you wanted (try it and see).

.(
    # Let us use $name verbatim without substitution.  This works
    # because the formatting of variables happens after the
    # substitution phase is finished and substitution isn't done
    # within code blocks.
    name = "$name"
    Name = "``$name``"
.)

The second example is similar to the first:

 ::

    .(
        lang = "python"
    .)
    .sub(r"\$NAME", "ts.py", re=re.I)
    The $NAME script is used to perform text substitutions in 
    text files.  {name} is a {{lang}} script.

This time, the ``re`` option is set to something different from ``None``
(the ``re`` keyword contains (integer) flags for python's ``re.compile``
function).  This instructs $name to compile the substitution as a
regular expression.  The ``re.I`` flag makes the regular expression
case-independent.  This results in identical output to the previous
example because both ``$NAME`` and {Name} have substitutions made on
them.  The ``r`` in front of the quoted string turns it into a 'raw
string', which makes it a bit easier to work with regular expressions
and backslashes (look up 'raw string' in python's documentation).

The code block (surrounded by ``.(`` and ``.)``) defines a python
variable named ``lang``.  This causes ``{{lang}}`` to be changed to
``python``.  Thus, you have two distinct ways of causing text
substitution in using the $name script.  Use double curly braces to
avoid the variable substitution.

    **Aside**:  since $name is used to produce this document, you
    might wonder how {Name} can be used in the text file without it
    being expanded to the script's name $name.  Read the relevant text
    in the ``ts.ts`` file.

The ``sub()`` function has a ``cont`` keyword argument that, if
``True``, lets the text processing continue in spite of an error.  You
can test this out by putting ``cont=1`` in the above function call and
putting double quote characters around ``re.I``.  This will cause a
``re.compile`` error, but text processing will continue.  You won't,
however, see the ``$NAME`` and {Name} strings changed to the name of the
script.

    However, a bad substitution line can cause an exception that can't
    be handled and $name will exit.  For example, a line such as
    ``.sub("a", "a", cont=True) x`` will result in a syntax error
    because of the spurious ``x`` when python tries to evaluate the
    line.  The script will exit with an error message about
    ``unsupported operand type(s)``.

Command syntax
{level1}

In the following, b means Boolean and i means integer.

Command:  .sub(src, dest, \*\*kw)
{level2}

Define a substitution; keywords are (default values in square
brackets)

 ::

    ignore      b   If True, ignore this command. [False]
    re          i   If not None, src is a regular expression.  [None]
    cont        b   Continue execution on a command failure. [False]
    count       i   Number of substitutions to make. [None]

Substitutions are plain text unless the ``re`` keyword is not the
default ``None``, in which case they are interpreted as python regular
expressions.  ``re`` is used as the flags argument to
``re.compile()``.  For example, if you set ``re=re.I``, the regular
expression would be case-independent.  You'll get an ``re.compile``
exception if the ``re`` keyword isn't an integer recognized by the
``re.compile`` function unless ``cont`` is True.

``ignore`` can be used to turn off a bunch of substitutions.  You
could, for example, define a variable ``chapter2`` in a python
code block.  Then you'd set a number of substitution's ``ignore``
keyword to be ``ignore=chapter2``.  If ``bool(chapter2)`` was
``True``, then that substitution would be ignored.

``cont`` is used to not stop processing on e.g. a regular
expression compilation failure.  The substitution with the error
won't work, but you'll still get some output from other
substitutions.

``count`` specifies how many matches on the line should be
replaced.  For example, if you only wanted the first occurrence of
the regular expression on the line replaced, set ``count`` to 1.
``count`` works with both plain text and regular expression
substitutions.  A value of ``None`` means to replace all matches.

Example:

 ::
    
    sub('x([^x]*)x', r'zz \1', re=re.I)

will be a substitution that uses a regular expression to change
strings with any non-x characters between ``x`` characters into
``zz`` followed by what was in between the ``x``'s.  Note the use
of the raw string and the back-reference in the second argument.
Some example transformations are:

 ::

    Input                       Output
    --------------------        ----------------------
    XXxxabcXXXxxx               zz abc
    x This is a stringx         zz This is a string
    xThis is X a stringx        zz This is zz  a string

For the last substitution, if you only wanted the first match
changed, you could include a ``count`` keyword of 1:

 ::

    sub('x([^x]*)x', r'zz \1', re=re.I, count=1)

which would result in the output ``zz This is  a stringx``.

Command:  .out(expr, \*\*kw)
{level2}

Turns the output stream on or off depending on the Boolean value
of the expression ``expr``.  The only keyword is ``ignore`` (a
Boolean), which, if ``True``, ignores the command.  

Command:  .inc(file, \*\*kw)
{level2}

This command includes a file's contents at the current position.
The file name is searched for in the set of directories defined by
the $ts_path environment variable (works like ``PATH``) and any
``-I`` options given on the command line. 

 ::

    ignore   b   If True, ignore this command [False]
    times    i   Number of times allowed for inc (0 means no limit) [0]
    cont     b   Continue execution on a command failure [False]

``times`` is used to control how many times an include file can be
loaded by the script.  Set ``times`` to 1 to only allow a file to
be loaded once; this will give you an error later if you try to
include the file again.

Set ``cont`` to ``True`` to not have execution stop if an include
file can't be found or read.

Command:  .( and .):  Code block
{level2}

 ::

    .(   Begin code block
       ... Put python code here ...
    .)   End code block

Python code can be indented in the code block; common whitespace
on non-empty lines will be removed before execution.  A code block
is executed after the line ending the code block is encountered.

Command:  .[ and .]:  Comments
{level2}

You can put free-form text into a comment block

 ::

    .[   Begin comment block
       Free-form text here
    .]   End comment block

All text in the comment block is ignored, including any text
with syntax relevant to $name.  This provides an easy mechanism to
comment out large chunks of a text file.

A comment line is a single ignored line

 ::

    .#   Comment line

Command:  .< and .> Formatting block
{level2}

A formatting block is used to change the wrapping or column
behavior of a chunk of text.  This is useful when substitutions
mess up the original wrapping of the text.  The block's syntax
is

 ::

    .<X(...)   # Begin formatting block
    .>   End formatting block

where ``X()`` is one of the allowed functions described below (or
the special syntax of shelling out).  Formatting blocks cannot be
nested.  A formatting block is formatted after all text and
variable substitutions are finished (it's the last step of $name's
actions).

The intended use case is to provide word-wrapping for text that
has been modified by substitutions and no longer fits nicely on
the screen.

The formatting that is done is controlled by the function call
``X()`` on the first line.  The allowed functions are

 ::

    columns()
    indent()
    wrap()

If the formatting block is encountered with no function call, the
program will not modify the block's text.  This behavior is easy to
change in the ``FormatBlock()`` function (change the ``allow_blank``)
boolean to False to cause an error to be generated).

wrap()
{level3}

Here's an example demonstrating the ``wrap()`` function (default
values in square brackets)

 ::

    .< wrap(w=-5, ii="* ", si="  ", et=True, dedent=True)
        This is the 
        first sentence.
        
        This is 
        the second
        sentence.

        This is the third sentence.
    .>

``w``  Width [``None``].  Lines will have lengths <= width except
for single words that have a length longer than ``w``.  If ``w``
is negative, it means a width of ``(COLUMNS + w)`` [2]_.  If ``w``
is ``None`` (default value), it means width is ``COLUMNS - 5`` or
``79`` if ``COLUMNS`` isn't defined.  If ``w`` is 0, it means no
wrapping.

``ii``  Initial indent string for each nonblank line [``""``].  A
nonblank line ``s`` is one that ``s.strip()`` is not the empty
string.

``si``  Subsequent indent.  [``""``]

``et``  Expand tab characters.  [``False``]

``dedent``  If True, common whitespace is removed from lines.
[``False``]

The example given will result in a bullet list with '*' characters

 ::

    * This is the first sentence.

    * This is the second sentence.

    * This is the third sentence.

indent()
{level3}

``indent()`` lets you add or subtract space characters to the
indentation of each line.  Keywords are

``spaces`` Number of spaces to add or subtract. [0]

``dedent`` If True, the lines have any common whitespace removed
before processing.

Shelling out
{level3}

Using ``!``, you can send a formatting block's text to a shell
pipeline; the block's text becomes the pipeline's stdin.  For
example 

 ::

    .<! nl 
    First line
    Second line
    .>

will cause the lines to be numbered by ``nl``, the UNIX line-numbering
utility.  The result will be 

 ::

    1 First line
    2 Second line

(The output will have a third blank line, but the restructured
text format doesn't show it.)

Usage statement
{level2}

You can get a usage statement from the script by running the script with
no input on the command line.  

``-b`` lets you deal with situations where the default ``.sub()``
syntax won't work because of another tool you're using.

``-I`` lets you define where include files are; note you can modify
the list ``d["-I"]`` in code blocks should you wish.

``-i`` defines include files that are inserted before any of the files
on the command line are read.

``-r`` relaxes the strictness.  By default, the $name script doesn't
allow two things to happen:  substitution redefinitions and one plain
text substitution being a substring of another.  This is done because
these are likely to be inadvertent mistakes and they can take a bit of
time to track down in complicated text with lots of substitutions.  If
you know you need to do such things, you can relax the strictness.

``-v`` summarizes the processing done by the script so a user can see
how the input text gets transformed to the output text.  It will
colorize the output using ANSI escape codes.

The script's global variable ``stream`` contains the stream where all
output is sent; it defaults to ``sys.stdout``.

Before and after output
{level2}

Sometimes you want text output before any of the input files' lines
are processed; conversely, you may want to output some information
after all the input files' lines have been processed.  

To cause output before the input files' lines are processed, use
``print`` statements in a code block.

To cause output after the input files' lines are processed, use code
blocks to append strings to the list of strings ``d["post"]``.  These
lines will be set to the output stream after the input lines are
processed.  

Note that there are no substitutions applied to text produced by
either method.

Modifying the script
{level1}

Architecture
{level2}

    The script works by reading in all the text in the include files
    and files given on the command line.  This lets multiple passes be
    made through the file (see `Processing algorithm`_ for details on
    these passes).  This can be inefficient and space-constrained for
    large text files, but works well for the typical source code files
    that I work with.

Overall design
{level2}

    The script is a relatively simple chunk of code.  The basic object
    in the design is a ``Line`` object, which contains the input text
    files' lines, the name of the text file, and the line number it
    came from (this information is captured to make it easier for
    users to pinpoint the source of a problem).  

    The ``Sub`` object is a ``Line`` object that encapsulates the
    information for a substitution.  If a ``Sub`` object is called on
    a string, the ``Sub``'s transformation is applied to the string
    and the transformed value is returned.  An ``Inc`` object is
    similarly used to encapsulate the characteristics of an include
    line.

    The advantage of using python's syntax for the function calls in
    $name's command lines is that the responsibility of the parsing
    for the function call can be delegated to python.  This makes
    coding almost trivial -- you can see what little code it takes to
    implement this in the ``GetParameters`` object and ``Sub``'s
    constructor.  This method is obvious in hindsight, but it took
    wrting a number of different versions of this and similar programs
    over the years for me to have this insight.  It's really just the
    principle of code reuse.  A maintenance advantage is that it makes
    it easier to hack the script to change its behavior.

    The ``d`` variable is a dictionary that holds the command line
    options and various containers of the program's data.

    Adding the ``-v`` command line verbosity option required a bit of
    work.  However, it's valuable in watching how input text gets
    changed and what the script is "thinking".  The color output adds
    significantly to the interpretation of the output, so if you're on
    a computer whose console doesn't recognize ANSI escape codes, it
    could be worth getting a console that can.  For example, on
    Windows computers, you can install the `colorama
    <https://pypi.python.org/pypi/colorama>`_ module and have it
    replace the ANSI escape sequences with Windows console function
    calls.

    The script's processing is essentially a straightforward
    declarative structure that you can see in ``main()``.  Most of the
    work is done in the ``ProcessLines()`` function. 

Processing algorithm
{level2}

Here's how the $name script works:

- The $ts_path variable is read from the environment and parsed into a
  list of directories [3]_.  These directories are searched for include
  files when an include file can't be found; any ``-I`` options on the
  command line add to this list of directories.
- The command line arguments are processed.
- The lines from the files on the command line are read in.  These lines
  will be in the order they are encountered during processing.
- Any ``.inc()`` include commands in the lines are processed and their
  lines are inserted into the text.  This is a recursive process and can
  handle complicated inclusions.
- The container (possibly nested from the recursive includes) of all the
  Line objects is flattened to be a plain list of Line objects so it can
  be iterated over in the order the lines were encountered.
- Each line is processed:

    * Substitutions are put into a substitutions array.
    * Check for redefined substitutions.
    * Comment block lines are ignored.
    * Output on/off lines are processed.
    * Code block lines are collected and executed when the end of
      the code block is encountered.
    * Plain lines have each substitution applied to them (in
      definition order) until the line's text doesn't change.
      When the line's text changes, the process starts over at the
      first substitution again.
    * Formatting blocks are ignored at this step.

- Ensure there are no plain text substitutions that contain another
  plain text substitution as a substring.
- Make sure we're not still in a code block (i.e., the end of the last
  code block section was encountered).
- Expand string variables using python's ``str.format()`` facilities
  (i.e., a symbol name surrounded by curly brackets).  A symbol name
  that isn't defined will stop the processing unless the ``-e`` option
  was used.
- Format any formatting blocks.
- Send the resulting string to the output stream.

Footnotes and references
{level1}

.. [#] I could critique the $name script in the same way, as its
    features and manpage kept growing during development.  However, I
    tried to add only those things that supported the key things I
    wanted:  1) text substitution, 2) in-line python code to calculate
    things, and 3) formatting to help with text that gets "messed up"
    with substitutions.

.. [#] ``COLUMNS`` is an environment variable that, if defined,
    indicates the number of columns on the current console screen.

.. [#] If you're on a system that doesn't use the ``:`` character to
    delimit path strings (e.g., Windows), you'll have to modify the
    code in the ``ParseCommandLine()`` function.

.. [hu] http://code.google.com/p/hobbyutil
