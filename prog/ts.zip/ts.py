'''
TODO

* I don't really like the -m option's manpage output.  I think the
  manpage should be made from the ts.ts script; it can be converted to
  both HTML form and OO form.  My preference would be to use the
  makefile to have the OO document constructed; then it would be saved
  as a PDF and the PDF would be the primary documentation.  This would
  require saving an OO file as the style document.

  Instead of demonstrating the features in the ts.py's internal
  manpage, construct some example files to include in the project's
  directory.

* Look at the texttable.py module and see if its functionality could
  be shoe-horned into a table() formatting function in the current
  script.

----------------------------------------------------------------------
Text substitution script.  Use -h option for a brief usage statement.
Use the -m option to have the manpage sent to stdout.
'''
# Copyright (C) 2014 Don Peterson
# Contact:  gmail.com@someonesdad1
 
#
# Licensed under the Open Software License version 3.0.
# See http://opensource.org/licenses/OSL-3.0.
#
 

from __future__ import division, print_function
import getopt
import os
import re
import subprocess
import sys
import textwrap
from collections import OrderedDict
from itertools import combinations
from math import log10, ceil
from pdb import set_trace as xx

py3 = True if sys.version_info[0] > 2 else False

if py3:
    from io import StringIO
else:
    from StringIO import StringIO

try:
    import debug
    if 0:
        debug.SetDebugger() # Start debugger on unhandled exception
except ImportError:
    pass

# The following imports the color.py module if it's available.  It's
# available at http://code.google.com/p/hobbyutil if you don't have
# it -- and I strongly recommend you use it, as it makes it much
# easier to read the -v output.
try:
    import color as c
except ImportError:
    # Make a dummy object that will swallow calls to the color module
    class C: 
        def __setattr__(self, attr, x): pass
        def __getattr__(self, attr): return None
        def fg(self, *p): pass
        def normal(self): pass
    c = C()

nl = "\n"
ws_only = re.compile(r"^\s*$")  # Finds lines with only whitespace

# The following will be the screen width to wrap to.  It is set from
# the COLUMNS environment variable; if COLUMNS is not present, it is
# set to 79.  If the -w command line option is used, its setting
# overrides the environment's setting.
columns = None

# Colors for -v option
color_types = {
    "normal"      : (c.white, c.black),
    "verbose"     : (c.lblue, c.black),
    "inc"         : (c.lmagenta, c.black),
    "sub"         : (c.yellow, c.black),
    "old"         : (c.blue, c.black),
    "new"         : (c.lwhite, c.black),
    "code"        : (c.blue, c.black),
    "missing"     : (c.red, c.black),
    "locals"      : (c.cyan, c.black),
    "globals"     : (c.brown, c.black),
    "formatting"  : (c.lcyan, c.black),
    "substring"   : (c.lred, c.black),
    "redef"       : (c.red, c.black),
    "phase"       : (c.green, c.black),
}

# Set this variable to define where all output will go.
stream = sys.stdout

# The following string defines the beginning of a command line 
cmd_line_begin = "."

#----------------------------------------------------------------------
# Use the -m option to send the following manpage to stdout.

manpage = '''
.(
    # This manpage is formatted with the script, so it serves as an
    # example of some of the script's features.
    inc = 4
    sp = " "

    # Default style for wrapping
    wrap.style = {
        "ii" : sp*inc,
        "si" : sp*inc,
        "dedent" : True,
    }

    # Style for indentation after a "normal" paragraph
    norm_ii = sp*(2*inc)
    indent1_1 = {
        "ii" : norm_ii,
        "si" : norm_ii,
        "dedent" : True,
        "rb" : False,
    }

    # Style for next-level indentation 
    norm_ii = sp*(3*inc)
    indent1_2 = {
        "ii" : norm_ii,
        "si" : norm_ii,
        "dedent" : True,
        "rb" : False,
    }

    # Style for keyword lines
    norm_ii = sp*(2*inc)
    kw1 = {
        "ii" : norm_ii,
        "si" : norm_ii,
        "dedent" : True,
        "rb" : True,
    }


    # Styles for bullet lists
    bullet1 = {
        "ii" : sp*(2*inc) + "* ",
        "si" : sp*(2*inc + 2),
        "dedent" : True,
        "rb" : True,
    }
    bullet2 = {
        "ii" : sp*(3*inc) + "- ",
        "si" : sp*(3*inc + 2),
        "dedent" : True,
        "rb" : True,
    }
.)
.sub("$name", "{name}")
NAME
.<wrap()
    $name - text indenter
.>

SYNOPSIS
.<wrap()
    $name [options] [file1 [file2...]]
.>

DESCRIPTION
.<wrap()
    $name is a python script to perform text substitutions.  Input is
    gotten from the indicated text files or stdin if no files are
    given.

    Features:
.>
.<wrap(**bullet1)
    Simple syntax for simple tasks.

    Uses python for command parsing.

    Python code can be embedded in the text.

    Substitutions are either simple text or regular expressions;
    you can also use backreferences.

    Can include other files.

    Substitutions are applied in the order they're found.

    Substitutions are applied to each line until no more changes occur.

    Easy to comment out material in the input files.

    Formatting blocks can be used to wrap, indent, number, etc.

    New formatting features are easy to add.

    ts.py is also a python module; use the text substitution
    facilities in your own python scripts.

    Verbose mode (-v) helps you see how text is changed.

    No installation -- just use the ts.py script.
.>

.<wrap()
    This script is not a 'macro processor'.  It knows nothing about
    tokens or symbols in some programming language -- it's a dumb text
    substitution tool.

    Syntax overview:
.>

.<wrap(rb=True, ii=sp*4)
        .sub(in, out)   Substitute 'out' strings for 'in' strings

        .out(expr)      Turn output on/off based on bool(expr)

        .inc(file)      Include the text from a file

        .( and .)       Code block for arbitrary python code

        .[ and .]       Comment out a block of text

        .< and .>       Formatting block (wrapping, columns, etc.)

        {{name}}          Python variable substitution (str.format())
.>

.<wrap()
    In complicated situations it may be difficult to understand why
    you're not getting what you expect.  Use the -v option to cause
    colored text to be printed that describes the processing steps.
    The colorized output requires a console that interprets ANSI
    escape sequences.

    You can also use the text substitution facilities in your own
    python scripts by loading ts.py as a module.  Create a list of
    Line objects lines containing the text (e.g., use the helper
    function ReadFile()), create an options dictionary d (use the
    GetDefaultOptions() function to put its default values in place),
    and call Transform(lines, d).  The processed string will be
    returned.
.>

OPTIONS
.<wrap(rb=True, ii=sp*4)
    -b s    Command lines begin with this string. [.]

    -e      Ignore str.format() errors.  [False]

    -h      Print a help message.

    -I dir  Define an include directory (multiples allowed).

    -i f    Include file f (multiples allowed)

    -m      Print manpage to stdout

    -r      Relax strictness:  allow redefs & sub substrings

    -v      Show processing details 
.>

.<wrap()
    For -I, TS_PATH is used first and any -I options are appended.
.>

COMMANDS
.<wrap()
    In the following, b means a Boolean, i means an integer, and s
    means a string.  The '.' of the command must appear in the first
    column of the text.

    .sub(src, dest, **kw)
.>
.<wrap(**indent1_1)
        Substitution facilities.  Every occurrence of the source
        string src is replaced with the destination string dest.
        Keywords:
.>

.<wrap(**kw1)
        cont    b   Continue execution on command failure. [False]

        re      i   Flags for regexp compilation. [None]

        ignore  b   If True, ignore this command. [False]
.>

.<wrap(**indent1_1)
        If re is None, then the function is a plain text substitution.
        If it's an integer, it's a flag for the re.compile() function
        and the substitution is a regular expression.

        A plain text substitution can't fail, but a regular expression
        compilation can.
.>

.<wrap()
    .inc(textfile)
.>
.<wrap(**indent1_1)
        Include the text of the file textfile at the current position.
        The file name is searched for in the set of directories
        defined by the TS_PATH environment variable (works like PATH)
        and any -I options on the command line.  Keywords:
.>

.<wrap(**kw1)
        cont    b   Continue execution if include fails. [False]

        count   i   Number of inclusions of this file to allow. [None]

        ignore  b   If True, ignore this command. [False]
.>

.<wrap(**indent1_1)
        If count is None, any number of inclusions is allowed.
.>

.<wrap()
    .out(expr)
.>
.<wrap(**indent1_1)
        Turns output on if expr evaluates to True; turns output off if
        expr evaluates to False.  expr must be a valid python
        expression.  Keyword:
.>

.<wrap(**kw1)
        ignore  b   If True, ignore this command. [False]
.>

CODE BLOCKS
.<wrap()
    Python code can be included in blocks delimited by the symbols
    '.(' and '.)'.  The code in these blocks is evaluated after the 
    block-closing symbol '.)' is encountered.  The code block's lines
    may have a common indent for readability; this indent is removed
    before processing.

    Variables defined in the block are put into a dictionary that
    holds local variables (it's d["locals"] in the script).  These are
    available to all subsequent commands and code blocks.
.>

COMMENT BLOCKS
.<wrap()
    Text between the symbols '.[' and '.]' is ignored and results in
    no output.

    A single line beginning with '.#' is a comment and is also
    ignored.
.>

FORMATTING BLOCKS
.<wrap()
    Text between the symbols '.<' and '.>' can be formatted with some
    built-in tools or external programs by 'shelling out'.  Formatting
    blocks can be nested.  The syntax is 
.>

.<indent(width=6, dedent=True)
        .<X(**kw)
        Block's text
        .>
.>

.<wrap()
    A formatting block with no function call is wrapped to a width 5
    spaces less than the console's width with any leading spaces
    removed.  You can change this behavior in the FormatBlock()
    function.

    Note that the formatting functions recognize the ignore keyword,
    which allows programmatically commenting out functionality.  When
    a formatting block is used with a function with the ignore keyword
    set to True, the formatting block's output is equivalent to the
    identity transformation.

    The allowed functions X and their keywords are:

    indent():  Increase or decrease block's indenting
.>

.<wrap(**kw1)
        indent  i   Indent more if positive, less if negative. [0]

        ignore  b   Ignore if True. [False]

        dedent  b   Remove any common indent first if True. [False]
.>

.<wrap(**indent1_1)
      indent designates the number of spaces to increase or decrease
      the indenting.  If negative, the indenting is decreased and
      there must be a suitable number of space characters on each line
      not composed of only space characters (lines with spaces will be
      empty after formatting).
.>

.<wrap()
    number():  Number a block's lines
.>
.<wrap(**kw1)
        fmt     s   String to use for formatting numbers [None]

        gap     s   String between number and text [" "]

        ib      b   Ignore lines with only whitespace [False]

        ignore  b   Ignore if True. [False]

        inc     i   Increment for numbers [1]

        indent  s   String to indent each line [""]

        start   i   Starting value for numbering [1]

        term    s   String that terminates number [""]
.>

.<wrap(**indent1_1)
      By setting fmt to e.g. "%3.1f", setting start to 1.0, and inc to
      0.1, you can number by increasing decimal numbers.
.>

.<wrap()
    wrap():  Wrap words to fit a given width
.>
.<wrap(**kw1)
        dedent  b   If True, remove any common indentation. [False]

        et      b   Expand tabs if True. [False]

        ignore  b   Ignore this command if True. [False]

        ii      s   Initial indent string for the paragraph. [""]

        rb      b   Remove blank lines. [False]

        si      s   Subsequent indent string for each line. [""]

        width   i   Width to wrap to. [-1]
.>

.<wrap(**indent1_1)
        A negative width means to add the indent to the 'columns'
        global variable to get the width to wrap to.
.>

.<wrap()
    It is straightforward to add new formatting functions.  Copy the
    signature of (for example) the wrap function.  The function will
    take in a variable 'block' (a list of strings) and should return a
    string representing the processed form of those strings.  
.>

STYLES
.<wrap()
    You can use style dictionaries to define the formatting keywords
    you'd like to use and use them repeatedly.  This saves you from
    mucking with the keyword arguments for each formatting function
    call.  To do this, define a dictionary in a code block and
    populate it with the keywords you wish to use.  Then call the
    formatting function with that dictionary as the keyword
    dictionary.  Example:  suppose your style dictionary is named
    'style'.  Use it in the wrap() formatting function by the syntax
    wrap(**style).  Look at the text in the $name's manpage variable
    to see a practical example.

    Another formatting convenience is that the formatting functions
    support the style attribute.  This lets you define a style
    dictionary in a code block and set the formatting function's style
    attribute to that dictionary.  This dictionary then provides the
    default keyword arguments for the formatting function.  However,
    those values can be overridden by the keywords given in the
    function call.

    Example:  Suppose you want the wrap function's width to default to
    -5, which means 5 spaces less than the current COLUMNS environment
    variable's value (or 80 - 5 if COLUMNS isn't defined).  The
    following code would accomplish this:
.>

.<indent(width=4, dedent=True)
    .(
        style = {{"width" : -5,}}
        wrap.style = style
    .)
.>

.<wrap()
    Later, all your formatting blocks that need wrapping can just call
    wrap() and get this default behavior.  You can then e.g. use
    "stylesheets" include files to define the styles you wish to use
    and invoke them via the -i command line option.
.>

SHELLING OUT
.<wrap()
    The text in a format block can be sent to a shell pipeline by the
    following syntax:
.>

.<indent(width=4, dedent=True)
        .<! cmd
        Format block's text
        .>
.>

.<wrap()
    where cmd is one or more programs connected by pipe ('|') symbols.
    The block's text is sent to the cmd command's stdin and the block
    is replaced by the command's stdout.  If the command's stderr
    returns 1 or more characters, the command is declared failed, 
    the stderr message is displayed, and the script exits.
.>

PROCESSING ALGORITHM
.<wrap()
    Here's how the ts.py script processes its input text:
.>

.<wrap(**bullet1)
    The TS_PATH variable is read from the environment and parsed
    into a list of directories.  These directories are searched for
    include files when an include file can't be found; any -I
    options on the command line add to this list of directories.

    The command line arguments are processed.

    The lines from the text files on the command line are read in.
    These lines will be in the order they are encountered during
    processing and are converted to Line objects.

    Any .inc() include commands in the lines are recursively
    processed and their lines are inserted into the text.

    The container (possibly nested) of all the Line objects is
    flattened.

    Each line is processed:
.>

.<wrap(**bullet2)
    Substitutions are put into a substitutions array.

    Check for redefined substitutions.

    Comment block lines are ignored.

    Output on/off lines are processed.

    Code block lines are collected and executed when the end of
    the code block is encountered.

    Plain lines have each substitution applied to them (in
    definition order) until the line's text doesn't change.
    When the line's text changes, the process starts over at the
    first substitution again.

    Formatting blocks are ignored at this step.
.>

.<wrap(**bullet1)
    Ensure there are no plain text substitutions that contain
    another plain text substitution as a substring.

    Make sure we're not still in a code block (i.e., the end of the
    last code block section was encountered).

    Expand string variables using python's formatting sequence
    (i.e., a symbol name surrounded by curly brackets).  A symbol
    name that isn't defined will stop the processing unless the
    -e option was used.

    Format any format blocks.

    Send the resulting string to the output stream.
.>
.(
    indent2_1 = {"indent" : inc*1, "dedent" : True}
    indent2_2 = {"indent" : inc*2, "dedent" : True}
    indent2_3 = {"indent" : inc*3, "dedent" : True}
.)

EXAMPLES
.<indent(**indent2_1)
    Simple text substitution:
.>
.<indent(**indent2_2)
        Input text lines:
.>
.<indent(**indent2_3)
            .sub("$NAME", "ts.py")
            The $NAME script is used to perform text substitutions 
            in text files.  $NAME is a python script.
.>
.<indent(**indent2_2)
        Output text:
.>
.<indent(**indent2_3)
            The ts.py script is used to perform text substitutions
            in text files.  $name is a python script.
.>

.<indent(**indent2_1)
    Using a regular expression for case-independence:
.>
.<indent(**indent2_2)
        Input text lines:
.>
.<indent(**indent2_3)
            .sub(r"\$NAME", "ts.py", re=re.I)
            The $NAME script is used to perform text substitutions
            in text files.  $name is a python script.
.>
.<indent(**indent2_2)
        Note the use of the raw string and the escape, as '$' is a
        magic character for regular expressions.  The output text will 
        be the same as the previous example.
.>

.<indent(**indent2_1)
    Embedded python code (uses python's str.format() string syntax):
.>
.<indent(**indent2_2)
        Input text lines:
.>
.<indent(**indent2_3)
            .(
                # This is a python code block.  You can indent it for
                # readability.  Compute pi/4 to 3 decimal places.
                from math import pi
                value = "%.3f" % (pi/4)
            .)
            {{value}}
.>
.<indent(**indent2_2)
        Output text lines:
.>
.<indent(**indent2_3)
            0.785
.>
    
.<indent(**indent2_1)
    Formatting block:
.>
.<indent(**indent2_2)
        Input text lines:
.>
.<indent(**indent2_3)
            .<wrap(width=30)
            It is a truth universally acknowledged, that a single man in 
            possession of a good fortune, must be in want of a wife.  
            .>
.>
.<indent(**indent2_2)
        Output text lines:
.>
.<indent(**indent2_3)
            It is a truth universally
            acknowledged, that a single
            man in possession of a good
            fortune, must be in want of a
            wife.
.>

.<indent(**indent2_1)
    Read in the text of the book 'Pride and Prejudice' (in the file
    'pnp', not included), wrap to near screen width, then number the 
    non-blank lines:
.>
.<indent(**indent2_2)
        Input text lines:
.>
.<indent(**indent2_3)
            .(
                book = open("pnp").read()
            .)
            .< number(ib=True)
            .< wrap(width=-30)
            {{book}}
            .>
            .>
.>
.<indent(**indent2_2)
        Output text lines (depends on console width):
.>
.<indent(**indent2_3)
           1 PRIDE AND PREJUDICE

           2 By Jane Austen

           3 Chapter 1

           4 It is a truth universally acknowledged, that a
           5 single man in possession of a good fortune, must
           6 be in want of a wife.
            ... etc. ...
.>

.<indent(**indent2_1)
    Demonstrate a shell pipeline:  use the 'tac' command to reverse
    the order of the previous example's lines:
.>
.<indent(**indent2_2)
        Input text lines:
.>
.<indent(**indent2_3)
            .(
                book = open("pnp").read()
            .)
            .<! tac
            .< number(ib=True)
            .< wrap(width=-30)
            {{book}}
            .>
            .>
            .>
.>
.<indent(**indent2_2)
        Output text lines:
.>
.<indent(**indent2_3)
            ... etc. ...
           6 be in want of a wife.
           5 single man in possession of a good fortune, must
           4 It is a truth universally acknowledged, that a

           3 Chapter 1

           2 By Jane Austen

           1 PRIDE AND PREJUDICE
.>
'''[1:-1]

#----------------------------------------------------------------------
class TSException(Exception): pass
class SubException(TSException): pass
class IncException(TSException): pass
class SubSubException(TSException): pass

class Line(object):
    '''A Line object contains a line from a source file.  The
    string, name of the source file, and the line number are stored.
    '''
    def __init__(self, string, srcfile, linenum):
        self.s = string
        self.f = os.path.relpath(srcfile)
        self.n = linenum
    def __str__(self):
        return "%s: '%s'" % (self.fn, self.s)
    @property
    def info(self):
        return (self.s, self.f, self.n)
    @property
    def fn(self):
        return "%s[%d]" % (self.f, self.n)

class GetParameters(object):
    '''Helper class to get the parameters and keywords of a command
    line.  Pass it the command line string with the leading command
    identifier stripped off.  Any exception that occurs means the
    command line wasn't of proper form.  The parameters will be in
    self.vars and keywords in self.kw.
    '''
    def __init__(self, string, **kw):
        kw["self"] = self
        exec("self._func%s" % string[string.find("("):], globals(), kw)
    def _func(self, *p, **kw):
        self.vars = p
        self.kw = kw

class Sub(Line):
    '''Encapsulate the characteristics of a substitution.  The
    substitution is made on a string by calling the Sub object as a
    function.
    '''
    def __init__(self, string, srcfile, linenum):
        '''We expect that the leading part of the line's string has
        been removed so that the line begins with 'sub('.
        '''
        if string[:4] != "sub(":
            raise SubException("Sub:  expected sub() call")
        super(Sub, self).__init__(string, srcfile, linenum)
        try:
            gp = GetParameters(string)
            self.vars = gp.vars
            self.kw = gp.kw
        except Exception as e:
            msg = ["Improperly formed sub command on line %s:" % self.fn]
            msg += ["  %s" % string]
            msg += ["  Error = %s" % e]
            msg = nl.join(msg)
            raise SubException(msg)
        # Get our attributes
        if len(self.vars) != 2:
            raise SubException("Substitution requires src & dest parameters")
        # Source and destination strings
        self.src, self.dest = self.vars
        # Keywords
        self.cont   = self.kw.get("cont", False)
        self.ignore = self.kw.get("ignore", False)
        self.re     = self.kw.get("re", None)
        # Compile re if present
        self.regexp = None
        try:
            self.regexp = (None if self.re is None else
                           re.compile(self.src, self.re))
        except Exception as e:
            msg = ["Couldn't compile regexp '%s'" % self.src]
            msg += ["  Source line %s" % self]
            msg += ["  Error:  %s" % e]
            msg = nl.join(msg)
            if not self.cont:
                raise SubException(msg)
    def __cmp__(self, other):
        '''Used to sort plain string Sub objects in a container.  The
        longer strings will sort to the beginning of the container,
        meaning they get applied first.
        '''
        if self.regexp is not None or other.regexp is not None:
            raise SubException("Can't compare re-type Sub objects")
        if len(self.src) < len(other.src):
            return 1
        elif len(self.src) > len(other.src):
            return -1
        return 0
    def __call__(self, string):
        '''Apply our substitution to the string and return the
        transformed string.
        '''
        if self.regexp is None:
            return string.replace(self.src, self.dest)
        else:
            return self.regexp.sub(self.dest, string)

class Inc(Line):
    '''Encapsulate the characteristics of an include line.
    '''
    def __init__(self, string, srcfile, linenum, searchpath):
        '''We expect that the leading part of the line's string has
        been removed so that the line begins with 'inc('.  searchpath
        is the contents of the d["-I"] list and contains the
        directories to search for the file if it can't be opened
        directly.
        '''
        if string[:4] != "inc(":
            raise IncException("Inc:  expected inc() call")
        super(Inc, self).__init__(string, srcfile, linenum)
        self.searchpath = searchpath
        self.count = 0  # Number of times included
        try:
            gp = GetParameters(string)
            self.vars = gp.vars
            self.kw = gp.kw
        except RuntimeError:#Exception:
            msg = ["", "  Improperly formed inc line in source:"]
            msg += ["    %s" % self]
            msg = nl.join(msg)
            raise IncException(msg)
        # Get our attributes
        if len(self.vars) != 1:
            raise IncException("Include requires a file name")
        # Source and destination strings
        self.filename = self.vars[0]
        # Keywords
        self.cont   = self.kw.get("cont", False)
        self.times  = self.kw.get("times", 0)
        self.ignore = self.kw.get("ignore", False)
    def __call__(self):
        '''Return a list of the file's Line objects.
        '''
        self.count += 1
        if self.times and self.count > self.times:
            return []
        # Locate the file
        if os.path.isfile(self.filename):
            stream = open(self.filename)
        else:
            stream = None
            for i in self.searchpath:
                f = os.path.join(i, self.filename)
                if os.path.isfile(f):
                    stream = open(f)
                    break
            if not stream:
                msg = "Couldn't find include file '%s'" % self.filename
                raise IncException(msg)
        return ReadFile(self.filename, stream)

#----------------------------------------------------------------------

def Verbose(msg, d, style="verbose", force=False):
    if force or d["-v"]:
        c.fg(color_types[style])
        print(msg, end="", file=stream)
        c.normal()
        print(file=stream)

def Error(msg, status=1):
    c.fg((c.lred, c.black))
    print(msg, end="", file=stream)
    c.normal()
    print(file=stream)
    exit(status)

def Usage(d, status=1):
    name = sys.argv[0]
    dashb = cmd_line_begin
    NL = "'\\n'"
    s = '''
Usage:  {name} [options] [file1 [file2...]]
    Text substitution tool with python features.  Use -@ to take input
    from stdin.  Output is sent to stdout.
Commands (start in first column) (b=bool, i=int, s=string, [default]): 
  .( and .)     Begin and end a python code block
  .[ and .]     Begin and end a comment block
  .< and .>     Begin and end a formatting block
  .#            Comment line           -------- Keyword Arguments --------
  .sub(src, dst) Text substitution.    cont(b), count(i), ignore(b), re(i)
  .inc(file)     Include a file.       cont(b), count(i), ignore(b)
  .out(expr)     Turn output on/off.   ignore(b)
Strings in text:
  {{name}}    Formatted python symbol
  Use python's string formatting syntax after the symbol.  Example:
    {{name!r:^80s}}    repr(name) --> string, center in 80 spaces
Formatting commands & keywords:
  indent()  dedent(b), i(i) (< 0, reduce, > 0, increase), ignore(b)
  number()  fmt(s), gap(s), ib(b), ignore(b), inc(i), indent(s),
            start(i), term(s)
  wrap()    w, ignore, ii, si, et, dedent (w < 0 ==> width = 'columns' + w)
Options:
  -b s    Command lines begin with this string ["{dashb}"]
  -e      Do not stop on formatting errors
  -h      Print this help message.
  -I dir  Define an include directory (multiples allowed)
          TS_PATH is used first and any -I options are appended.
  -i f    Include file f (multiples allowed)
  -m      Print restructured text manpage to stdout
  -r      Relax strictness:  allow redefs & sub substrings
  -v      Show processing details 
  -w w    Set output width to w [COLUMNS] (value in 'columns' global)
'''[1:-1]
    print(s.format(**locals()))
    sys.exit(status)

def GetDefaultOptions(d):
    global columns
    if "COLUMNS" in os.environ:
        columns = max(1, int(os.environ["COLUMNS"]))
    # Program to launch files with registered application
    d["launch"] = "/usr/bin/exo-open"
    d["phase"] = 0      # Tracks processing phase
    d["out"] = True     # Output is on
    d["-@"] = False     # Take input from stdin
    d["-b"] = cmd_line_begin  # String that begins command lines
    d["-e"] = False     # Do not stop on formatting errors
    d["-I"] = []        # Include directories
    d["-i"] = []        # Include files
    d["-l"] = False     # List substitutions found in input
    d["-m"] = False     # Send manpage to stdout
    d["-r"] = False     # Relax strictness
    d["-v"] = False     # Show processing details
    d["-w"] = None      # Width to wrap to
    # Container for substitutions
    d["sub"] = []
    # Container for output 
    d["output_lines"] = []
    # Start off not in an blocks
    d["in_code_block"] = False
    d["in_comment_block"] = False
    # Start off with empty code block
    d["code_block"] = []
    # Container for lines to send to output stream after all
    # substitutions and formatting are done.
    d["post"] = []
    # Get any include directories from TS_PATH
    if "TS_PATH" in os.environ:
        # This needs to be fixed for a Windows environment
        d["-I"] += os.environ["TS_PATH"].split(":")
    # When evaluating expressions and code block lines, we'll utilize
    # the following dictionary for variables in a "local" context.
    # The OrderedDict is use to let you see the relative order they
    # were encountered in the input text.
    d["locals"] = OrderedDict()

def ParseCommandLine(d):
    GetDefaultOptions(d)
    try:
        optlist, files = getopt.getopt(sys.argv[1:], "@b:ehI:i:mo:rs:vw:")
    except getopt.GetoptError as e:
        msg, option = e
        print(msg, file=sys.stderr)
        exit(1)
    for o, a in optlist:
        if o == "-b":
            if not a:
                raise ValueError("-b option must be non-empty string")
            d["-b"] = a
        if o == "-@":
            d["-@"] = True
        elif o == "-e":
            d["-e"] = True
        elif o == "-h":
            Usage(d, status=0)
        elif o == "-I":  
            # Note we don't check to see if directory exists
            d["-I"].append(a)
        elif o == "-i":
            # We'll check for the files' existence later after all
            # possible -I options are found.
            d["-i"].append(a)
        elif o == "-m":
            d["-m"] = True
        elif o == "-r":
            d["-r"] = True
        elif o == "-v":
            d["-v"] = True
        elif o == "-w":
            try:
                d["-w"] = int(a)
                if d["-w"] < 1:
                    raise Exception()
                global columns
                columns = d["-w"]
            except Exception:
                Error("Bad value for -w option")
    if not d["-I"]:
        # If no include directories are given, use the current
        # directory.
        d["-I"].append(os.getcwd())
    if not files:
        Usage(d, 0)
    return files

def Phase(description, d):
    '''In verbose mode, show the processing phase.
    '''
    d["phase"] += 1
    n = 10
    s = "-"*n
    s += " Phase %d:  %s " % (d["phase"], description)
    s += "-"*max(5, columns - len(s))
    Verbose(s, d, style="phase")

def GetInput(srcfile, input_stream, d):
    '''Return a list of the file's lines where each list element is a
    Line object.  d is the options dictionary.
    '''
    lines = []
    s = input_stream.read()
    if s:
        for linenum, line in enumerate(s.split(nl)):
            lines.append(Line(line, srcfile, linenum + 1))
    Verbose("Read %d %s from '%s'" % (len(lines), 
            "line" if len(lines) == 1 else "lines", srcfile, d))
    return lines

def ProcessOut(line, d):
    string, filenum, linenum = line.info
    Verbose("Processing Out %s" % line, d)
    d["out"] = bool(eval(string[4:]))
    state = "on" if d["out"] else "off"
    Verbose("  Boolean was %s; output is %s" % (d["out"], state), d)

def NumberCodeLines(lines):
    '''Return a string that contains numbered code lines suitable for
    printing in an error message.
    '''
    from math import log10, ceil
    out, fmt, width = [], "%*d:  %s", int(ceil(log10(len(lines))))
    for i, line in enumerate(lines):
        out.append(fmt % (width, i + 1, line))
    return nl.join(out)

def ProcessCodeBlock(d):
    '''The end of a code block has been reached, so compile and
    execute the stored lines.
    '''
    # Remove any common leading space characters.
    lines = textwrap.dedent(nl.join([i.s for i in d["code_block"]])).split(nl)
    code, numlines = nl.join(lines), len(lines)
    # Get file and line numbers for error message
    cb_location = d["code_block"][0].fn
    try:
        compiled = compile(code, "<code block w/%d lines>" % numlines, "exec")
    except Exception as e:
        msg = "Code compile error:\n  Error:  '%s'" % e
        msg += "\n  %s:  Code:\n" % cb_location
        msg += NumberCodeLines(code.split(nl))
        Error(msg)
    try:
        globals_copy = globals().copy()
        globals_copy["d"] = d
        exec(compiled, globals_copy, d["locals"])
    except Exception as e:
        msg = "Code execution error:\n  Error:  '%s'" % e
        msg += "\n  %s:  Code\n" % cb_location
        msg += NumberCodeLines(code.split(nl))
        Error(msg)
    Verbose("  Processed OK", d)
    d["code_block"] = []

def GetIncludeFile(filename, d):
    '''Search the directories in d["-I"] for a file with the indicated
    name.  Return it as a path relative to the current directory.
    '''
    for directory in d["-I"]:
        f = os.path.join(directory, filename)
        if os.path.isfile(f):
            return os.path.relpath(f)
    Error("Could not find include file '%s'" % filename)

def ReadFile(filename, fstream):
    '''Read the indicated text file from its stream and return a list 
    of Line objects.
    '''
    lines = []
    for linenum, line in enumerate(fstream.readlines()):
        if line[-1] == nl:  # Remove trailing newline
            line = line[:-1]
        lines.append(Line(line, filename, linenum + 1))
    return lines

def GetInputLines(files, d):
    '''Return a list of Line objects representing the input line of
    the files on the command line. 
    '''
    Phase("get input lines", d)
    lines = []
    # Get the include files that were set with -i option
    for include_filename in d["-i"]:
        filename = GetIncludeFile(include_filename, d)
        newlines = ReadFile(filename, open(filename))
        Verbose("Read %d lines from '%s' (-i file)" % 
                (len(newlines), filename), d)
        lines += newlines
    # Read in command line files or stdin
    if d["-@"]:
        newlines = ReadFile("<stdin>", sys.stdin)
        Verbose("Read %d lines from 'stdin'" % (len(newlines),
                filename), d)
        lines += newlines
    else:
        for filename in files:
            newlines = ReadFile(filename, open(filename))
            Verbose("Read %d lines from '%s'" % (len(newlines),
                    filename), d)
            lines += newlines
    return lines

def Flatten(L):
    ''' Flatten a list L.  Adapted from the routine by Kevin L. Sitze
    on 2010-11-25 http://code.activestate.com/recipes/577470-fast-
    flatten-with-depth-control-and-oversight-over/?in=lang-python.
    This code may be used pursuant to the MIT License.
    '''
    isit, r, s = lambda x: isinstance(x, (list, tuple)), [], [(0, L)]
    while s:
        i, seq = s.pop()
        while i < len(seq):
            while isit(seq[i]):
                if not seq[i]: 
                    break
                else:
                    s.append((i + 1, seq))
                    seq = seq[i]
                    i = 0
            else: 
                r.append(seq[i])
            i += 1
    return r

_r = re.compile(r"'(.*)'")

def GetType(v):
    s = str(type(v))
    m = _r.search(s)
    if not m:
        return s
    return m.groups()[0].replace("__main__.", "")

def DumpVariables(d):
    if not d["-v"]:
        return
    Phase("dump variables", d)
    # Local variables
    if d["locals"]:
        Verbose("Local variables in the order they were defined:", d)
        for k, v in d["locals"].items():
            if isinstance(v, str):
                s = "  %s = '%s'" % (k, v)
            else:
                s = "  %s = <%s> %s" % (k, GetType(v), v)
            Verbose(s, d, style="locals")
    # Global variables (added by user's code)
    orig = set(d["globals"].keys())
    curr = set(globals().copy().keys())
    added = list(sorted(list(curr - orig)))
    if added:
        Verbose("Added global variables:", d)
        for v in added:
            s = "  %s = '%s'" % (v, globals()[v])
            Verbose(s, d, style="globals")

def StripCmdHeader(string, d):
    if string.startswith(d["-b"]):
        return string[len(d["-b"]):].lstrip()
    return string

def IsInc(line, d):
    if not line.s.startswith(d["-b"]):
        return False
    s = StripCmdHeader(line.s, d)
    return s[:4] == "inc("

def IsSub(line, d):
    if not line.s.startswith(d["-b"]):
        return False
    s = StripCmdHeader(line.s, d)
    return s[:4] == "sub("

def IsComment(line, d):
    if not line.s.startswith(d["-b"]):
        return False
    s = StripCmdHeader(line.s, d)
    return s[0] == "#"

def IsOut(line, d):
    if not line.s.startswith(d["-b"]):
        return False
    s = StripCmdHeader(line.s, d)
    return s[:4] == "out("

def IsCodeBlockStart(line, d):
    if not line.s.startswith(d["-b"]):
        return False
    s = StripCmdHeader(line.s, d)
    return s[0] == "("

def IsCodeBlockEnd(line, d):
    if not line.s.startswith(d["-b"]):
        return False
    s = StripCmdHeader(line.s, d)
    return s[0] == ")"

def IsCommentBlockStart(line, d):
    if not line.s.startswith(d["-b"]):
        return False
    s = StripCmdHeader(line.s, d)
    return s[0] == "["

def IsCommentBlockEnd(line, d):
    if not line.s.startswith(d["-b"]):
        return False
    s = StripCmdHeader(line.s, d)
    return s[0] == "]"

def IsFormatBlockStart(line, d):
    # Note line is a plain string
    if not line.startswith(d["-b"]):
        return False
    s = StripCmdHeader(line, d)
    return s[0] == "<"

def IsFormatBlockEnd(line, d):
    # Note line is a plain string
    if not line.startswith(d["-b"]):
        return False
    s = StripCmdHeader(line, d)
    return s[0] == ">"

def CheckNotInCodeBlock(d):
    if d["in_code_block"]:
        msg = ["Error:  code block still open"]
        if d["code_block"]:
            line = d["code_block"][0]
            msg += ["  Code begins at %s" % line.fn]
        Error(nl.join(msg))

def CheckForSubSubstrings(d, test=False):
    '''Look in d["sub"] for plain text substitutions that are
    substrings of another substitution (ignore regular expressions).
    If test is True, raise an exception rather than printing
    anything.
    '''
    if len(d["sub"]) < 2:
        return
    # Build a list of non-regexp substitutions
    s, t, error = [i for i in d["sub"] if i.re == None], "substring", False
    strict, errmsg = not d["-r"], ""
    w = "Error" if strict else "Warning"
    t = "substring" if strict else "redef"
    for sub1, sub2 in combinations(s, 2):
        if (sub1.src in sub2.src) or (sub2.src in sub1.src):
            msg = ["%s:  substitution contained in another):" % w,
                "  sub1 = %s" % sub1,
                "  sub2 = %s" % sub2
            ]
            errmsg += nl.join(msg) + nl
            if not test:
                Verbose(errmsg, d, style=t, force=strict)
            error = True
    if not d["-r"] and error:
        if test:
            raise SubSubException(errmsg)
        exit(1)

def GetIncludeLines(line, d):
    '''line is an include Line object.  Read in its file's line and
    recursively expand any include lines.  Return the resulting list
    of Line objects.
    '''
    string = line.s[len(d["-b"]):].lstrip()
    inc = Inc(string, line.f, line.n, d["-I"])
    lines = inc()
    Verbose("Read %d lines from '%s'" % (len(lines), inc), d)
    return ExpandIncludeLines(lines, d)

def ExpandIncludeLines(lines, d):
    '''Return a list of Line objects with all include directives
    expanded.
    '''
    for i, line in enumerate(lines):
        if IsInc(line, d):
            lines[i] = GetIncludeLines(line, d)
    return lines

def ApplyFormatting(line, string, d):
    '''Apply formatting; if the string is changed, return the changed
    string; otherwise return the unchanged string.
    resulting string.
    '''
    vars = globals().copy()
    vars.update(dict(d["locals"]))
    newstring = string
    try:
        newstring = string.format(**vars)
    except (KeyError, ValueError) as e:
        if d["-e"]:
            Verbose("Variable %s missing in %s:" % (e,
                    line.fn), d, style="missing")
        else:
            msg = ["Variable %s missing:" % e]
            msg += ["  %s" % line]
            Error(nl.join(msg))
    if newstring != string:
        Verbose("Formatting changed string %s:" % line.fn, d,
                style="formatting")
        Verbose("  Old:  '%s'" % string, d)
        Verbose("  New:  '%s'" % newstring, d, style="new")
        changed = True
    return newstring

def ApplySubstitutions(line, string, d):
    '''Apply substitutions until one changes the string; return the
    changed string.
    '''
    for sub in d["sub"]:
        newstring = sub(string)
        if newstring != string:
            Verbose("Substitution %s changed string %s:" %
                    (sub.fn, line.fn), d, style="sub")
            Verbose("  Old:  '%s'" % string, d)
            Verbose("  New:  '%s'" % newstring, d, style="new")
            return newstring
    return string

def CheckForRedefinition(sub, d):
    '''If sub is a plain text substitution, ensure it is not already
    in the list of substitutions.
    '''
    w = "Warning" if d["-r"] else "Error"
    for plain in [i for i in d["sub"] if i.re == None]:
        if plain.src == sub.src:
            # Had a match of substitution strings
            msg = ("%s:  substitution '%s' redefined on %s" % 
                   (w, plain.src, sub.fn))
            if d["-r"]:
                Verbose(msg, d, style="redef")
            else:
                Error(msg)

def ProcessLines(lines, d):
    '''Process each line in the list of Line objects.  The types of
    lines that can be encountered are (leading command string removed):
        sub      Substitutions
        out      Change output state
        (, )     Code block
        [, ]     Comment block
    The lines to be output after processing are put into
    d["output_lines"].  Code block lines are put into d["code_block"].
    '''
    for line in lines:
        if d["in_comment_block"] and not IsCommentBlockEnd(line, d):
            if not d["out"]:
                continue
            Verbose("Ignore: %s" % line, d)
            continue
        if IsSub(line, d):
            if not d["out"]:
                continue
            s = StripCmdHeader(line.s, d)
            try:
                sub = Sub(s, line.f, line.n)
                CheckForRedefinition(sub, d)
                d["sub"].append(sub)
                Verbose("Found substitution:  %s" % line, d)
            except Exception as e:
                Error(str(e))
        elif IsComment(line, d):
            pass
        elif IsCommentBlockStart(line, d): 
            if not d["out"]:
                continue
            if d["in_comment_block"]:
                Error("%s:  already in comment block" % line.fn)
            d["in_comment_block"] = True
            Verbose("Starting comment block %s" % line.fn, d)
        elif IsCommentBlockEnd(line, d): 
            if not d["out"]:
                continue
            if not d["in_comment_block"]:
                Error("%s:  not in comment block" % line.fn)
            d["in_comment_block"] = False
            Verbose("Ending comment block %s" % line.fn, d)
        elif IsOut(line, d):
            ProcessOut(line, d)
        elif IsCodeBlockStart(line, d):
            if not d["out"]:
                continue
            if d["in_code_block"]:
                Error("%s:  already in code block" % line.fn)
            d["in_code_block"] = True
            Verbose("Starting code block %s" % line.fn, d)
            if d["code_block"]:
                raise Exception("Bug:  unexecuted code block")
            d["code_block"] = []
        elif IsCodeBlockEnd(line, d):
            if not d["out"]:
                continue
            if not d["in_code_block"]:
                Error("%s:  not in code block" % line.fn)
            d["in_code_block"] = False
            Verbose("Ending code block %s" % line.fn, d)
            ProcessCodeBlock(d)
        else:
            if not d["out"]:
                continue
            if d["in_code_block"]:
                Verbose("  Code %s" % line, d, style="code")
                d["code_block"].append(line)
            else:
                # Apply substitutions until string doesn't change
                changed, string = True, line.s
                while changed:
                    changed = False
                    newstring = ApplySubstitutions(line, string, d)
                    if newstring != string:
                        changed = True
                        string = newstring
                d["output_lines"].append(string)

def ExpandFormattingVariables(d):
    string = nl.join(d["output_lines"])
    vars = globals().copy()
    vars.update(dict(d["locals"]))
    newstring = string
    try:
        newstring = string.format(**vars)
    except (KeyError, ValueError) as e:
        if d["-e"]:
            Verbose("Variable %s is missing or bad in output string" % e,
                    d, style="missing")
        else:
            msg = ["Variable %s missing:" % e]
            Error(nl.join(msg))
    if newstring != string:
        Verbose("Formatting changed the output string", d)
    else:
        Verbose("Formatting did not change the output string", d)
    return newstring

def ContextError(msg, linenum0, lines, block_count):
    '''Print the error message msg and the lines in context of the
    offending line.
    '''
    offset = 3
    start = max(0, linenum0 - offset)
    end   = min(linenum0 + offset, len(lines))
    c.fg(c.lred)
    print(msg)
    print("In formatting block number %d" % block_count)
    print("Lines before and after offending line:")
    for i in range(start, end):
        print("  %r" % lines[i])
    c.normal()
    exit(1)

def OnlyWS(line):
    '''Return True if the string line consists only of whitespace or
    is empty.
    '''
    return ws_only.match(line) is not None

def GetDefaults(default, func, kw):
    '''Return (opt, options) where opt is a function to get the
    desired keyword argument from the style attribute of the function
    func.  options is a copy of the function's style dictionary.
    default is a dictionary with the default keywords and their
    values.  func is the function.  kw is the keyword dictionary 
    passed into the function.
    '''
    if not hasattr(func, "style"): # Set default attributes
        func.style = default
    # Make sure we have all needed keywords
    for i in default:
        if i not in func.style:
            func.style[i] = default[i]
    # Construct the dictionary we'll use for our options and update it
    # with the keywords passed on the command line.  Use a copy so
    # that we don't modify the original.
    options = func.style.copy()
    options.update(kw)
    opt = lambda x:  options.get(x, default[x])
    return (opt, options)

def CommonLeadingSpaces(block):
    '''Return common number of leading spaces on the strings in the
    sequence block.  Note that lines of only whitespace are ignored.
    '''
    f = lambda x: len(x) - len(x.lstrip(" "))
    # Don't count lines with only whitespace
    return min([f(i) for i in block if not OnlyWS(i)])

def wrap(block, **kw):
    '''block is a sequence of string objects.  wrap them appropriately
    per the keywords and return the resulting string.
    '''
    default = {
        "dedent" : False,   # If True, remove leading common spaces
        "et"     : False,   # Expand tabs
        "ignore" : False,   # Ignore this command
        "ii"     : "",      # Initial indent string
        "rb"     : False,   # Remove blank lines
        "si"     : "",      # Subsequent indent string
        "width"  : -1,      # Width to wrap to
    }
    opt, options = GetDefaults(default, wrap, kw)
    if opt("ignore"):
        return nl.join(block)   # Identity transformation
    # We'll use python's textwrap module to do the work.  The width
    # will be set by the columns global variable.
    tw = textwrap.TextWrapper()
    # Set the width to wrap to
    ws = opt("width")
    if ws is None:
        tw.width = max(columns, 1)
    else:
        try:
            w = int(ws)
        except Exception:
            Error("'%s' is bad 'width' parameter in wrap()" % ws)
        if not w:
            # TextWrapper objects can't take widths of 0; we'll fake
            # no wrapping with a big integer.
            tw.width = 1 << 64
        else:
            tw.width = max(columns + w, 1) if w < 0 else max(w, 1)
    # Other keywords
    tw.expand_tabs = opt("et")
    tw.initial_indent = opt("ii")
    tw.subsequent_indent = opt("si")
    tw.fix_sentence_endings = True
    # Remove any trailing whitespace from the lines, as it can show up
    # between words after wrapping.
    newblock = [i.rstrip() for i in block]
    # Put back into string form because textwrap.dedent() requires a
    # string rather than a sequence.
    string, out = nl.join(newblock), []
    if opt("dedent"):
        string = textwrap.dedent(string)
    # Now do paragraph wrapping
    nlnl = nl + nl
    paragraphs = string.split(nlnl)
    for i, paragraph in enumerate(paragraphs):
        out += tw.wrap(paragraph)
        if i != len(paragraphs) - 1:
            out += [""]  # Maintain paragraph breaks
    if opt("rb"):
        # Remove lines that only have whitespace
        out = [i for i in out if not OnlyWS(i)]
    return nl.join(out)

def indent(block, **kw):
    '''block is a sequence of string objects.  Indent them i spaces
    where i is an integer keyword; it can be negative.  If negative,
    each line except blank lines must have the requisite number of
    spaces.  Return the resulting string.
    '''
    default = {
        "dedent" : False,   # If True, remove leading common spaces
        "ignore" : False,   # Ignore this command
        "indent" : 0,       # How much to indent
    }
    opt, options = GetDefaults(default, wrap, kw)
    indent_ = opt("indent")
    dedent = opt("dedent")
    ignore = opt("ignore")
    if indent_ < 0 and dedent:
        Error("Error:  indent() can't have indent < 0 and dedent True")
    if ignore or indent_ == 0:
        return nl.join(block)   # Identity transformation
    n = CommonLeadingSpaces(block)
    # Dedent if required
    if n and dedent:
        r = re.compile("^" + " "*n)
        block = [r.sub("", i) for i in block]
    if indent_ < 0:
        if abs(indent_) > n:
            msg = '''
indent() format block error:
  The negative indent = %d is greater than the minimum number
  of spaces on lines in block (%d).  The first few lines of the 
  block are:
'''[1:]
            msg += nl.join(block[:3])
            Error(msg % (indent_, n))
        # Remove this number from each line
        return nl.join([j[abs(indent_):] for j in block])
    else:
        t = " "*indent_
        return nl.join([t + j for j in block])

def number(block, **kw):
    '''block is a sequence of string objects.  Number each line and
    return the resulting string.
    '''
    default = {
        "ignore" : False,   # Ignore this command
        "ii" : "",          # String to indent each line
        "fmt" : None,       # Optional formatting string
        "gap" : " " ,       # String between number and text
        "ib" : False,       # Don't number lines of only whitespace
        "inc" : 1,          # Increment for numbers
        "start" : 1,        # Starting value for numbering
        "term" : "",        # String that terminates number
    }
    opt, options = GetDefaults(default, wrap, kw)
    gap = opt("gap")
    ib = opt("ib")
    ignore = opt("ignore")
    inc = opt("inc")
    ii = opt("ii")
    start = opt("start")
    term = opt("term")
    fmt = opt("fmt")
    sp = " "
    if ignore:
        return nl.join(block)   # Identity transformation
    # Count the number of lines that will get numbers.
    numlines = len([i for i in block if OnlyWS(i)]) if ib else len(block)
    if fmt is None:
        # Get number of decimal digits required to display largest number
        maxnum = start + inc*(numlines - 1)
        n = max(1, int(ceil(log10(maxnum))))
        # Build line formatting string
        f = ii + "%*d%s%s%s"
        out, i = [], start
        for line in block:
            if ib and OnlyWS(line):
                out.append(line)
                continue
            out.append(f % (n, i, term, gap, line))
            i += inc
        return nl.join(out)
    else:
        # Use user-specified formatting string for numbers
        out, i = [], start
        for line in block:
            s = fmt % i
            if ib and OnlyWS(line):
                out.append(line)
                continue
            out.append("%s%s%s%s%s" % (ii, s, term, gap, line))
            i += inc
        return nl.join(out)

def FormatBlock(block, block_count, block_start_line, d):
    '''block will be a list of strings comprising the lines of the
    formatting bock.  block_count will be the number of the block that
    has been encountered in the input text so far.  block_start_line
    contains the string that began the format block with the beginning
    of the command string portion stripped off.
    '''
    if not block_start_line:
        # Set the choice variable to determine how an empty block
        # start line is handled.
        choice = 2
        if choice == 0:
            # Exit with an error message
            msg = [
                "Error:  format block number %d missing function call" % 
                    block_count,
                "First few lines of block:"
            ]
            msg += block[:3]
            Error(nl.join(msg))
        elif choice == 1:
            # Identity transformation
            return nl.join(block)
        elif choice == 2:
            # Default wrapping
            block_start_line = "wrap()"
    cmd = StripCmdHeader(block_start_line, d)
    if cmd[0] == "!":
        # Shell out
        cmd = cmd[1:]
        p = subprocess.PIPE
        s = subprocess.Popen(cmd, stdin=p, stdout=p, stderr=p, shell=True)
        result, err = s.communicate(nl.join(block))
        if err:
            msg = ["Error:  shell command returned error",
                   "  Format block number %d" % block_count,
                   "  '%s'" % err
                  ]
            Error(nl.join(msg))
        # If the resulting string ends with a newline, we remove it
        # because it was probably put there by the pipeline (the
        # block's strings were split on newlines and there thus
        # shouldn't be any there).
        return result[:-1] if result[-1] == nl else result
    else:
        # Get the keyword parameters and check that there are no
        # regular parameters.
        loc = dict(d["locals"])
        try:
            gp = GetParameters(block_start_line, **loc)
        except Exception as e:
            msg = [
                "Error:  formatting call failed (GetParameters()):",
                "  %s" % block_start_line, 
                "  %s" % e,
            ]
            Error(nl.join(msg))
        if gp.vars:
            msg = ["Error:  '%s' is a bad formatting block line" % 
                        block_start_line,
                "  No function parameters are allowed."]
            Error(nl.join(msg))
        # Construct the function call
        func = block_start_line[:block_start_line.find("(")]
        cmd ="s = %s" % ("%s(block, **kw)" % func) 
        # Call the relevant function
        loc.update({"kw" : gp.kw, "block":block})
        try:
            exec(cmd, globals(), loc)
        except Exception as e: 
            msg = [
                "Error:  formatting call failed:",
                "  exec '%s'" % cmd, 
                "  In text as '%s'" % block_start_line, 
                "  Exception:  %s" % e,
            ]
            Error(nl.join(msg))
        # Show what happened
        msg = ["Formatted block %d (%d lines):" % (block_count, len(block))]
        msg += ["  Command line = '%s'" % block_start_line]
        Verbose(nl.join(msg), d, style="formatting")
        return loc["s"]

def ExpandFormatBlocks(string, d):
    '''string contains the string to be formatted.  Pull out the
    format blocks, process them, then return the finished string.
    '''
    lines, out, block, block_start_line = string.split(nl), [], [], None
    format_block_level, block_count = 0, 0
    # Nesting of formatting blocks is handled by using a stack of blocks.
    stack = []
    push, pop = stack.append, stack.pop
    for linenum0, line in enumerate(lines):
        if IsFormatBlockStart(line, d):
            format_block_level += 1
            push((block, block_start_line))
            block_start_line = StripCmdHeader(line, d)[1:].strip()
            block = []
            block_count += 1
        elif IsFormatBlockEnd(line, d):
            if format_block_level < 1:
                msg = "End of format block while not in a format block"
                ContextError(msg, linenum0, lines, block_count)
            format_block_level -= 1
            s = FormatBlock(block, block_count, block_start_line, d)
            if format_block_level:
                block, block_start_line = pop()
                # Put the just-formatted block into the previous block
                block += s.split(nl)
            else:
                out.append(s)
        else:
            if not format_block_level:
                out.append(line)
            else:
                block.append(line)
    if format_block_level:
        msg = ["The number of format block starts doesn't match the ends"]
        msg += ["  Remaining number = %d" % format_block_level]
        Error(nl.join(msg))
    return nl.join(out)

def Transform(lines, d):
    '''Use this function in your own scripts; it does the same thing
    as main() except avoids any stream output.  Perform the includes,
    substitutions, and formatting on the Line objects in the lines
    list.  d is the options dictionary.  Return a string representing
    the transformed information.
 
    For ease of use, define d to be an empty dictionary and call 
    GetDefaultOptions(d) to get the required options.
 
    This function is also used for unit testing of the various
    features.
    '''
    lines = ExpandIncludeLines(lines, d)
    lines = Flatten(lines)
    ProcessLines(lines, d)
    CheckForSubSubstrings(d, test=True)
    CheckNotInCodeBlock(d)
    string = ExpandFormattingVariables(d)
    string = ExpandFormatBlocks(string, d)
    # Add a newline if d["post"] is not empty
    if d["post"]:
        string += nl
    string += nl.join(d["post"])
    return string

def Manpage(d):
    '''Format the manpage and send it to stdout.  Note it thus becomes
    an example for some of this script's techniques.
    '''
    stream = StringIO(manpage)
    lines = ReadFile("<manpage>", stream)
    dummy, d["locals"]["name"] = os.path.split(sys.argv[0])
    print(Transform(lines, d))
    exit(0)

def main():
    '''This function is used for the command line script.  The primary
    difference between this function and Transform() is that
    Transform() doesn't have the code that causes verbose printing
    with the -v option.
    '''
    d = {} # Options dictionary
    # Make a copy of the beginning globals so that we can determine
    # later changes.
    d["globals"] = globals().copy()
    files = ParseCommandLine(d)
    if d["-m"]:
        Manpage(d)
    lines = GetInputLines(files, d)
    Phase("expand include lines", d)
    lines = ExpandIncludeLines(lines, d)
    # Flatten
    Phase("flatten list of lines", d)
    Verbose("Before flattening = %d lines" % len(lines), d)
    lines = Flatten(lines)
    Verbose("After flattening  = %d lines" % len(lines), d)
    # Process each line
    Phase("process lines", d)
    ProcessLines(lines, d)
    Phase("check for substitution substrings", d)
    CheckForSubSubstrings(d)
    # Make sure a code block wasn't left open
    CheckNotInCodeBlock(d)
    DumpVariables(d)
    Phase("expanding formatting variables", d)
    string = ExpandFormattingVariables(d)
    # Process any format blocks
    Phase("formatting format blocks", d)
    string = ExpandFormatBlocks(string, d)
    # Print the output.
    Phase("send the text to the output stream", d)
    print(string, file=stream)
    # Print any lines saved in d["post"].
    if d["post"]:
        print(nl.join(d["post"]), file=stream)
if __name__ == "__main__":
    main()
