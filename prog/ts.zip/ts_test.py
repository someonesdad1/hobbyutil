from __future__ import print_function, division 
import os
import re
import ts
import sys
from lwtest import run, assert_equal, raises

py3 = sys.version_info[0] == 3
if py3:
    long = int
    from io import StringIO
else:
    from StringIO import StringIO
sio = StringIO

from pdb import set_trace as xx
if 0:
    import debug
    debug.SetDebugger()

nl = "\n"
fld = "@-----*"         # Input/output separator
rec = "@=====*"         # Test case separator

# Collection of test cases.  Ignore lines beginning with whitespace
# and '#'.
data = '''
# The empty string should result in the empty string

@------------------------------------------------------------------

@==================================================================

# A simple string should not be changed
Simple string
@------------------------------------------------------------------
Simple string

@==================================================================

# Multiple simple strings should not be changed
Simple string 1
Simple string 2
Simple string 3
@------------------------------------------------------------------
Simple string 1
Simple string 2
Simple string 3

@==================================================================

# Simple substitution
.sub("$name", "ts.py")
The script's name is $name.
@------------------------------------------------------------------
The script's name is ts.py.

@==================================================================

# Case-insensitive substitution
.sub(r"\$name", "ts.py", re=re.I)
The script's name is $name.
The script's name is $Name.
@------------------------------------------------------------------
The script's name is ts.py.
The script's name is ts.py.

@==================================================================

# Don't fail on a regexp compilation failure when cont is True
.sub(r"\$name", "ts.py", re="re.I", cont=True)
The script's name is $name.
The script's name is $Name.
@------------------------------------------------------------------
The script's name is $name.
The script's name is $Name.

@==================================================================

# Show out() works
Line 1
.out(0)
Line 2
Line 3
.out(1)
Line 4
@------------------------------------------------------------------
Line 1
Line 4
@==================================================================

# Code block and interpolated variable.
.(
    from math import pi
    x = "%.4f" % pi
.)
{x}
@------------------------------------------------------------------
3.1416

@==================================================================

# We can't test the pre- stuff using print statements without e.g.
# using subprocess.
.(
    d["post"].append("post- line")
.)
Normal line
@------------------------------------------------------------------
Normal line
post- line
@==================================================================

# Comment block & line are ignored.
.[
    This should be ignored.
.]
.# This line is ignored.
Normal line
@------------------------------------------------------------------
Normal line
@==================================================================

# Formatting block:  default
.<
No change.
.>
Normal line
@------------------------------------------------------------------
No change.
Normal line
@==================================================================
# Formatting block:  wrapping
.<wrap(width=20)
It is a truth universally acknowledged, that a single man in possession 
of a good fortune, must be in want of a wife.  
.>
@------------------------------------------------------------------
It is a truth
universally
acknowledged, that a
single man in
possession of a good
fortune, must be in
want of a wife.
@==================================================================
# Number a group of lines including empty ones
.<number(term=".")
Line 1
Line 2

Line 3
.>
@------------------------------------------------------------------
1. Line 1
2. Line 2
3. 
4. Line 3
@==================================================================
# Number a group of lines; ignore empty ones
.<number(term=".", ib=True)
Line 1
Line 2

Line 3
.>
@------------------------------------------------------------------
1. Line 1
2. Line 2

3. Line 3
@==================================================================
# Dedent
.<wrap(dedent=True)
    Line 1
    Line 2

    Line 3
.>
@------------------------------------------------------------------
Line 1 Line 2

Line 3
''' 

# The following tests require verbatim interpretation
data_v = (
    # Wrapping and indenting
    ('''
.<wrap(width=20, ii=" ", si=" ")
It is a truth universally acknowledged, that a single man in possession 
of a good fortune, must be in want of a wife.  
.>
'''[1:-1], '''
 It is a truth
 universally
 acknowledged, that
 a single man in
 possession of a
 good fortune, must
 be in want of a
 wife.
'''[1:-1]
),
    # Make a bullet list
    ('''
.<wrap(ii="  * ", si="    ")
Line 1

Line 2

Line 3
.>
'''[1:-1], '''
  * Line 1

  * Line 2

  * Line 3
'''[1:-1]
),
    # Make a more complicated bullet list with wrapping; remove the
    # blank lines and dedent the text.
    ('''
.<wrap(width=30, ii="* ", si="  ", rb=True, dedent=True)
    It is a truth universally acknowledged, that a single man in possession of a good fortune, must be in want of a wife.  

    However little known the feelings or views of such a man may be on his first entering a neighbourhood, this truth is so well fixed in the minds of the surrounding families, that he is considered the rightful property of some one or other of their daughters.  
.>
'''[1:-1], '''
* It is a truth universally
  acknowledged, that a single
  man in possession of a good
  fortune, must be in want of
  a wife.
* However little known the
  feelings or views of such a
  man may be on his first
  entering a neighbourhood,
  this truth is so well fixed
  in the minds of the
  surrounding families, that
  he is considered the
  rightful property of some
  one or other of their
  daughters.
'''[1:-1]
),

    # Number using most of the features
    ('''
.<number(ib=True, gap=" x ", start=1.0, inc=0.1, fmt="%3.1f", ii=" ")
Line 1
Line 2

Line 3
.>
'''[1:-1], '''
 1.0 x Line 1
 1.1 x Line 2

 1.2 x Line 3
'''[1:-1]
),
    # Expanding tabs
    ('''
.<wrap(et=True)
\tLine with tab (expanding tabs)

\t\tLine with two tabs

    Line with text indent
.>
'''[1:-1], '''
        Line with tab (expanding tabs)

                Line with two tabs

    Line with text indent
'''[1:-1]
),
    # Indenting:  positive indent
    ('''
.<indent(indent=1)
Line 1 positive indent
Line 2
.>
'''[1:-1], '''
 Line 1 positive indent
 Line 2
'''[1:-1]
),
    # Indenting:  negative indent
    ('''
.<indent(indent=-1)
 Line 1 negative indent
 Line 2
.>
'''[1:-1], '''
Line 1 negative indent
Line 2
'''[1:-1]
),
    # Nested formatting blocks
    ('''
.<
.<number()
First line nested formatting blocks
Second line
.>
.>
'''[1:-1], '''
1 First line nested formatting blocks 2 Second line
'''[1:-1]
),
    # Dedent via indent()
    ('''
.<indent(indent=2, dedent=True)
      Line 1 dedent via indent()
    Line 2

    Line 3
.>
'''[1:-1], '''
    Line 1 dedent via indent()
  Line 2
  
  Line 3
'''[1:-1]
),
)

class TestFailure(Exception): pass

def OptDict():
    d = {}
    ts.GetDefaultOptions(d)
    return d

def Extract(s, verbatim=False):
    '''s is a potential input string.  If verbatim is False, strip
    leading and trailing whitespace, remove lines whose first
    non-whitespace character is '#', and return as a string with
    newlines.  If verbatim is True, return the whole string with no
    modifications.
    '''
    if verbatim:
        return s
    lines = []
    for line in s.strip().split(nl):
        t = line.strip()
        if t and t[0] == "#":
            continue
        lines.append(line)
    return nl.join(lines)

def Perform(input, expected, d, verbatim=False):
    '''Use the ts.py module to transform the input string.  Compare the
    output to the string expected; if they match, the test passed.  If
    not, it's a failure; document it in a string and raise an
    exception.  d is the options dictionary.
    '''
    Perform.n += 1
    t = Extract(input, verbatim)
    lines = ts.ReadFile("<%d>" % Perform.n, sio(t))
    got = ts.Transform(lines, d)
    if got != expected:
        msg = ["", "Test <%d> failure:" % Perform.n, "Expected:"]
        for i in expected.split(nl):
            msg.append("  " + repr(i))
        msg.append("Got:")
        for i in got.split(nl):
            msg.append("  " + repr(i))
        raise TestFailure(nl.join(msg))

def TestDashB():
    '''Test that the -b option can change the beginning of a command
    string.
    '''
    d = OptDict()
    d["-b"] = "!!!"
    input = '''
!!!sub(r"\$name", "ts.py", re=re.I)
The script's name is $name.
'''[1:-1]
    expected = "The script's name is ts.py."
    Perform(input, expected, d, verbatim=True)

def TestDashE():
    '''Test that the -e option will allow a formatting error.
    string.
    '''
    d = OptDict()
    d["-e"] = True
    input = "{x}"
    expected = "{x}"
    Perform(input, expected, d, verbatim=True)

def TestDashR():
    '''Test that the -r option will allow redefinitions and sub
    substrings.
    '''
    d = OptDict()
    d["-r"] = True
    input = '''
.sub("a", "b")
.sub("aa", "b")
.sub("a", "c")
.sub("b", "x")
a
'''[1:-1]
    expected = "x"
    Perform(input, expected, d, verbatim=True)

def TestInclude():
    '''Show that a -I option can be utilized to find a temporary
    include file in /tmp.
    '''
    d = OptDict()
    d["-I"], fn, s = ["/tmp"], "ts.test.inc", "hello"
    f = os.path.join("/tmp", fn)
    input = '.inc("%s")' % fn
    expected = s
    open(f, "w").write(s + nl)
    try:
        Perform(input, expected, d)
    finally:
        os.remove("/tmp/%s" % fn)

def TestsThatCanBeDoneByParsingTheDataString():
    for i in re.split(rec, data, re.S):
        input, expected = [j.strip() for j in re.split(fld, i, re.S)]
        Perform(input, expected, OptDict())

def TestsThatNeedToBeDoneLiterally():
    for input, expected in data_v:
        Perform(input, expected, OptDict(), verbatim=True)

if __name__ == "__main__":
    Perform.n = 0   # Test case counter
    failed, messages = run(globals())
