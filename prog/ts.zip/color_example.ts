Color example:  We'll define a variable that contains an escape sequence
that changes the output to red, then another that changes it back to
normal.

.( # Code block to define colors
    c_red = "[1;31;40m"
    c_normal = "[0;37;40m"
.)
Hi {c_red}there{c_normal}, Bob.
