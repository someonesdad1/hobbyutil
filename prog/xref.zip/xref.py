'''《
vim:  foldmethod=marker foldtext=foldtext() foldmarker=《,》

Xref tool
  * xref.cpp:  The current implementation doesn't seem to be using a
    dictionary added with the -d option.  Since the 2018 test of
    /pylib/xref.py showed that it was 7.8 s vs. 5.4 s for the C++ version,
    this indicates that a much easier to maintain xref tool can be
    constructed in python.  A major advantage is that it would be fully 
    Unicode-aware and would allow for other encodings besides UTF8.

    I would bet with some functional tools constructed for the tokenizing
    sequence, things would be more than fast enough.

    It only needs to be a python 7 app; in fact, limit it to python 3.7 to
    allow use of f-strings.

    Here's the xref usage:

    Usage:  xref [options] [source_file_1 [source_file_2...]]
      A token cross-referencing and spell checking tool.
        -8          Flag line:offset of 8-bit characters
        -@          Get file list from stdin
        -h          Print man page to stdout
        -i          Print informational statistics to stdout
        -l          Long listing:  tokens, files, and line numbers
        -t          Short listing:  print tokens only
        -T          Print the processing times
    Spell checking:
        -c          Do not use built-in keywords for C/C++, python, shell 
        -C          Remove common English contractions
        -d dict     Specify a spelling dictionary in addition to default dict
        -D dict     Specify a spelling dictionary (replaces default dictionary)
        -g          Do not remove digits from tokens when spell checking
        -k          Split composite tokens when spell checking
        -n          Negate spell check:  only print tokens in dictionaries
        -s          Perform a spell check of the tokens (uses default
                    dictionary if one was compiled in)
    Default dictionary = 'c:/cygwin/home/Don/bin/data/words'

    Other things:
      
      * Use the -e and -E options like -d and -D, but these would mean
        dictionaries that were in serialized form.  Run some experiments to
        see how much pickling a dictionary helps to reduce runtime speed,
        as a large dictionary will take time to load and parse.
      * Make the tokenizer a class so that a user could pass a different
        class on the command line.
      * -u x Unicode options
        x = 1     Don't include any tokens with non-ASCII characters
        x = 2     Print any tokens to stderr that use Unicode characters
                  not allowed in python identifiers
      * -i option could ignore case.  -I could be stats.
      * -L option to specify programming language keywords to ignore 
      * A dash on the command line should allow input from stdin (the file
        name would be [stdin].
      * A histogram of the n most-used tokens (-H n)
      * Consider changing output to one line per token if there's only one
        file.
      * Regexps to color-highlight certain tokens
      * Total match count on token's line in parentheses
      * Sort options
        - By number of references
        - By name
        - By name, but in dictionary order

  xref timing Mon 30 Sep 2019 08:24:28 AM

    Very interesting data comparing /pylib/xref.py to the compiled C++
    program:
        --> time p xref.py *.py pgm/*.py >a
            real    0m9.189s        First non-cached data
            user    0m6.546s
            sys     0m0.343s
        --> time p xref.py *.py pgm/*.py >a
            real    0m6.846s
            user    0m6.578s
            sys     0m0.218s
        --> time xref *.py pgm/*.py >b
            real    0m7.576s
            user    0m5.500s
            sys     0m1.968s
        --> time xref *.py pgm/*.py >b
            real    0m7.405s
            user    0m5.203s
            sys     0m2.140s
        --> time xref *.py pgm/*.py >b
            real    0m7.436s
            user    0m5.312s
            sys     0m2.046s
        --> time p xref.py *.py pgm/*.py >a
            real    0m6.831s
            user    0m6.625s
            sys     0m0.140s
        --> time p xref.py *.py pgm/*.py >a
            real    0m6.813s
            user    0m6.593s
            sys     0m0.156s
    Summary:
        python:  6.8, 6.8, 6.8 s
        C++:     7.6, 7.4, 7.4, 7.3, 7.3 s (last two from below)
    Conclusion:  the python code is faster than the compiled C++ code.
    I attribute this to the 10 years or so that python 3 has been
    optimized.

    I recompiled the xref.cpp file with the -Ofast option and got the
    following results:
        --> time xref *.py pgm/*.py >b
            real    0m7.342s
            user    0m5.312s
            sys     0m1.983s
        --> time xref *.py pgm/*.py >b
            real    0m7.343s
            user    0m5.250s
            sys     0m2.030s
    
    This is a real eye-opener; about a decade ago a very astute CS guy
    in Europe commented to me in an email that the compiled stuff would
    stay approximately the same, but the interpreted stuff would keep
    getting faster.

''' # 》
if 1:  # imports
    # 《
    # Copyright (C) 2019 Don Peterson
    # Contact:  gmail.com@someonesdad1
    #
    # Licensed under the Open Software License version 3.0.
    # See http://opensource.org/licenses/OSL-3.0.
    #
    import getopt
    import os
    import re
    import sys
    from string import punctuation
    from pdb import set_trace as xx
    if 1:
        import debug
        debug.SetDebugger()  # Start debugger on unhandled exception
    nl = "\n"
    ii = isinstance
    default_dict = 'c:/cygwin/pylib/pgm/words'
    #》

def Xref(stream, filename, preserve_case=True, mydict={}):
    '''《 Build a dictionary of the tokens from stream, which will be read
    a line at a time.  mydict = dict(token: fdict) where fdict is
    dict(filename: set of line numbers where token was found).
    Stream is named by filename and will usually be the stream from
    open(filename), but it might be something else like the stdin stream
    which was labeled "stdin".
 
    The punctuation and control characters in the line are replaced
    with space characters, then each line is parsed on whitespace.  The
    tokens are inserted into the dictionary, which is returned.
    Multiple calls with a dictionary allow cross-referencing tokens in
    multiple files.
    '''
    if not hasattr(Xref, "punct"):
        # Construct a regexp that can be used to replace punctuation
        # with space characters for subsequent tokenizing.  '_' is
        # removed, as it is a valid token identifier character.
        punct = punctuation.replace("_", "")
        p = [re.escape(i) for i in punct]
        Xref.punct = re.compile('|'.join(p))
    def ProcessLine(line, linenum):
        line = line.rstrip("\n\r").replace("\t", " ")
        line = Xref.punct.sub(" ", line)        # Replace punct w/ space
        line = line if not preserve_case else line.lower() 
        words = re.split("  *", line)
        for word in words:
            if word == "":
                continue
            if 0:
                try:
                    # Ignore integers
                    x = int(word)
                    if str(x) == word:
                        continue
                except ValueError:
                    pass
            if word not in mydict:
                mydict[word] = {filename: set()}
            if filename not in mydict[word]:
                mydict[word][filename] = set()
            if linenum not in mydict[word][filename]:
                mydict[word][filename].add(linenum)
    # Read the lines from the stream
    linenum = 0
    line = stream.readline()
    while line:
        linenum += 1   # Line numbering is 1-based
        ProcessLine(line, linenum)
        line = stream.readline()
    return mydict 
    #》

def Error(msg, status=1):
    '《 Print error message and exit'
    print(msg, file=sys.stderr)
    exit(status)
    #》

def GetWords(s):
    '《 Return a set of words in the multiline string s'
    w = []
    for line in s.split(nl):
        if d["-i"]:
            w.extend(line.lower().split())    
        else:
            w.extend(line.split())    
    return set(tuple(w))
    #》

def Keywords():
    '《 Return a set of programming keywords'
    # C/C++/shell
    t = '''
    abs acos acosh acosl alloc amode argc argv asctime asin asinh asinl
    atan atan2 atan2l atanh atanl atexit atof atoi atol bitset bool
    boolalpha brk bsearch calloc ceil ceill cerr cgets chdir chmod cin
    clearerr cmode conio const const_iterator cosh coshl cosl cout
    cprintf cputs creat cscanf cstdlib ctime ctype difftime dup dup2
    ecvt elif endif endl erf erfc errno esac exec execl execle execlp
    execlpe execv execve execvp execvpe exp expl extern fabs fabsl
    fclose fcloseall fcntl fcvt fdopen feof ferror fflush fgetc fgetchar
    fgetpos fgets fileno fi floorl flushall fmod fmodl fopen fprint
    fprintf fputc fputchar fputs fread freopen frexp frexpl fscanf fseek
    fsetpos fstat fstream ftell func fwrite gcvt getc getch getchar
    getche getcwd getenv getline getw gmtime gsignal ifdef ifndef
    ifstream inline int ios iostream isalnum isalpha isascii isatty
    iscntrl isdigit isgraph islower isprint ispunct isspace istring
    istrstream isupper isxdigit iterator itoa labs ldexp ldexpl ldiv
    lfind localtime log10 log10l logl longjmp lsearch lseek ltoa malloc
    matherr mblen mbstowcs mbtowc memccpy memchr memcmp memcpy memicmp
    memmove memset mkdir mktemp mktime modf modfl namespace noboolalpha
    nocreate noreplace oct ofstream ostream perror pow pow10 pow10l powl
    printf putc putchar putenv putw qsort readonly realloc resetiosflags
    rmdir sbrk scanf setbase setbuf setf setfill setiosflags setjmp
    setmode setprecision setvbuf setw showbase showpoint showpos signal
    sinh sinhl sinl sizeof skipws spawnl spawnle spawnlp spawnlpe spawnv
    spawnve spawnvp spawnvpe sprintf sqrt sqrtl srand sscanf stat std
    stderr stdin stdio stdlib stdout stime stpcpy str strcat strchr
    strcmp strcmpi strcoll strcpy strcspn strdup strerror strftime
    stricmp strlen strlwr strncat strncmp strncmpi strncpy strnicmp
    strnset strpbrk strrchr strrev strset strspn strstr strstream strtod
    strtok strtol strtoul struct strupr strxfrm substr swprintf tanh
    tanhl tanl tmpfile tmpnam toascii tolower toupper trunc typedef
    typename tzset ultoa undef ungetc ungetch unitbuf unset uppercase va
    vfprintf vfscanf vprintf vscanf vsprintf vsscanf wcstombs wctomb'''
    s = GetWords(t)
    # Python
    t = '''
    and ascii bytearray bytes callable chr classmethod cmath cmp
    copysign def delattr delitem delslice dict dir divmod eq eval
    excepthook frozenset gamma getattr getitem getslice getstate globals
    hasattr hex hypot id init isinstance issubclass iter len lgamma
    locals lshift max memoryview min mul ord or radd rcmp rdiv rdivmod
    repr rlshift rmod rmul rop ror rpow rrshift rshift rsub rxor setattr
    setitem setslice setstate staticmethod tuple ufloat UFloat umath
    uncertainties vars xor xrange zip'''
    s.update(GetWords(t))
    return s
    #》

def ParseCommandLine(d):
    '《 Parse command line and return arguments'
    d["-@"] = False
    d["-C"] = False     # Remove common English contractions
    d["-c"] = False     # Use common programming keywords
    d["-D"] = "/pylib/pgm/words"      # Default spelling wordlist
    d["-d"] = []        # Auxiliary spelling wordlists
    d["-g"] = False     # Do not remove digits from tokens
    d["-I"] = False     # Information stats
    d["-i"] = False     # Ignore case of tokens
    d["-k"] = False     # Split composite tokens
    d["-n"] = False     # Only print those tokens that ARE in dictionaries
    d["-s"] = False     # Perform spell check
    d["-t"] = False     # List tokens only
    d["tokens"] = {}
    d["wordlist"] = set()
    try:
        opts, args = getopt.getopt(sys.argv[1:], "@Ccd:D:ghIiknst")
    except getopt.GetoptError as e:
        print(str(e))
        exit(1)
    for o, a in opts:
        if len(o) == 2 and o[1] in "@CcgIiknst":
            d[o] = not d[o]
        elif o in ("-d",):
            d["-d"].append(a)
        elif o in ("-D",):
            d["-D"] = None if a == "None" else a
        elif o in ("-h", "--help"):
            PrintManpage()
            exit(0)
    if not args and not d["-@"]:
        Usage(d)
    return args
    #》

def GetWordlists():
    '''《 
    '''
    if not d["-c"]:
        d["wordlist"].update(Keywords())
    if d["-C"]:
        d["wordlist"].update(GetContractions())
    for f in d["-d"]:
        s = open(f).read()
        d["wordlist"].update(GetWords(s))
    if d["-D"] is not None:
        s = open(d["-D"]).read()
        d["wordlist"].update(GetWords(s))
    #》

def GetContractions():
    '''《 Return a set of contraction words
    '''
    s = '''I ain aren couldn daren daresn dasn didn er finna gimme giv
        gonna gotta hadn hasn howdy isn ll ma mayn mightn mustn ne needn
        ol oughtn shan shouldn st tis twas wasn wouldn'''
    return GetWords(s)
    #》

def PrintManpage():
    '《'
    print('''
NAME
    xref.py - produce a cross reference of tokens in a set of text files

SYNOPSIS
    xref.py [options] [file1 [file2...]]

DESCRIPTION
    Tokens are gotten by replacing non-alphanumeric characters by
    space characters, then parsing on whitespace.  The output is
    printed to stdout and is the token on its own line followed by the
    files and line numbers that contain that token.  The -t option
    causes only the tokens to be printed out, one per line.

    Tab and carriage return characters will be replaced by spaces, but
    other control characters won't.  To see them, you may need to save
    the output to a file and view it with your editor.

    The program is also capable of spell checking the text files.  You
    may compile in the location of a default dictionary to use.  A
    dictionary is a list of tokens separated by whitespace that give
    the correct spelling of the tokens.  Letter case is ignored.
    Any misspelled tokens are printed to stdout.

    During spell checking, the program will parse compound tokens such
    as 'MyFunction' and 'my_function' into the tokens 'my' and
    'function', then look them up in the dictionary.  This allows
    programmers to help ensure they're using descriptive names for
    symbols in their programs.  The algorithm for splitting a compound
    token is to replace underscores by space characters, then put a
    space character before each upper case letter.  Single letters as
    tokens are ignored.  Tokens that are misspelled are printed to
    stdout.  The program includes a built-in dictionary for keywords
    in C, C++, python, and shell programming.  Tokens that begin with
    '0' are ignored, as they are likely octal or hex constants.
    Tokens that are composed of all digits are also ignored.

    In the source code, you can define a default dictionary to use for
    spell checking (if the string is empty, no default dictionary is
    used).  It is not an error if this file is not present.

    Because of the algorithm used for splitting composite tokens,
    tokens with all uppercase letters will be ignored when spell
    checking.

    Non-7-bit characters seen in e.g. UTF-8 encoded files will be seen
    in tokens, so this program should work on encoded files in a
    suitable terminal.  The line numbers and offsets of these non-
    7-bit characters will be sent to stderr if the -8 option is used.

CROSS-REFERENCING OPTIONS
    -@
        Get file list from stdin, one file per line.

    -h
        Print this man page to stdout.

    -I
        Print informational statistics at end of report.

    -i
        Case of tokens is ignored, so the report will have tokens in all
        lower case.

    -t
        Print only the tokens found in sorted order, one token per line.

SPELL CHECKING OPTIONS
    -c
        Do not use the built-in keywords for C/C++, python, and Bourne
        type shell scripts when spell checking.  You can replace the
        list in the source code with your own list of words.

    -C 
        Remove tokens resulting from common English contractions (e.g.,
        'didn', 'hasn', etc.).

    -d dict     
        Specify a spelling dictionary in addition to the default
        dictionary.  Use this option to add correctly spelled tokens
        that are not in the default dictionary.  You can have more
        than one -d option.  This "dictionary" should be a plain text
        file with one token per line.

    -D dict
        Specify a spelling dictionary that replaces the default
        dictionary.  You can have more than one -D option, but the last
        one on the command line is used.  This "dictionary" should be a
        plain text file with one token per line.

    -g
        Do not remove digits from tokens when spell checking.  Normally,
        a token such as MyFunction4 would have the 4 removed before
        spell checking.

    -k
        When spell checking, split composite words such as TwoWords or
        two_words into the simple words Two and Words.  This is intended
        to allow you to spell check source code.  Many programmers feel
        variable names should be spelled correctly and use words in the
        dictionary, rather than abbreviations.

    -n
        Don't read in the default dictionary.

    -s
        Perform a spell check on the tokens (uses the default
        dictionary if one was compiled in).  Any tokens not found in
        the dictionary will be printed to stdout.

EXAMPLES
    xref file1
        Print a list of tokens in file1 with filename and line numbers.

    xref -t file1
        Print a list of tokens only in file1.

    xref -s -d wordlist file1
        Spell check file1 using an explicitly specified "dictionary"
        (list of words, one word per line).

NOTES
    Please send bug reports/improvements to someonesdad1@gmail.com.
    ''')
    #》

def GetFiles():
    '''《 Read in the files to process from stdin, one file per line.
    '''
    return [i.rstrip("\n") for i in sys.stdin.readlines()]
    #》

def ProcessFile(file):
    '''《 Read in this file's tokens and put them into d["tokens"].
    '''
    if file == "-":
        stream, name = sys.stdin, "stdin"
    else:
        stream, name = open(file), file
    Xref(stream, name, preserve_case=d["-i"], mydict=d["tokens"])
    #》

def Usage(d, status=1):
    '《 Print usage statement and exit'
    name = sys.argv[0]
    s = f'''
Usage:  {name} [options] [file1 [file2...]]
  A token cross-referencing and spell checking tool.  Use '-' as a file
  argument to tokenize stdin.
    -@          Get file list from stdin, one file per line
    -h          Print man page to stdout
    -I          Print informational statistics
    -t          Print tokens only
  Spell checking:
    -c          Do not use built-in keywords for C/C++, python, shell 
    -C          Remove common English contractions
    -d dict     Specify a spelling dictionary in addition to default dict
    -D dict     Specify a spelling dictionary (replaces default dictionary)
    -g          Do not remove digits from tokens when spell checking
    -i          Ignore case of tokens for spelling
    -k          Split composite tokens when spell checking
    -n          Negate spell check:  only print properly-spelled tokens
    -s          Perform a spell check of the tokens 
    Default dictionary = '{default_dict}'
 
    Tokens are split in a line on python whitespace characters.
'''[1:-1]
    print(s.format(**locals()))
    exit(status)
    #》

def NumReferences(token):
    '''《 Return the number of line references this token has.
    '''
    n = 0
    t = d["tokens"][token]
    for i in t:
        n += len(t[i])
    return n
    #》

def PrintReport():
    '''《 Print the report.
    '''
    D = d["tokens"]
    for token in sorted(D.keys()):
        print(token)
        if not d["-t"]:
            F = D[token]
            for file in sorted(F):
                linenums = ', '.join([str(i) for i in sorted(list(F[file]))])
                n = len(F[file])
                print(f"    {file}: [{n}] {linenums}")
    if d["-I"]:
        # Print information statistics
        T = d["tokens"]
        # Total number of tokens
        numtokens = len(T)
        # Tokens with one reference & maximum number
        tok_one_ref = 0
        max_refs, max_t = 0, ""
        for t in T:
            n = 0
            for f in T[t]:
                n += len(T[t][f])
            if n > max_refs:
                max_refs = n
                max_t = t
            if len(T[t]) == 1:
                k = list(T[t].keys())[0]
                if len(T[t][k]) == 1:
                    tok_one_ref += 1
        print(f'''
Tokens with one reference    = {tok_one_ref}
Maximum number of references = {max_refs} ({max_t})
Total number of tokens       = {numtokens}
        '''.rstrip())
    #》

def RemoveDigits(token):
    '《'
    if not d["-g"]:
        digits = "0123456789"
        s = []
        for c in token:
            if c not in digits:
                s.append(c)
        return ''.join(s) 
    else:
        return token
    #》

def SplitCompositeToken(token):
    '''《 Return a list of the split words.
    Algorithm:  split the word on underscores, then insert a space
    character before each capital letter.  Digits are removed from the
    token unless -g was used.
    '''
    if token.upper() == token and "_" not in token:
        return [token]
    token = RemoveDigits(token)
    T = list(token)
    capitals = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    N = []
    for c in T:
        if c in capitals:
            N.append(" ")
        elif c == "_":
            N.append(" ")
            continue
        N.append(c)
    if d["-i"]:
        return ''.join(N).lower().split()
    else:
        return ''.join(N).split()
    #》

def SpellCheck():
    '''《 Print misspelled words.
    '''
    GetWordlists()
    T, W = sorted(d["tokens"].keys()), d["wordlist"]
    for t in T:
        misspelled = False
        if d["-k"]:     # Split composite tokens first
            for w in SplitCompositeToken(t):
                if w not in W:
                    misspelled = True
                    break
            if d["-n"] and not misspelled:
                print(t)
            elif misspelled:
                print(t)
        else:
            tk = RemoveDigits(t.lower() if d["-i"] else t)
            misspelled = tk not in W
            if d["-n"] and not misspelled:
                print(t)
            elif misspelled:
                print(t)
    #》

if __name__ == "__main__":
    # 《
    d = {}      # Options dictionary
    args = ParseCommandLine(d)
    if d["-@"]:
        args += GetFiles()
    for file in args:
        ProcessFile(file)
    if d["-s"]:
        SpellCheck()
    else:
        PrintReport()
    #》
