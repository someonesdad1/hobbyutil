/***********************************************************************
This file is the main component of the xor program.  See the xor.pdf
file for documentation.

If you define the VERBOSE macro when compiling, the program will print
out file names, sizes, and the hashed integer of the shuffling string.

----------------------------------------------------------------------
Copyright (C) 2012 Don Peterson
Contact:  gmail.com@someonesdad1
  
                    The Wide Open License (WOL)
  
Permission to use, copy, modify, distribute and sell this software and
its documentation for any purpose is hereby granted without fee,
provided that the above copyright notice and this license appear in
all copies.  THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT EXPRESS OR
IMPLIED WARRANTY OF ANY KIND. See
http://www.dspguru.com/wide-open-license for more information.
***********************************************************************/

#include <iostream>
#include <string>
#include <cstring>
#include <cstdlib>
#include <fstream>
#include <cassert>
#include "md5.h"

using namespace std;

// Note:  the following type must be an integer 4 bytes in size to
// ensure simplerandom() works properly.  If it's larger than 4 bytes, see
// the comment in simplerandom() on how to fix the algorithm to handle this
// case.  However, things will break badly if it's an integer longer
// than 16 bytes.
typedef unsigned long ulong;

double simplerandom(const ulong seed = 0)
{
    /* A simple linear congruential generator that returns a double in
    the half interval [0, 1).  Call with no argument to get a
    pseudorandom number.  Call with a nonzero seed argument to
    initialize the sequence.  */
    static ulong idum  = 1;
    if (seed)
    {
        idum = seed;
        return 0.0;
    }
    const double scale = 4294967296.0;  // double(2**32)
    // If idum is larger than a 32 bit integer, fix the following line
    // by changing it to
    // idum = (1664525L*idum + 1013904223L) % 4294967296;
    // The multiplier was recommended by Knuth and the additive
    // constant by Lewis.
    idum = 1664525L*idum + 1013904223L;
    double val = idum/scale;
    // Ensure the half interval because we want to use
    // int(simplerandom()*i) where i is an integer and have the result be
    // an integer in the interval [0, i - 1].
    if (val == 1.0)  // Ensure the half interval
        val = (scale - 1)/scale;
    return val;
}

string Normalize(const char * path)
{
    /* Replace any backslashes in path with forward slashes. */
    const string bs = "\\";
    string npath = path;
    string::size_type pos = npath.find(bs);
    while (pos != string::npos)
    {
        npath[pos] = '/';
        pos = npath.find(bs);
    }
    return npath;
}

void ReadWholeFile(const string & filename, string & bytes)
{
    /* Read all the bytes from file filename into the string bytes. */
    ifstream in(filename.c_str(), ios::binary);
    if (! in)
    {
        cerr << "Couldn't open '" << filename << "' file" << endl;
        exit(1);
    }
    // Go to the end of the file so we can use in.tellg() to get the
    // file's size in bytes
    in.seekg(0, ios::end);
    // Make the string bytes' size same as file
    bytes.resize(in.tellg());
    // Reset file pointer to beginning of file
    in.seekg(0, ios::beg);
    // Read all the bytes in at once
    in.read(& bytes[0], bytes.size());
    in.close();
    // Ensure we have at least one byte
    if (bytes.empty())
    {
        cerr << "Error:  '" << filename 
             << "' file is empty or doesn't exist." << endl;
        exit(1);
    }
}

void ProcessData(const string & data, 
                 const string & key, 
                 const string & output_file)
{
    /* XOR each byte of the data file with each byte of the key file.
    The mod operation (%) ensures that the method still works even if
    there aren't as many key file bytes as data file bytes. */
    ofstream out(output_file.c_str(), ios::binary);
    if (! out)
    {
        cerr << "Couldn't open '" << output_file << "' file for writing" 
             << endl;
        exit(1);
    }
    // Write one byte at a time to the output stream by XOR'ing a byte
    // from the data file with a byte from the key file.
    const int ks = key.size();
    for (unsigned int i=0; i < data.size(); i++)
    {
        out.put(data[i] ^ key[i % ks]);
    }
}

void Usage(const string & name)
{
    cerr << "Usage:  " << name << "  [-s string]  data  key  output\n"
"  Reads the bytes from the data file, XORs them with the bytes from\n"
"  the key file, and writes the results to the output file.  If there\n"
"  are not enough bytes in the key file, they are used in circular\n"
"  buffer fashion.\n"
"\n"
"  If the -s option is given (it must be before the file names), it is\n"
"  used to shuffle the bytes in the key file in memory.  The string is\n"
"  the seed for the random number generator for this shuffling.\n"
;
    exit(1);
}

void ShuffleKeyFile(string & key, const char * seed_string)
{
    /* Shuffle the key string using the simplerandom() function and the
    Moses-Oakford algorithm.  Seed the simplerandom number generator with
    an integer derived from the MD5 hash of seed_string. */
    
    // Get the MD5 hash of seed_string.
    MD5_CTX context;
    MD5Init(&context);
    MD5Update(&context, (unsigned char *)seed_string, strlen(seed_string));
    MD5Final(&context);
    // Convert beginning bytes of hash to an integer (note digest is
    // 16 bytes long; this will break if a ulong is more than 16 bytes).
    ulong seed = *((ulong *) context.digest);
    // Initialize the random number generator with this seed
    simplerandom(seed);
#ifdef VERBOSE
    cout << "Shuffling with seed " << seed << endl;
#endif
    // This is the Moses-Oakford shuffling algorithm (see Knuth, vol.
    // 2, "Seminumerical Algorithms", 2nd ed., section 3.4.2, pg 139,
    // algorithm P).  This O(n) algorithm for the array of n items
    // X[0], X[1], ..., X[n-1] is:
    //    1.  i = n - 1  (Start with last element in array)
    //    2.  Generate random number U on [0, 1).
    //    3.  j = int(U*i) so that j is an integer in [0, i-1].
    //    4.  Exchange X[i] with X[j].
    //    5.  Decrement i by 1.
    //    6.  If i > 0, go to step 2.
    ulong i = key.size() - 1;
    while (i > 0)
    {
        ulong j = int(i*simplerandom());      // j is in [0, i - 1]
        assert(j >= 0 && j < i);        // Check to make sure
        // Swap key[i] and key[j]
        char tmp = key[i];
        key[i] = key[j];
        key[j] = tmp;
        i--;
    }
}

int main(int argc, char **argv)
{
    const string program_name = Normalize(argv[0]);
    argv++;
    argc--;
    const char * seed_string = 0;
    if (argc && argv[0][0] == '-' && argv[0][1] == 's')
    {
        // The -s option is given
        seed_string = (const char *)argv[1];
        argv++;
        argv++;
        argc--;
        argc--;
    }
    if (argc != 3) 
        Usage(program_name);
    // Get the names of the files to use
    const string datafile    = Normalize(argv[0]);
    const string keyfile     = Normalize(argv[1]);
    const string outputfile  = Normalize(argv[2]);
    // Read in all the bytes
    string data;
    string key;
    ReadWholeFile(datafile, data);
    ReadWholeFile(keyfile, key);
#ifdef VERBOSE
    cout << "Data file = '" << datafile << "', " << data.size() << " bytes" << endl;
    cout << "Key  file = '" << keyfile << "', " << key.size() << " bytes" << endl;
#endif
    // Shuffle the key file if necessary
    if (seed_string) 
    {
        ShuffleKeyFile(key, seed_string);
    }
    // XOR the bytes and write the output file
    ProcessData(data, key, outputfile);
    return 0;
}
