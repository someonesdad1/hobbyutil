''' 
This module provides a OneTimePad object that can be used to get a
random string of bytes.

If you trust python's os.urandom() function, you can use this module
for cryptographically secure one time pads.  If you provide a nonzero
seed to the OneTimePad object, it will generate a repeatable sequence
of one time pad strings.

-------------------------------------------------------------

Copyright (C) 2005, 2012 Don Peterson
Contact:  gmail.com@someonesdad1

                         The Wide Open License (WOL)

Permission to use, copy, modify, distribute and sell this software and its
documentation for any purpose is hereby granted without fee, provided that
the above copyright notice and this license appear in all source copies.
THIS SOFTWARE IS PROVIDED "AS IS" WITHOUT EXPRESS OR IMPLIED WARRANTY OF
ANY KIND. See http://www.dspguru.com/wide-open-license for more
information.
'''
import os, random
try:
    from usage import usage
    usage("d:/p/pylib/otp.py", comment="")
except ImportError:
    pass

class OneTimePad:
    '''Generate one time pads.  If you initialize with seed != 0, the
    routine will use a repeatable random number generator.  Otherwise,
    the os.urandom() generator is used (requires python 2.4).
    '''
    def __init__(self, numbytes=16, seed = 0):
        self.numbytes = numbytes
        if seed:
            random.seed(seed)
            self.generator = self._getrandbytes
        else:
            self.generator = os.urandom

    def Get(self):
        # Return a one time pad in hex digits.
        str = ""
        for char in self.generator(self.numbytes):
            str += "%02X" % ord(char)
        return str

    def GetBinary(self):
        # Return a one time pad in binary.
        return self.generator(self.numbytes)

    def _getrandbytes(self, n):
        '''Return n random bytes using the random module's generator.
        '''
        s = ""
        for i in xrange(n // 4):
            s += self._generate_string(random.getrandbits(32))
        remainder = n % 4
        if remainder:
            t = self._generate_string(random.getrandbits(32))
            s += t[:remainder]
        return s

    def _generate_string(self, n):
        '''Generate a string from a four byte integer n.  The string is the
        4 bytes of the integer, each converted to a character.
        '''
        str = ""
        str = str + chr((n & 0xFF000000) >> 24)
        str = str + chr((n & 0x00FF0000) >> 16)
        str = str + chr((n & 0x0000FF00) >>  8)
        str = str + chr((n & 0x000000FF) >>  0)
        return str

if __name__ == "__main__":
    import sys, getopt
    from math import *
    def ParseCommandLine(d):
        d["-b"] = False
        if len(sys.argv) < 2:
            Usage(d)
        try:
            optlist, args = getopt.getopt(sys.argv[1:], "b")
        except getopt.GetoptError as str:
            msg, option = str
            out(msg)
            sys.exit(1)
        for opt in optlist:
            if opt[0] == "-b":
                d["-b"] = not d["-b"]
        if not args:
            Usage(d)
        return args
    def out(*v, **kw):
        sep = kw.setdefault("sep", " ")
        nl  = kw.setdefault("nl", True)
        stream = kw.setdefault("stream", sys.stdout)
        stream.write(sep.join([str(i) for i in v]))
        if nl:
            stream.write("\n")
    def Error(msg):
        out(msg, stream=sys.stderr)
        exit(1)
    def Usage(d, status=1):
        name = os.path.split(sys.argv[0])[1]
        num_bytes = d["num_bytes"]
        out('''
Usage:  {name} [-b] num_times [num_bytes [seed]]
  Generate cryptographically-secure random bytes in hex format.  Use
  the -b option for binary output (which should probably be redirected
  to a file).  If you want binary output, you should invoke python
  with the -u option on systems where it matters.  num_times and
  num_bytes can be any expressions that can have the integer part
  taken.  For example 

    {name} -b pi/2 1.1e6 >dest_file
 
  will result in a file containing 1100000 bytes.

  If you provide a seed string, a repeatable sequence is generated
  (and note this is not done with python's os.urandom, hence the
  output is not suitable for cryptographic applications).
 
  num_bytes defaults to {num_bytes}.

  Here, "cryptographically-secure" means python's os.urandom is used
  as the random number generator.  You'll have to decide whether that
  function is secure enough for your purposes.
'''[1:-1].format(**locals()))
        exit(1)
    d = {}
    d["seed"], d["num_bytes"] = 0, 32
    args = ParseCommandLine(d)
    f = lambda x: int(float(eval(x)))
    if len(args) == 1:
        num_times = f(args[0])
    elif len(args) == 2:
        num_times = f(args[0])
        d["num_bytes"] = f(args[1])
    elif len(args) == 3:
        num_times = f(args[0])
        d["num_bytes"] = f(args[1])
        seed = abs(hash(args[2]))
    else:
        Usage(d)
    if num_times < 1:
        Error("num_times must be an integer > 0")
    o = OneTimePad(numbytes=d["num_bytes"], seed=d["seed"])
    if d["-b"]:
        for i in range(num_times):
            out(o.GetBinary(), nl=False)
    else:
        for i in range(num_times):
            out(o.Get())
