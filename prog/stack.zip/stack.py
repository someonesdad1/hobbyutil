'''
General-purpose stack object.  In the following, a stack of items a,
b, c, etc. will be represented as abc where the leftmost element is
the top of the stack.
 
Attributes
 
    size
        Maximum number of elements the stack can hold.  0 for
        infinity (this is the default).  If you set the stack's size
        to an integer greater than zero, the stack is limited to that
        maximum number of elements.  If you push() or append() a new
        element, the element on the other end of the stack is lost.
        If you set the size to a number less than the number of
        elements already in the stack, the right-most elements will be
        lost if their sequence number is larger than the size.
 
    homogeneous
        A Boolean value indicating whether the stack is homogeneous or
        not.  Because of the method of implementation, you can clear()
        a homogeneous stack and store a new type of object in it.
 
Methods
    __init__(homogeneous=False)
        Initializes an empty stack.  Set homogeneous to True to force
        the stack to only store homogeneous items (i.e., the items
        stored must be of the same type).
 
    append(x)
        Append x to the bottom of the stack.  append(x) to the stack
        abc results in abcx.
 
    swap()
        Exchange the top of the stack and the next element.
        ValueError if stack isn't large enough.  swap() on abc results
        in bac.
 
    rotate(n)
        Rotate to the right n items; n defaults to 1.  rotate(1) for
        abc results in cab.  If n is negative, rotate in the opposite
        direction.
 
    push(x)
        Puts x on the top of the stack.  push(x) on the stack abc
        results in xabc.
 
    pop()
        Pop one item off the top of the stack and return it.
        IndexError if stack is empty.  pop() on abc returns a and the
        stack after the operation is bc.
 
    clear()
        Set the stack to the empty stack.
 
Operations
    A stack is an iterable, so you can turn it into a list, tuple, and
    iterate over its elements in a 'for' loop.  len() operating on a
    stack returns the number of elements in the stack.
'''
 
# Copyright (C) 2014 Don Peterson
# Contact:  gmail.com@someonesdad1
 
#
# Licensed under the Open Software License version 3.0.
# See http://opensource.org/licenses/OSL-3.0.
#
 
from __future__ import print_function, division
import sys
from collections import deque

pyver = sys.version_info[0]
if pyver == 3:
    long = int

class Stack(object):
    def __init__(self, homogeneous=False):
        self._homogeneous = True if homogeneous else False
        self._size = 0
        self._d = deque()
    def clear(self):
        self._d.clear()
    def append(self, x):
        self._check_type(x)
        self._d.append(x)
    def swap(self):
        if len(self._d) < 2:
            raise ValueError("Stack doesn't contain enough elements")
        a, b = self._d.popleft(), self._d.popleft()
        self._d.appendleft(a)
        self._d.appendleft(b)
    def pop(self):
        return self._d.popleft()
    def push(self, x):
        self._check_type(x)
        self._d.appendleft(x)
    def rotate(self, n):
        if not isinstance(n, (int, long)):
            raise ValueError("n must be an integer")
        self._d.rotate(n)
    def _check_type(self, x):
        if len(self._d) and self._homogeneous:
            if type(x) != type(self._d[0]):
                msg = """Homogeneous stack; operation on different type:
  Object = '%s'"""
                raise ValueError(msg % str(x))
    def __str__(self):
        return ''.join(("stack(TOS->", str(list(self._d)), ")"))
    def __iter__(self):
        return iter(self._d)
    def __len__(self):
        return len(self._d)
    def _get_size(self):
        return self._size
    def _set_size(self, size):
        if not isinstance(size, (int, long)):
            raise ValueError("size must be an integer")
        if size < 0:
            raise ValueError("size must be >= 0")
        if size != self._size:
            if size:
                elements = list(self)[:size]
                self._d = deque(elements, size)
            else:
                self._d = deque(list(self))
        self._size = size
    size = property(_get_size, _set_size, None,
                    "Set maximum size [0 ==> unbounded]")
    @property
    def homogeneous(self):
        return self._homogeneous
