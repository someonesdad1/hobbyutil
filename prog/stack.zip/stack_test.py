from __future__ import division, print_function
from stack import Stack, deque
from lwtest import run, raises

n = 5

def init():
    st = Stack()
    for i in range(n):
        st.append(i)
    return st

def testAppend():
    st = init()
    assert(st.homogeneous == False)
    # This also checks that it's an iterable
    assert(list(st) == list(range(n)))

def testLen():
    st = init()
    assert(len(st) == n)

def testPop():
    st = init()
    for i in range(n):
        assert(st.pop() == i)
    assert(len(st) == 0)

def testPush():
    st = Stack()
    for i in range(n):
        st.push(i)
    for i in reversed(range(n)):
        assert(st.pop() == i)
    assert(len(st) == 0)

def testClear():
    st = init()
    assert(len(st) == n)
    st.clear()
    assert(len(st) == 0)

def testSize():
    st, m = init(), 2
    st.size = m
    assert(len(st) == m)
    assert(list(st) == list(range(m)))
    # Show we lose elements off the end by pushing
    for i in range(m):
        st.push(i)
    assert(list(st) == list(reversed(range(m))))
    # Analogous thing happens with append
    st.append(1)
    assert(list(st) == list(range(m)))
    # Can set back to infinite size
    st.size = 0
    st.clear()
    for i in range(n):
        st.append(i)
    assert(list(st) == list(range(n)))

def testHomogeneity():
    st = Stack(homogeneous=True)
    assert(st.homogeneous == True)
    st.push(1.1)
    x = 1
    raises(ValueError, st.push, x)
    raises(ValueError, st.append, x)
    st.clear()
    st.push(1)
    x = 1.1
    raises(ValueError, st.push, x)
    raises(ValueError, st.append, x)

def testRotate():
    # This test is a bit superficial because the stack's
    # implementaton is based on a deque and the deque is used
    # as the standard behavior.  However, it remains a valid
    # test if the Stack object's implementation changes.
    st = init()
    std = deque(list(st))
    for n in range(len(st)):
        st.rotate(n)
        std.rotate(n)
        assert(list(st) == list(std))
    for n in range(len(st)):
        st.rotate(-n)
        std.rotate(-n)
        assert(list(st) == list(std))
    # Can rotate an empty stack
    st.clear()
    st.rotate(10)

if __name__ == "__main__":
    exit(run(globals())[0])
