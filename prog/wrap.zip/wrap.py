'''
This script will wrap text per specifications.  See the Usage statement for
details (use -h on the command line).
'''
# Copyright (C) 2014 Don Peterson
# Contact:  gmail.com@someonesdad1
 
#
# Licensed under the Open Software License version 3.0.
# See http://opensource.org/licenses/OSL-3.0.
#
 
from __future__ import print_function, division
import getopt
import os
import sys
import textwrap

nl = "\n"

def Error(msg, status=1):
    print(msg, file=sys.stderr)
    exit(status)

def Usage(d, status=1):
    name = sys.argv[0]
    width = d["-w"]
    indent = d["-i"]
    expand_tabs = d["-t"]
    s = '''
Usage:  {name} [options] [file1 [file2...]]
    Wrap the paragraphs in the indicated text files to the
    characteristics indicated by the options and print the formatted
    text to stdout.  A paragraph is defined to be two consecutive
    newlines.
 
Options:
    -h
        Print a manpage.
    -i n
        Set the indentation level.  Setting n to 0 means remove
        wrapping.  The default is to remove any common indentation.
        n can be a python expression.
    -r
        Remove empty blank lines.
    -s
        Read stdin before reading any files on the command line.
    -t
        Expand tabs.  [{expand_tabs}]
    -w n
        Set the width to n.  The default is to set it to 5 columns
        less than the COLUMNS environment variable (or 75 if not
        defined).  n can be a python expression.
Examples
    Convert a text file for pasting into a word processing document:
        python {name} -i 0 -r textfile >textfile.wp

    Indent the text with left and right margins of 7 spaces (assumes a
    UNIX-type shell):
        python {name} -i 7 -w "$COLUMNS - 7"  textfile
'''[1:-1]
    print(s.format(**locals()))
    sys.exit(status)

def ParseCommandLine(d):
    d["-i"] = None      # Indent
    d["-t"] = False     # Expand tabs
    d["-r"] = False     # Remove empty paragraphs
    d["-s"] = False     # Read stdin
    d["-w"] = None      # Width
    try:
        optlist, files = getopt.getopt(sys.argv[1:], "hi:rstw:")
    except getopt.GetoptError as e:
        msg, option = e
        print(msg)
        exit(1)
    for opt in optlist:
        if opt[0] == "-i":
            try:
                d["-i"] = int(eval(opt[1]))
                if d["-i"] < 0:
                    raise ValueError()
            except ValueError:
                Error("Indentation (-i) argument must be 0 or larger")
        if opt[0] == "-h":
            Usage(d, status=0)
        if opt[0] == "-r":
            d["-r"] = True
        if opt[0] == "-s":
            d["-s"] = True
        if opt[0] == "-t":
            d["-t"] = True
        if opt[0] == "-w":
            try:
                d["-w"] = int(eval(opt[1]))
                if d["-w"] <= 0:
                    raise ValueError()
            except ValueError:
                Error("Width (-w) argument  must be greater than 0")
    if d["-i"] is 0:
        d["-w"] = 1 << 64   # Since textwrap doesn't do unwrapping
    elif d["-w"] is None:
        d["-w"] = DefaultWidth()
    d["-i"] = 0 if d["-i"] is None else d["-i"]
    if not files and not d["-s"]:
        Usage(d)
    return files

def DefaultWidth():
    return (max(1, int(os.environ["COLUMNS"]) - 5)
            if "COLUMNS" in os.environ else 75)

def RemoveCommonIndent(lines):
    g = lambda x: len(x) - len(x.lstrip(" "))
    leading_spaces = min([g(i) for i in lines if i])
    t = " "*leading_spaces
    def f(s):  # Remove leading spaces or return "" for whitespace line
        if s.startswith(t):
            s = s[leading_spaces:]
        return "" if s.isspace() else s.rstrip()
    return [f(i) for i in lines]

if __name__ == '__main__':
    opt = {}  # Options dictionary
    files = ParseCommandLine(opt)
    # Get sequence of input lines
    lines = []
    if opt["-s"]:
        lines += sys.stdin.read().splitlines()
    text = []
    for filename in files:
        with open(filename, "rU") as f:
            text.append(f.read())
    lines += nl.join(text).splitlines()
    lines = RemoveCommonIndent(lines)
    # Set up a TextWrapper object
    w = textwrap.TextWrapper()
    w.expand_tabs = opt["-t"]
    w.width = max(1, opt["-w"])
    w.replace_whitespace = True
    w.fix_sentence_endings = True
    t = " "*opt["-i"]
    w.initial_indent = t
    w.subsequent_indent = t
    # Split on paragraphs, wrap each paragraph, and send to stdout
    pp = nl + nl
    for line in nl.join(lines).split(pp):
        print(w.fill(line), end=nl if opt["-r"] else pp)
