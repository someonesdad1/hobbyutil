'''
Convert a text file to word processor form.
 
Defines a paragraph as two consecutive newlines.  Each paragraph's text
is split into tokens and these tokens are joined by a single space.
Hyphenated words at the end of a line are rejoined and the hyphen
removed.  The text of the paragraph is then put onto one line.
 
A facility is provided to allow blocks of text (e.g., code, poetry) to
be sent to the output verbatim.  See the usage statement with -h for
how to do this along with various options.
 
The defaults are set up for how I like to have text formatted for
incorporation into my word processor, but these may not fit your needs.
The default values can be set in the function ParseCommandLine().
'''
# Copyright (C) 2014 Don Peterson
# Contact:  gmail.com@someonesdad1
 
#
# Licensed under the Open Software License version 3.0.
# See http://opensource.org/licenses/OSL-3.0.
#
 
from __future__ import division, print_function
import sys
import os
import re
import getopt

try:
    from io import StringIO
except ImportError:
    from StringIO import StringIO

have_gtk = have_windows = False
try:
    import pygtk
    pygtk.require("2.0")
    import gtk
    have_gtk = True
except ImportError:
    try:
        import win32clipboard
        have_windows = True
    except ImportError:
        pass

py3 = True if sys.version_info[0] > 2 else False
nl = "\n"

# The following string is used to flag locations of verbatim text in
# the processed data.  It must not appear in regular text when followed
# by the string representation of an integer.
key_start = "\x00key"

# Abbreviations and titles need one space after them.
abbreviations = '''
    a acad acc acct ad addr adj adv al alt approx apr assn asst at
    attn aug ave b betw bros c ca cal cca cent cf ch chas chem cit
    cm co conc corp cp ct ctrl cu cwt d dec dept devt diff dist div
    dwt e ea ed edn encl eng esp esq est et etc ex exc f feb fem ff
    fig fl flor ft fwd g gal govt grad h hr hrs ht i ibid id impt
    in inc info inv irreg j jan jr jul jun k l lat lb lib litt long
    loq m mar masc mass max may meas mech med min misc movt mts n
    nat naut no nov o obj oct op orig oz p para pc pcs phys pl pop
    poss pp ppl prep prob pron prox pseud pt pub q qtr r rd ref
    refl reg rev s sc scil sec sep sept seq ser sic sing so sp sq
    sr st stat syn t tbsp tem temp thos tsp u ult univ unkn v var
    vb viz vol vols vs vt vulg w wk wm wt x y yd yr yrs z
'''
titles = '''
    capt col comdr cpl dr gen gov hon lt maj mme mr mrs ms mt prof pvt
    sgt ste
'''

def Error(msg, status=1):
    print(msg, file=sys.stderr)
    exit(status)

def Usage(d, status=1):
    name = sys.argv[0]
    colon = d["-k"]
    bl = d["-p"]
    ns = d["-s"]
    on, off = d["verbatim_begin"].strip(), d["verbatim_end"].strip()
    s = '''
Usage:  {name} [options] [file1 [file2]]
  Removes hard line breaks from input text so that paragraphs are
  indicated by one newline.  The use case is to change text into a form
  suitable for importing into a word processor.  file 1 is the input
  text file and file2 is the output text file.

  A hyphenated word at the end of a line will be joined with the first
  word on the following line and the hyphen removed except if the word
  on the following line is capitalized (e.g., in a hyphenated name).

  Use {on} and {off} on their own lines to indicate a block of text
  that shouldn't be reformatted.

  Multiple spaces will be changed into one space character.

Options:
    -c      Get input from clipboard; send output to clipboard.
    -h      Print this help message.
    -i      Get input from clipboard; output to file1.
    -k n    Number of spaces after a colon. [{colon}]
    -n      Don't remove trailing newlines.
    -o      Get input from file1; output to clipboard.
    -p n    Number of newlines after a paragraph. [{bl}]
    -s n    Number of spaces between sentences. [{ns}]
'''[1:-1]
    print(s.format(**locals()))
    sys.exit(status)

def ParseCommandLine(d):
    d["-c"] = False         # In & out to clipboard
    d["-i"] = False         # Input from clipboard
    d["-k"] = 2             # Number of spaces after colon
    d["-n"] = True          # Remove any trailing newlines
    d["-o"] = False         # Output to clipboard
    d["-p"] = 0             # Newlines after paragraph
    d["-s"] = 2             # Number of spaces after sentence
    d["verbatim"] = {}
    d["verbatim_begin"] = "{{" + nl
    d["verbatim_end"] = "}}" + nl
    try:
        opts, args = getopt.getopt(sys.argv[1:], "chik:nop:s:")
    except getopt.GetoptError as e:
        print(str(e))
        exit(1)
    for o, a in opts:
        if o in ("-c",):
            d["-i"] = d["-o"] = True
        elif o in ("-h",):
            Usage(d, status=0)
        elif o in ("-i",):
            d["-i"] = True
        elif o in ("-k",):
            d["-k"] = int(a)
        elif o in ("-n",):
            d["-n"] = False
        elif o in ("-o",):
            d["-o"] = True
        elif o in ("-p",):
            d["-p"] = int(a)
        elif o in ("-s",):
            d["-s"] = int(a)
    # Check for proper number of parameters
    if d["-o"] or d["-i"]:
        if (d["-i"] and not d["-o"]) or (d["-o"] and not d["-i"]):
            if len(args) != 1:
                Usage(d)
        if d["-i"] and d["-o"]:
            if args:
                Usage(d)
    # Set up input & output streams
    d["in"] = sys.stdin
    d["out"] = sys.stdout
    if not d["-i"] and not d["-o"]:
        if len(args) == 1:
            d["in"] = open(args[0], "r")
        elif len(args) == 2:
            d["in"] = open(args[0], "r")
            d["out"] = open(args[1], "w")
    if d["-i"]:
        d["in"] = StringIO(unicode(GetStringFromClipboard()))
    if d["-o"]:
        d["out"] = StringIO()
    # Build the set of abbreviations/titles
    k = "abbreviations"
    d[k] = set()
    for line in abbreviations.split(nl):
        d[k].update(set(line.split()))
    k = "titles"
    d[k] = set()
    for line in titles.split(nl):
        d[k].update(set(line.split()))
    return args

def GetStringFromClipboard():     # Input from clipboard
    if have_gtk:
        cb = gtk.clipboard_get()
        s = cb.wait_for_text()
    elif have_windows:
        win32clipboard.OpenClipboard()
        s = win32clipboard.GetClipboardData(win32con.CF_TEXT)
        win32clipboard.CloseClipboard()
    else:
        Error("No clipboard connection")
    return s

def CheckVerbatimBlockMarks(d):
    '''Verify there's an equal number of beginning and ending block
    marks.
    '''
    s, b, e = d["text"], d["verbatim_begin"], d["verbatim_end"]
    n_begin = s.count(b)
    n_end = s.count(e)
    if n_begin != n_end:
        b, e = b.strip(), e.strip()
        msg = "Unmatched verbatim block markers '{b}' and '{e}'"
        Error(msg.format(**locals()))

def RemoveVerbatimBlocks(d):
    '''Remove the verbatim blocks from the input string and replace
    them with tokens that we can use to put them back in later.
    '''
    CheckVerbatimBlockMarks(d)
    d["verbatim"] = {}
    # Make a regular expression that can be used to remove the blocks.
    b, e = d["verbatim_begin"], d["verbatim_end"]
    r = re.compile(r'''
        {0}     # Match the verbatim_begin string
        (.*?)   # Non-greedy match of everything; put in group
        {1}     # Match the verbatim_end string
    '''.format(b, e), re.S | re.X)
    count = 0
    while True:
        count += 1
        key = "{0}{1}".format(key_start, count)
        mo = r.search(d["text"])
        if mo:
            s, e = mo.start(), mo.end()
            assert(len(mo.groups()) == 1)
            d["verbatim"][key] = mo.groups()[0]
            # Remove the found string and replace it with the key.
            # Note we make sure that the verbatim string is a separate
            # paragraph by surrounding it with multiple newlines.
            t = [d["text"][:s], 2*nl, key, 2*nl, d["text"][e:]]
            d["text"] = ''.join(t)
        else:
            break

def GetParagraphs(d):
    '''Split the input text into paragraphs.
    '''
    r = re.compile(r"\n\n+", re.S)
    for i in r.split(d["text"]):
        yield i

def EndsInHyphen(word):
    '''This function is present to allow you to use other characters to
    indicate hyphenation.  For example, the Unicode code points U+2010
    and U+2011 might be considered hyphens also.
    '''
    return word[-1] in "-"
def EndsInColon(word):
    return word[-1] == ":"

def IsEndOfSentence(word):
    return word[-1] == "."

def IsAbbreviationOrTitle(word, next_word, d):
    '''word ends in '.'; return True if it's an abbreviation or title
    and, thus, doesn't require an extra space after it because it's not
    the end of a sentence.
    '''
    assert(word[-1] == ".")
    w = word[:-1].lower()
    is_capital = ord("A") <= ord(next_word[0]) <= ord("Z")
    # Handle a.m. and p.m. specially
    if w in ("a.m.", "p.m."):
        return not is_capital
    if w in d["abbreviations"]:
        return True
    if w in d["titles"]:
        return is_capital
    return False

def ProcessParagraph(p):
    '''Convert a paragraph p to a sequence of words and join by spaces.
    Unhyphenate words that end in a hyphen character.
    '''
    words, q = p.replace(nl, " ").split(), []
    n = len(words)
    had_hyphen = False
    for i, word in enumerate(words):
        if had_hyphen:
            # This word was processed already because the previous word
            # was hyphenated.
            had_hyphen = False
            continue
        if EndsInHyphen(word) and i < n - 1:
            had_hyphen = True
            next_word = words[i + 1]
            first_char = next_word[0]
            if ord("A") <= ord(first_char) <= ord("Z"):
                # Next word is capitalized, so leave hyphen in place.
                q.append(word + next_word)
            else:
                # Remove the hyphen and join the next word.
                q.append(word[:-1] + next_word)
        elif EndsInColon(word):
            # We subtract one space because of the space character
            # which will be inserted at the end of this function.
            q.append(word + " "*(d["-k"] - 1))
        elif IsEndOfSentence(word):
            # We only need to do further processing if the -s option is
            # not 1 space.
            if d["-s"] != 1:
                # This can either be a true end of sentence or an
                # abbreviation/title.
                if i < n - 1:  # Next word exists
                    next_word = words[i + 1]
                    if IsAbbreviationOrTitle(word, next_word, d):
                        q.append(word)
                    else:
                        # We subtract one space because of the space
                        # character which will be inserted at the end
                        # of this function.
                        q.append(word + " "*(d["-s"] - 1))
                else:
                    q.append(word)
            else:
                q.append(word)
        else:
            q.append(word)
    return " ".join(q)

def SendStringToClipboard(s):
    if have_gtk:
        clipboard = gtk.clipboard_get()
        clipboard.set_text(s)
        clipboard.store()
    elif have_windows:
        win32clipboard.OpenClipboard()
        win32clipboard.EmptyClipboard()
        win32clipboard.SetClipboardText(s)
        win32clipboard.CloseClipboard()

if __name__ == "__main__":
    d = {}  # Options dictionary
    args = ParseCommandLine(d)
    d["text"] = d["in"].read()      # Get all the text to process
    RemoveVerbatimBlocks(d)
    paragraphs = []
    for paragraph in GetParagraphs(d):
        p = ProcessParagraph(paragraph)
        # Replace with verbatim text if appropriate
        key = p.strip()
        if key in d["verbatim"]:
            p = d["verbatim"][key].strip(nl)
        paragraphs.append(p)
    # Join the paragraphs into a single string
    n = max(1, d["-p"])
    s = (nl*n).join(paragraphs)
    # Remove trailing newlines
    if d["-n"]:
        s = s.rstrip(nl)
    # Send to the output stream
    if d["-o"]:
        SendStringToClipboard(s)
    else:
        print(s, file=d["out"])
