from __future__ import print_function, division
import fractions
from lwtest import run, assert_equal, raises
from wordnum import WordNum, Scale
from random import uniform, seed
from pdb import set_trace as xx

def PhraseBasics(scale):
    # Test the names in Scale's dictionaries
    scl = Scale(scale)
    w = WordNum(scale)
    for word in scl.small_mag2num:
        assert(w.phrase(word) == scl.small_mag2num[word])
    for word in scl.big_mag2num:
        assert(w.phrase("one " + word) == scl.big_mag2num[word])
def test_PhraseBasics():
    PhraseBasics("short")
    PhraseBasics("long")
def test_IntPhrase():
    # Short scale
    w = WordNum("short")
    s = ("six billion nine million eight hundred forty seven thousand "
         "million one hundred two")
    num = 6009847102
    assert(w.phrase(s) == num)
    s = ("nine million six billion eight hundred forty seven thousand "
         "million one hundred two")
    assert(w.phrase(s) == num)
    assert(w.phrase("zero fifty zero seven") == 57)
    assert(w.phrase("one quadrillion") == 10**15)
    assert(w.phrase("one decillion") == 10**33)
    s = "minus one thousand three hundred eighty seven"
    assert(w.phrase(s) == -1387)
    s = "negative one thousand three hundred eighty seven"
    assert(w.phrase(s) == -1387)
    s = "negative one hundred and one"
    assert(w.phrase(s) == -101)
    # Long scale
    w = WordNum("long")
    s = ("six billion nine million eight hundred forty seven thousand "
         "one hundred two")
    num = 6*10**12 + 9*10**6 + 847102
    assert(w.phrase(s) == num)
    # Note the big words can commute because addition commutes
    s = ("nine million six billion eight hundred forty seven thousand "
         "one hundred two")
    assert(w.phrase(s) == num)
    assert(w.phrase("one quadrillion") == 10**24)
    assert(w.phrase("one decillion") == 10**60)
    s = "minus one thousand three hundred eighty seven"
    assert(w.phrase(s) == -1387)
    s = "negative one thousand three hundred eighty seven"
    assert(w.phrase(s) == -1387)
def test_FractionPhrase():
    w = WordNum("short")
    assert(w.phrase("one over five") == fractions.Fraction(1, 5))
    assert(w.phrase("five over one") == fractions.Fraction(5, 1))
    raises(ValueError, w.phrase, "five over zero")
    s = "minus eight thousand nine hundred fifty seven"
    assert(w.phrase("%s over %s" % (s, s)) == 
                    fractions.Fraction(1, 1))
    assert(w.phrase("%s over one" % s) == 
                    fractions.Fraction(-8957, 1))
def test_FloatPhrase():
    w = WordNum("short")
    s, n = "minus one point zero five", -1.05
    assert(w.phrase(s) == n)
    s = "minus one point oh five"
    assert(w.phrase(s) == n)
    s = "minus one dot oh five"
    assert(w.phrase(s) == n)
    assert(w.phrase("point zero seven seven") == 0.077)
    assert(w.phrase("minus point zero seven seven") == -0.077)
def test_Normalize():
    w = WordNum("short")
    assert(w.normalize("oh") == ["zero"])
    assert(w.normalize("dot") == ["point"])
    s = "FouR\nTHOUSand\tTHREe@dot#oh\x1b.SIX"
    num = ["four", "thousand", "three", "point", "zero", "six"]
    assert(w.normalize(s) == num)
def test_Float():
    Float("short")
    Float("long")
def Float(scale):
    w = WordNum(scale)
    assert(w("1.") == ["one"])
    assert(w("1.2") == ["one", "point", "two"])
    assert(w("+1.") == ["one"])
    assert(w("+1.2") == ["one", "point", "two"])
    assert(w("-1.") == ["minus", "one"])
    assert(w("-1.2") == ["minus", "one", "point", "two"])
    t = ["six", "point", "zero", "two", "times", "ten", "to",
         "the", "twenty", "third"]
    assert(w(6.02e+23) == t)
    assert(w("6.02e+23") == t)
    assert(w("0.") == ["zero"])
    # Zero exponent
    assert(w("1e0") == ["one"])
    assert(w("1e00") == ["one"])
    assert(w("-1e0") == ["minus", "one"])
    assert(w("-1e00") == ["minus", "one"])
    assert(w("1e-0") == ["one"])
    assert(w("1e-00") == ["one"])
    assert(w("-1e-0") == ["minus", "one"])
    assert(w("-1e-00") == ["minus", "one"])
    # Integer significand
    t = ["times", "ten", "to", "the"]
    assert(w("1e1") == ["one"] + t + ["first"])
    assert(w("1.e1") == ["one"] + t + ["first"])
    assert(w("1e+1") == ["one"] + t + ["first"])
    assert(w("1.e+1") == ["one"] + t + ["first"])
    assert(w("+1e+1") == ["one"] + t + ["first"])
    assert(w("+1.e+1") == ["one"] + t + ["first"])
    # Negative integer significand
    assert(w("-1e1") == ["minus", "one"] + t + ["first"])
    assert(w("-1.e1") == ["minus", "one"] + t + ["first"])
    assert(w("-1e+1") == ["minus", "one"] + t + ["first"])
    assert(w("-1.e+1") == ["minus", "one"] + t + ["first"])
    assert(w("-1e-1") == ["minus", "one"] + t + ["minus", "one"])
    assert(w("-1.e-1") == ["minus", "one"] + t + ["minus", "one"])
    # 
    assert(w("1.2e1") == ["one", "point", "two"] + t + ["first"])
    assert(w("1.2e-1") == ["one", "point", "two"] + t +
                                   ["minus", "one"])
    assert(w("-1.2e-1") == ["minus", "one", "point", "two"] + t +
                                    ["minus", "one"])
def test_Ordinal():
    w = WordNum(scale="short")
    raises(ValueError, w.ordinal, "0")
    assert(w.ordinal("1") == ["first"])
    assert(w.ordinal("2") == ["second"])
    assert(w.ordinal("41") == ["forty", "first"])
    assert(w.ordinal(str(10**3)) == ["one", "thousandth"])
    assert(w.ordinal(str(10**6)) == ["one", "millionth"])
    assert(w.ordinal(str(10**9)) == ["one", "billionth"])
    assert(w.ordinal(str(10**12)) == ["one", "trillionth"])
def Sequence(scale):
    # Show that various integers can be converted to word form and
    # back with no loss of information.
    w = WordNum(scale=scale)
    for n in range(0, 10**6, 293):
        words = w(n)
        m = w(' '.join(words)) 
        assert(n == m)
    # Test an assortment of larger numbers:  generate a floating
    # point number between low and high and interpret it as the
    # logarithm of the integer to test.
    low, high, count = 6, 30, 1000
    seed(0)
    while count:
        n = int(10**uniform(low, high))
        words = w(n)
        m = w(' '.join(words)) 
        assert(n == m)
        count -= 1
def test_Sequence():
    Sequence("short")
    Sequence("long")

if __name__ == "__main__":
    exit(run(globals())[0])
