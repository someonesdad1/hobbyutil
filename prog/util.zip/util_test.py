'''
Missing tests for:
    Ignore Debug, Dispatch, GetString

'''
from __future__ import division, print_function
import math
import itertools
import sys
from random import seed
from util import *
from lwtest import run, assert_equal, raises
from pdb import set_trace as xx

if py3:  # py3 defined in util
    from io import StringIO
else:
    from StringIO import StringIO

seed(2**64)  # Make test sequences repeatable
show_coverage = len(sys.argv) > 1

def TestInt():
    data = (
        ("0b11", 3),
        ("0o10", 8),
        ("0x10", 16),
        ("10", 10),
        ("-0b11", -3),
        ("-0o10", -8),
        ("-0x10", -16),
        ("-10", -10),
    )
    for s, n in data:
        assert(Int(s) == n)

def TestAlmostEqual():
    assert(AlmostEqual(0, 0))
    assert(AlmostEqual(0, 1e-353))
    assert(AlmostEqual(1.0, 1.0))
    assert(AlmostEqual(1, 1 + 2e-15))
    assert(not AlmostEqual(1, 1 + 2.11e-15))
    assert(AlmostEqual(1.0, 1.001, 1e-2))
    assert(not AlmostEqual(1.0, 1.011, 1e-2))

def TestSpeedOfSound():
    assert(AlmostEqual(SpeedOfSound(273.15), 331.4, 1e-5))

def TestWindChillInDegF():
    assert(AlmostEqual(WindChillInDegF(20, 0), -21.9952, 1e-5))

def TestHeatIndex():
    assert(AlmostEqual(HeatIndex(40, 96), 101, 7e-2))
    assert(AlmostEqual(HeatIndex(100, 90), 132, 4e-1))

def TestSpellCheck():
    input_list = ("dog", "cAt", "hurse")
    word_dictionary = {"dog":"", "cat":"", "horse":"", "chicken":""}
    s = SpellCheck(input_list, word_dictionary)
    assert(len(s) == 1 and s[0] == "hurse")
    s = SpellCheck(input_list, word_dictionary, case_is_not_important=0)
    assert(len(s) == 2 and s[0] == "cAt" and s[1] == "hurse")

def TestAWG():
    assert(AlmostEqual(AWG(12), 0.0808, 8e-4))

def TestWireGauge():
    assert(AlmostEqual(WireGauge(12), 0.189))
    assert(AlmostEqual(WireGauge(0.189), 12))

def TestSignSignificandExponent():
    s, m, e = SignSignificandExponent(-1.23e-4)
    assert(s == -1 and m == 1.23 and e == -4)

def TestSignificantFigures():
    assert(AlmostEqual(float(SignificantFiguresS(1.2345e-6)), 1.23e-6))
    assert(AlmostEqual(SignificantFigures(1.2345e-6), 1.23e-6))

def TestEngineering():
    m, e, s = Engineering(1.2345e-6)
    assert(float(m) == 1.23 and e == -6 and s == "u")
    m, e, s = Engineering(1.2345e-7)
    assert(float(m) == 123 and e == -9 and s == "n")
    m, e, s = Engineering(1.2345e-8)
    assert(float(m) == 12.3 and e == -9 and s == "n")

def TestIdealGas():
    P, v, T = 0.101325e6, 0, 300
    v = IdealGas(P, v, T)
    assert(AlmostEqual(v, 0.85181, 1e-5))
    P = 0
    P = IdealGas(P, v, T)
    assert(AlmostEqual(P, 0.101325e6))
    T = 0
    T = IdealGas(P, v, T)
    assert(AlmostEqual(T, 300))

def TestConvertToNumber():
    assert(ConvertToNumber("1+i") == 1+1j)
    assert(ConvertToNumber("1+j") == 1+1j)
    assert(ConvertToNumber("j") == 1j)
    assert(ConvertToNumber("1.") == 1)
    assert(ConvertToNumber("1e2") == 1e2)
    assert(ConvertToNumber("1E2") == 1E2)
    assert(ConvertToNumber("1/2") == Fraction(1, 2))
    assert(ConvertToNumber("1") == 1)
    n = 10**50  # Large integer
    assert(ConvertToNumber(str(n)) == n)

def TestCommonPrefix():
    assert(not CommonPrefix(["a", "b"]))
    assert("a" == CommonPrefix(["aone", "atwo", "athree"]))
    assert("abc" == CommonPrefix(["abc", "abc", "abc"]))

def TestCommonSuffix():
    assert(not CommonSuffix(["a", "b"]))
    assert("a" == CommonSuffix(["onea", "twoa", "threea"]))
    assert("abc" == CommonSuffix(["abc", "abc", "abc"]))

def TestDecimalToBase():
    # Generate a few random integers and check the results with
    # python's int() built-in.
    for base in range(2, 37):
        for i in range(100):
            x = randint(0, int(1e6))
            # Note the following call also checks the result
            s = DecimalToBase(x, base, check_result=True)

def TestFlatten():
    a = [0, (1, 2, (3, 4, (5, 6, 7))), (8, (9, 10))]
    assert(list(Flatten(a)) == list(range(11)))

def TestSplitOnNewlines():
    assert(SplitOnNewlines("1\n2\r\n3\r") == ["1", "2", "3", ""])

def Test_eng():
    assert(eng(3456.78) == "3.46e3")
    assert(eng(3456.78, digits=4) == "3.457e3")
    # kkg is a illegal SI unit, but the code allows it
    assert(eng(3456.78, unit="kg") == "3.46 kkg")

def TestIsIterable():
    assert(IsIterable("") and IsIterable([]) and IsIterable(()) )
    assert(IsIterable({}) and IsIterable(set()))
    assert(not IsIterable(3))
    assert(IsIterable("a"))
    assert(not IsIterable("a", exclude_strings=True))
    assert(IsIterable([]))
    assert(IsIterable((0,)))
    assert(IsIterable(iter((0,))))
    assert(not IsIterable(0))

def Test_partition():
    if py3:
        return
    s = [['abc'], ['a', 'bc'], ['ab', 'c'], ['a', 'b', 'c']]
    assert(s == partition("abc"))

def TestBinary():
    f = lambda n: "-" + bin(n)[3:] if n < 0 else bin(n)[2:]
    for n in range(-1000, 1000):
        assert(Binary(n) == f(n))

def TestFindDiff():
    s1 = u"hello"
    s2 = u"hello there"
    assert(FindDiff(s1, s2) == -1)
    s1 = u"hellx"
    assert(FindDiff(s1, s2) == 4)
    s1 = u""
    assert(FindDiff(s1, s2, ignore_empty=True) == 0)

def Test_int2base():
    raises(ValueError, int2base, "", 2)
    raises(ValueError, int2base, 0, 370)
    x = 12345
    assert(int2base(x, 2) == bin(x)[2:])
    assert(int2base(x, 8) == oct(x)[1 + py3:])
    assert(int2base(x, 16) == hex(x)[2:])
    assert(int2base(36**2, 36) == "100")
    s = "53,kkns^~laU"
    assert(int2base("255" + str(2**64), 94) == s)

def Test_base2int():
    s = "53,kkns^~laU"
    assert(base2int(s, 94) == int("255" + str(2**64)))

def TestGetChoice():
    names = set(("one", "two", "three", "thrifty"))
    assert(GetChoice("o", names) == "one")
    assert(set(GetChoice("th", names)) == set(["three", "thrifty"]))
    assert(GetChoice("z", names) == None)

def TestKeep():
    assert(Keep("abc", "bc") == "bc")

def TestKeepFilter():
    f = KeepFilter("bc")
    assert(f("abc") == "bc")

def TestRemove():
    assert(Remove("abc", "cb") == "a")

def TestRemoveFilter():
    f = RemoveFilter("bc")
    assert(f("abc") == "a")

def TestListInColumns():
    s = [sig(math.sin(i/20), 3) for i in range(20)]
    got = "\n".join(ListInColumns(s))
    ts = "  "   # Note there are two spaces after these rows...
    exp = "0.00   0.0998 0.199  0.296  0.389  0.479  0.565  0.644  0.717  0.783"
    exp += ts
    exp += "\n"
    exp += "0.0500 0.149  0.247  0.343  0.435  0.523  0.605  0.682  0.751  0.813"
    exp += ts
    assert(got == exp)

def Test_hyphen_range():
    s = "77"
    L = hyphen_range(s)
    assert(L == [77])
    s = "8-12,14,18"
    L1 = hyphen_range(s)
    assert(L1 == [8, 9, 10, 11, 12, 14, 18])
    s = "12-8,14,18,18"
    L = hyphen_range(s)
    assert(L == [12, 11, 10, 9, 8, 14, 18, 18])
    L = hyphen_range(s, sorted=True)
    assert(L == L1 + [18])
    L = hyphen_range(s, unique=True)
    assert(L == L1)

def TestTempConvert():
    k, r = 273.15, 459.67
    assert(AlmostEqual(TempConvert(0, "c", "f"), 32))
    assert(AlmostEqual(TempConvert(0, "c", "k"), k))
    assert(AlmostEqual(TempConvert(0, "c", "r"), 32 + r))
    assert(AlmostEqual(TempConvert(0, "c", "c"), 0))
    assert(AlmostEqual(TempConvert(212, "f", "c"), 100))
    assert(AlmostEqual(TempConvert(212, "f", "f"), 212))
    assert(AlmostEqual(TempConvert(212, "f", "k"), k + 100))
    assert(AlmostEqual(TempConvert(212, "f", "r"), r + 212))

def TestIsTextFile():
    s = StringIO("Some text")
    assert(IsTextFile(s))
    s = StringIO("Some text\xf8")
    assert(not IsTextFile(s))
    # Also test IsBinaryFile()
    s = StringIO("Some text\xf8")
    assert(IsBinaryFile(s))

def Test_randq():
    s = [randq(seed=0)]
    for i in range(10):
        s.append(randq())
    s = ["%08X" % i for i in s]
    # Hex strings from "Numerical Recipes in C", page 284
    t = ["3C6EF35F", "47502932", "D1CCF6E9", "AAF95334", "6252E503",
        "9F2EC686", "57FE6C2D", "A3D95FA8", "81FDBEE7", "94F0AF1A",
        "CBF633B1"]
    assert(s == t)

def Test_randr():
    m = randq.maxidum
    assert(randr(0) == (1013904223 % m)/float(m))

def TestRemoveComment():
    s = ""
    assert(RemoveComment(s) == s)
    s = "abc"
    assert(RemoveComment(s) == s)
    s = " #"
    assert(RemoveComment(s) == " ")
    s = "a = 1 # kdjjfd"
    assert(RemoveComment(s, code=True) == "a = 1 ")
    s = "a = '#'"
    try:
        RemoveComment(s, code=True)
        raise Exception("Expected a ValueError exception")
    except ValueError:
        pass

def TestCountBits():
    bits = "0112122312"
    for i in range(10):
        assert(CountBits(i) == int(bits[i]))

def TestFindSubstring():
    #    01234567890
    s = "x  x    x  "
    assert(FindSubstring(s, "x") == (0, 3, 8))

util_simlink = "c:/cygwin/pylib/test/util_simlink.py"
translated_util_simlink = "../util.py"

def TestIsCygwinSymlink():
    if sys.platform == "win32":
        # For this to work, create a cygwin simlink named util_simlink.py
        # in /pylib/test that points to /pylib/util.py.
        assert(IsCygwinSymlink(util_simlink))
        assert(not IsCygwinSymlink("c:/cygwin/home/Don/bin/data/notes.txt"))

def TestTranslateSymlink():
    if sys.platform == "win32":
        # For this to work, create a cygwin simlink named util_simlink.py
        # in /pylib/test that points to /pylib/util.py.
        assert(TranslateSymlink(util_simlink) == translated_util_simlink)

def Test_bitlength():
    assert(bitlength(0) == 1)
    assert(bitlength(1) == 1)
    assert(bitlength(2) == 2)
    assert(bitlength(255) == 8)
    assert(bitlength(256) == 9)

def Test_grouper():
    def even_odd(elem):         # sample mapper
        if 10 <= elem <= 20:    # skip elems outside the range
            key = elem % 2      # group into evens and odds
            return key, elem
    got = grouper(range(30), even_odd)
    expected = {0: [10, 12, 14, 16, 18, 20], 1: [11, 13, 15, 17, 19]}
    assert(got == expected)
    got = grouper(range(30), even_odd, sum)
    expected = {0: 90, 1: 75}
    assert(got == expected)

def Test_int2bin():
    assert(int2bin(-33, 8) == "11011111")
    assert(int2bin( 33, 8) == "00100001")

def TestCfg():
    lines = '''
        from math import sqrt
        a = 44
        b = "A string"
        def X(a):
            return a/2
        c = a*sqrt(2)
        d = X(a)
'''[1:-1].split("\n")
    d = Cfg(lines)
    assert(d["a"] == 44)
    assert(d["b"] == "A string")
    assert(d["c"] == d["a"]*d["sqrt"](2))
    assert(d["d"] == 22)
    assert(str(d["X"])[:11] == "<function X")

def Test_soundex():
    test_cases = (
        ("Euler",       "E460"),
        ("Gauss",       "G200"),
        ("Hilbert",     "H416"),
        ("Knuth",       "K530"),
        ("Lloyd",       "L300"),
        ("Lukasiewicz", "L222"),
        ("chute",       "C300"),
        ("shoot",       "S300"),
        ("a",           "A000"),
        ("A",           "A000"),
    )
    for s, expected in test_cases:
        assert(soundex(s) == expected)
    assert(soundex("a") == "A000")
    raises(ValueError, soundex, "")
    raises(ValueError, soundex, " ")
    raises(ValueError, soundex, ".")

def TestSoundSimilar():
    assert(SoundSimilar("bob", "bib"))
    assert(SoundSimilar("mike", "make"))
    assert(SoundSimilar("mike", "muke"))
    assert(SoundSimilar("mike", "moke"))
    assert(SoundSimilar("mike", "meke"))
    assert(SoundSimilar("don", "dan"))
    assert(SoundSimilar("don", "din"))
    assert(not SoundSimilar("robert", "rabbit"))
    assert(not SoundSimilar("aorta", "rabbit"))

def TestUnique():
    assert(Unique(tuple()) == list())
    assert(Unique(list()) == list())
    a, b = (5, 4, 1, 5, 4, 2, 3, 2, 2, 4), [5, 4, 1, 2, 3]
    assert(Unique(a) == b)

def TestRemoveIndent():
    s = '''
    This is a test
        Second line
      Third line
    '''
    lines = RemoveIndent(s, numspaces=4).split("\n")
    assert(lines[0] == "")
    assert(lines[1] == "This is a test")
    assert(lines[2] == "    Second line")
    assert(lines[3] == "  Third line")
    assert(lines[4] == "")

def TestInterpretFraction():
    expected = Fraction(5, 4)
    assert(InterpretFraction("5/4") == expected)
    assert(InterpretFraction("1 1/4") == expected)
    assert(InterpretFraction("1+1/4") == expected)
    assert(InterpretFraction("1-1/4") == expected)
    #
    assert(InterpretFraction("+5/4") == expected)
    assert(InterpretFraction("+1 1/4") == expected)
    assert(InterpretFraction("+1+1/4") == expected)
    assert(InterpretFraction("+1-1/4") == expected)
    #
    assert(InterpretFraction("-5/4") == -expected)
    assert(InterpretFraction("-1 1/4") == -expected)
    assert(InterpretFraction("-1+1/4") == -expected)
    assert(InterpretFraction("-1-1/4") == -expected)
    #
    assert(InterpretFraction("1 1/1") == Fraction(2, 1))
    assert(InterpretFraction("+1 1/1") == Fraction(2, 1))
    assert(InterpretFraction("-1 1/1") == Fraction(-2, 1))
    #
    assert(InterpretFraction("1 2/1") == Fraction(3, 1))
    assert(InterpretFraction("+1 2/1") == Fraction(3, 1))
    assert(InterpretFraction("-1 2/1") == Fraction(-3, 1))
    # Argument must contain "/" and be parseable
    raises(ValueError, InterpretFraction, "1")
    raises(ValueError, InterpretFraction, "1/")
    raises(ValueError, InterpretFraction, "/1")

def TestProperFraction():
    assert(ProperFraction(Fraction("-1")) == "-1 0/1")
    assert(ProperFraction(Fraction("1")) == "1 0/1")
    assert(ProperFraction(Fraction(-1, 1)) == "-1 0/1")
    assert(ProperFraction(Fraction(1, 1)) == "1 0/1")
    assert(ProperFraction(Fraction(-3, 1)) == "-3 0/1")
    assert(ProperFraction(Fraction(3, 1)) == "3 0/1")
    assert(ProperFraction(Fraction(5, 4)) == "1 1/4")
    assert(ProperFraction(Fraction(-5, 4)) == "-1 1/4")

def Test_signum():
    assert(signum(-5) == -1)
    assert(signum(5) == 1)
    assert(signum(0) == 0)
    t = float
    assert(isinstance(signum(5, ret_type=t), t))

def TestSingleton():
    class A(object): pass
    a, b = A(), A()
    assert(hash(a) != hash(b))
    class A(Singleton): pass
    a, b = A(), A()
    assert(hash(a) == hash(b))

def TestNamingConventionConversions():
    cw, us, mc = "AbcDef", "abc_def", "abcDef"
    assert(cw2us(cw) == us)
    assert(cw2mc(cw) == mc)
    assert(us2mc(us) == mc)
    assert(us2cw(us) == cw)
    assert(mc2us(mc) == us)
    assert(mc2cw(mc) == cw)

def TestBatch():
    s = "0123456789"
    r = ("012", "345", "678", "9")
    for i, b in enumerate(Batch(s, 3)):
        assert(r[i] == ''.join(list(b)))

def TestGroupByN():
    n, m = 5, 3
    s = range(n)
    t = ((0, 1, 2),)
    assert(t == tuple(GroupByN(s, m, fill=False)))
    t = ((0, 1, 2), (3, 4, None))
    u = tuple(GroupByN(s, m, fill=True))
    assert(t == tuple(GroupByN(s, m, fill=True)))

def TestPercentile():
    s = sorted([  # NIST gauge study data from
        # https://www.itl.nist.gov/div898/handbook/prc/section2/prc262.htm
        95.0610, 95.0925, 95.1065, 95.1195, 95.1442, 95.1567, 95.1591,
        95.1682, 95.1772, 95.1937, 95.1959, 95.1990])
    assert(round(Percentile(s, -1), 4) == 95.0610)
    assert(round(Percentile(s, 0), 4) == 95.0610)
    assert(round(Percentile(s, 0.5), 4) == 95.1579)
    assert(round(Percentile(s, 0.9), 4) == 95.1981)
    assert(round(Percentile(s, 1), 4) == 95.1990)
    assert(round(Percentile(s, 1.1), 4) == 95.1990)
    raises(ValueError, Percentile, [1], 0.5)

def TestStringSplit():
    s = "hello there"
    assert(StringSplit([4, 7], s) == ['hell', 'o t', 'here'])
    t = "3s 3x 4s"
    if py3:
        f = lambda x: bytes(x, encoding="ascii")
        q = [f('hel'), f('ther'), f('e')]
        assert(StringSplit(t, s, remainder=True) == q)
        assert(StringSplit(t, s, remainder=False) == q[:-1])
    else:
        q = ['hel', 'ther', 'e']
        assert(StringSplit(t, s, remainder=True) == q)
        assert(StringSplit(t, s, remainder=False) == q[:-1])

def TestIsConvexPolygon():
    p = ((0, 0), (1, 0), (1, 1), (0, 1))
    assert(IsConvexPolygon(*p))
    p = ((0, 0), (1, 0), (1, 1), (0.5, 0.5))
    assert(not IsConvexPolygon(*p))
    # Test with lines slightly above and below the above figure's
    # diagonal.
    d = 1e-10
    p = ((0, 0), (1, 0), (1, 1), (0.5 + d, 0.5))    # Concave
    assert(not IsConvexPolygon(*p))
    p = ((0, 0), (1, 0), (1, 1), (0.5 - d, 0.5))    # Convex
    assert(IsConvexPolygon(*p))
    p = ((0, 0), (1, 0), (1, 1), (0.5, 0.5 + d))    # Convex
    assert(IsConvexPolygon(*p))
    p = ((0, 0), (1, 0), (1, 1), (0.5, 0.5 - d))    # Concave
    assert(not IsConvexPolygon(*p))

def TestStringToNumbers():
    s = "4j 3/5 6. 7"
    assert(StringToNumbers(s) == (4j, Fraction(3, 5), 6.0, 7))

def TestPaste():
    a = ["a", "b", 1]
    b = ["d", "e"]
    c = ["f"]
    s = Paste(a, b, c)
    assert(s == ['a\td\tf', 'b\te\t', '1\t\t'])

def TestItemCount():
    f, F = ItemCount, Fraction
    raises(Exception, f, 1)
    raises(Exception, f, 1.0)
    raises(Exception, f, F(1, 1))
    raises(Exception, f, object())
    # Empty sequence returns empty string
    assert(f([]) == [])
    # Elementary counting
    assert(f([1]) == [(1, 1)])
    assert(f([1.0]) == [(1.0, 1)])
    assert(f([1, 1]) == [(1, 2)])
    assert(f([1, 1, 1]) == [(1, 3)])
    # Two element types
    assert(f([1, 2]) == [(1, 1), (2, 1)])
    assert(f([1, 1, 2]) == [(1, 2), (2, 1)])
    assert(f([1, 2.0]) == [(1, 1), (2.0, 1)])
    assert(f([1.0, 2.0]) == [(1.0, 1), (2.0, 1)])
    assert(f([1.0, 2.0, 2]) == [(2.0, 2), (1.0, 1)])
    assert(f([1.0, 2, 2.0]) == [(2, 2), (1.0, 1)])
    assert(f([1.0, 2, 2.0, F(2, 1)]) == [(2, 3), (1.0, 1)])
    # Show order can matter.  Thus, the results can be syntactically
    # different but semantically the same.
    assert(f([1, 2, 1, 2]) == [(1, 2), (2, 2)])
    assert(f([2, 1, 1, 2]) == [(2, 2), (1, 2)])
    assert(f([2, 1, F(1, 1), 2]) == [(2, 2), (1, 2)])
    # Item type also matters
    assert(f([1, F(1, 1)]) == [(1, 2)])
    assert(f([1.0, F(1, 1)]) == [(1.0, 2)])
    assert(f([F(1, 1), 1.0]) == [(F(1, 1), 2)])
    assert(f([F(1, 1), 1]) == [(F(1, 1), 2)])
    # Fractions
    assert(f([F(1, 2), 1]) == [(F(1, 2), 1), (1, 1)])
    assert(f([F(1, 2), F(1, 2)]) == [(F(1, 2), 2)])
    # Show that it works with strings
    assert(f(["a", "b", "a"]) == [("a", 2), ("b", 1)])
    # Any hashable object can be counted
    a, b = object(), object()
    assert(f([a, b]) == [(a, 1), (b, 1)])
    # Show the n keyword returns the n largest counts
    a = [1, 2, 2, 3, 3, 3]
    assert(f(a, n=1) == [(3, 3)])
    assert(f(a, n=2) == [(3, 3), (2, 2)])
    assert(f(a, n=3) == [(3, 3), (2, 2), (1, 1)])
    assert(f(a, n=4) == [(3, 3), (2, 2), (1, 1)])

def TestKeepOnlyLetters():
    s = "\t\n\xf8abcABC123_"
    # digits True
    expected = "   abcABC123"
    t = KeepOnlyLetters(s, underscore=False, digits=True)
    assert(t == expected + " ")
    t = KeepOnlyLetters(s, underscore=True, digits=True)
    assert(t == expected + "_")
    # digits False
    expected = "   abcABC"
    t = KeepOnlyLetters(s, underscore=False, digits=False)
    assert(t == expected + " "*4)
    t = KeepOnlyLetters(s, underscore=True, digits=False)
    assert(t == expected + " "*3 + "_")

def TestReadVariables():
    code = '''
a = 3
b = 4
c = "5"'''
    s = StringIO(code)
    d = ReadVariables(s)
    assert(d == {"a": 3, "b": 4, "c": "5"})
    
def TestVisualCount():
    s = (1, 1, 1, 2, "a", "a", (1, 2))
    got = "\n".join(VisualCount(s, width=20))
    expected ='''
1      *************
a      ********
2      ****
(1, 2) ****'''[1:]
    assert(got == expected)

def TestWalker():
    # Construct a dummy directory structure
    dir, file = "walker", "a"
    path = os.path.join(dir, file)
    os.mkdir(dir)
    open(path, "w").write("hello")
    # Test we see directory
    w = Walker()
    w.dir = True
    for i in w("."):
        assert(i == "./walker")
    # Test we see file
    w = Walker()
    w.dir = False
    for i in w("walker"):
        assert(i == "walker/a")
    # Remove what we set up
    os.remove(path)
    os.rmdir(dir)

def Test_mantissa():
    x = 1.234 
    mant = mantissa(x)
    assert(mant == 0.091315)

def Test_significand():
    x = math.pi*1e-10
    assert(significand(x, digits=6) == 3.14159)
    assert(significand(x, digits=2) == 3.1)

def Test_bitvector():
    s = "9"
    bv = bitvector(s)
    assert(str(bv) == s)
    assert(repr(bv) == "bitvector({})".format(s))
    binary = bin(int(s))[2:] + "0"*8
    for i, value in enumerate(binary):
        assert(bv[i] == int(value))
    assert(bv[1000] == 0)   # Check a high bit number

def Test_BraceExpansion():
    assert(list(BraceExpansion("a.{a, b}")) == ['a.a', 'a. b'])
    # Cartesian product
    s = list(BraceExpansion("{A,B,C,D}{A,B,C,D}"))
    t = [i + j for i, j in itertools.product('ABCD', repeat=2)]
    assert(s == t)

def Test_GrayConversions():
    # Test integers from 0 to 15
    gray = "0 1 11 10 110 111 101 100 1100 1101 1111 1110 1010 1011 1001 1000"
    for i, g in enumerate(gray.split()):
        b = gray2bin(g)
        assert(b == bin(i)[2:])
        g1 = bin2gray(b)
        assert(g1 == g)

if __name__ == "__main__":
    exit(run(globals(), dryrun=False)[0])
